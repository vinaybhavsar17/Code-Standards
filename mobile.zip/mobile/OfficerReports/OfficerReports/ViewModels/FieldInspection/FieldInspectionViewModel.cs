﻿using OfficerReports.Resources.Strings;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using OfficerReports.Services.LocationService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using OfficerReports.Models.FieldInspection;
using OfficerReports.Services.FieldInspection;
using System.Collections.ObjectModel;
using OfficerReports.Models;
using OfficerReports.Constants;
using OfficerReports.Services.Storage;
using CommunityToolkit.Maui.Core.Extensions;
using OfficerReports.Interfaces;
using OfficerReports.Models.Base;
using OfficerReports.Services.Base;

namespace OfficerReports.ViewModels.FieldInspection
{
    public class FieldInspectionViewModel : ViewModelBase
    {

        #region Internal Variables/Constants
        private IUserService _userService;
        private ILocationService _locationService;
        private IFieldInspectionService _fieldInspectionService;
        private IAzureStorageService _azureStorageService;
        private int _clientSideID;
        private int _userID;
        private int _clientID;
        private int _customerID;
        private DateTime _reportOpenedDateAndTime;
        private Location fieldOfficerOpenedLocation;
        private Location fieldOfficerCreatedLocation;
        #endregion

        #region Bindable Properties


        private Models.Site.ClientSite _selectWorkSite;
        public Models.Site.ClientSite SelectWorkSite
        {
            get { return _selectWorkSite; }
            set
            {
                _selectWorkSite = value;
                Site = _selectWorkSite.SiteName;
                Client = _selectWorkSite.ClientName;
                _clientSideID = _selectWorkSite.ClientSiteId;
                _clientID = _selectWorkSite.ClientId;
                RaisePropertyChanged(() => SelectWorkSite);
            }
        }


        private ObservableCollection<FieldInspectedOfficer> _inspectedOfficers;
        public ObservableCollection<FieldInspectedOfficer> InspectedOfficers
        {
            get { return _inspectedOfficers; }
            set
            {
                _inspectedOfficers = value;
                OnPropertyChanged(nameof(InspectedOfficers));

            }
        }

        private int _selectedItemIndex;
        public int SelectedItemIndex
        {
            get { return _selectedItemIndex; }
            set
            {
                _selectedItemIndex = value;
                OnPropertyChanged(nameof(SelectedItemIndex));
            }
        }

        private FieldInspectedOfficer _selectedInspectedOfficer;
        public FieldInspectedOfficer SelectedInspectedOfficer
        {
            get { return _selectedInspectedOfficer; }
            set
            {
                _selectedInspectedOfficer = value;
                if (value != null)
                {
                    if (value.UserName == AppConstants.TypeNA)
                    {
                        OtherOfficerEnabled = true;
                    }
                    else
                    {
                        OtherInspectedOfficerIfNotInList = string.Empty;
                        OtherOfficerEnabled = false;
                    }
                }
                OnPropertyChanged(nameof(SelectedInspectedOfficer));

            }
        }

        private bool _otherOfficerEnabled;
        public bool OtherOfficerEnabled
        {
            get { return _otherOfficerEnabled; }
            set
            {
                _otherOfficerEnabled = value;
                OnPropertyChanged(nameof(OtherOfficerEnabled));
            }
        }

        private ObservableCollection<Models.FileInfo> _officerfiles;
        public ObservableCollection<Models.FileInfo> OfficerFiles
        {
            get { return _officerfiles; }
            set
            {
                _officerfiles = value;
                RaisePropertyChanged(() => OfficerFiles);
            }
        }

        private ObservableCollection<Models.FileInfo> _vehiclefiles;
        public ObservableCollection<Models.FileInfo> VehicleFiles
        {
            get { return _vehiclefiles; }
            set
            {
                _vehiclefiles = value;
                RaisePropertyChanged(() => VehicleFiles);
            }
        }

        private string _officer;
        public string Officer
        {
            get { return _officer; }
            set
            {
                _officer = value;
                RaisePropertyChanged(() => Officer);
            }
        }

        private string _client;
        public string Client
        {
            get { return _client; }
            set
            {
                _client = value;
                RaisePropertyChanged(() => Client);
            }
        }

        private string _site;
        public string Site
        {
            get { return _site; }
            set
            {
                _site = value;
                RaisePropertyChanged(() => Site);
            }
        }

        private string _otherInspectedOfficerIfNotInList;
        public string OtherInspectedOfficerIfNotInList
        {
            get { return _otherInspectedOfficerIfNotInList; }
            set
            {
                _otherInspectedOfficerIfNotInList = value;
                RaisePropertyChanged(() => OtherInspectedOfficerIfNotInList);
            }
        }

        private string _meetClient = AppResource.False;
        public string MeetClient
        {
            get { return _meetClient; }
            set
            {
                _meetClient = value;
                if (value == AppResource.False || value == AppResource.NA)
                {
                    WhyYouNotMeetWithClientDescribe = string.Empty;
                }
                RaisePropertyChanged(() => MeetClient);
            }
        }

        private string _whyYouNotMeetWithClientDescribe;
        public string WhyYouNotMeetWithClientDescribe
        {
            get { return _whyYouNotMeetWithClientDescribe; }
            set
            {
                _whyYouNotMeetWithClientDescribe = value;
                RaisePropertyChanged(() => WhyYouNotMeetWithClientDescribe);
            }
        }

        private bool _darCompleted = true;
        public bool DarCompleted
        {
            get { return _darCompleted; }
            set
            {
                _darCompleted = value;
                if (value == true)
                {
                    DarNotCompletedDescribe = string.Empty;
                }
                RaisePropertyChanged(() => DarCompleted);
            }
        }

        private string _darNotCompletedDescribe;
        public string DarNotCompletedDescribe
        {
            get { return _darNotCompletedDescribe; }
            set
            {
                _darNotCompletedDescribe = value;
                RaisePropertyChanged(() => DarNotCompletedDescribe);
            }
        }

        private bool _properUniform = true;
        public bool ProperUniform
        {
            get { return _properUniform; }
            set
            {
                _properUniform = value;
                if (value == true)
                {
                    ProperUniformIfNoDescribe = string.Empty;
                }
                RaisePropertyChanged(() => ProperUniform);
            }
        }

        private string _properUniformIfNoDescribe;
        public string ProperUniformIfNoDescribe
        {
            get { return _properUniformIfNoDescribe; }
            set
            {
                _properUniformIfNoDescribe = value;
                RaisePropertyChanged(() => ProperUniformIfNoDescribe);
            }
        }

        private bool _isProperlyGroomed = true;
        public bool IsProperlyGroomed
        {
            get { return _isProperlyGroomed; }
            set
            {
                _isProperlyGroomed = value;
                if (value == true)
                {
                    ProperlyGroomedIfNoDescribe = string.Empty;
                }
                RaisePropertyChanged(() => IsProperlyGroomed);
            }
        }

        private string _properlyGroomedIfNoDescribe;
        public string ProperlyGroomedIfNoDescribe
        {
            get { return _properlyGroomedIfNoDescribe; }
            set
            {
                _properlyGroomedIfNoDescribe = value;
                RaisePropertyChanged(() => ProperlyGroomedIfNoDescribe);
            }
        }

        private bool _validLicense = true;
        public bool ValidLicense
        {
            get { return _validLicense; }
            set
            {
                _validLicense = value;
                if (value == true)
                {
                    LicenseNotValidThenDescribe = string.Empty;
                }
                RaisePropertyChanged(() => ValidLicense);
            }
        }

        private string _licenseNotValidThenDescribe;
        public string LicenseNotValidThenDescribe
        {
            get { return _licenseNotValidThenDescribe; }
            set
            {
                _licenseNotValidThenDescribe = value;
                RaisePropertyChanged(() => LicenseNotValidThenDescribe);
            }
        }

        private bool _adminQuestion;
        public bool AdminQuestion
        {
            get { return _adminQuestion; }
            set
            {
                _adminQuestion = value;
                if (value == false)
                {
                    IfAdminQuestionsWhatAreThey = string.Empty;
                }
                RaisePropertyChanged(() => AdminQuestion);
            }
        }

        private string _ifAdminQuestionsWhatAreThey;
        public string IfAdminQuestionsWhatAreThey
        {
            get { return _ifAdminQuestionsWhatAreThey; }
            set
            {
                _ifAdminQuestionsWhatAreThey = value;
                RaisePropertyChanged(() => IfAdminQuestionsWhatAreThey);
            }
        }

        private bool _knownPostOrder = true;
        public bool KnownPostOrder
        {
            get { return _knownPostOrder; }
            set
            {
                _knownPostOrder = value;
                if (value == true)
                {
                    IfAdminQuestionsWhatAreThey = string.Empty;
                }
                RaisePropertyChanged(() => KnownPostOrder);
            }
        }

        private string _ifOfficerDontKnowPostOrderDescribe;
        public string IfOfficerDontKnowPostOrderDescribe
        {
            get { return _ifOfficerDontKnowPostOrderDescribe; }
            set
            {
                _ifOfficerDontKnowPostOrderDescribe = value;
                RaisePropertyChanged(() => IfOfficerDontKnowPostOrderDescribe);
            }
        }

        private string _isVechileDocPresent = AppResource.True;
        public string IsVechileDocPresent
        {
            get { return _isVechileDocPresent; }
            set
            {
                _isVechileDocPresent = value;
                if (value == AppResource.False || value == AppResource.NA)
                {
                    VehicleDocNotPresentThenDescribe = string.Empty;
                }
                RaisePropertyChanged(() => IsVechileDocPresent);
            }
        }

        private string _vehicleDocNotPresentThenDescribe;
        public string VehicleDocNotPresentThenDescribe
        {
            get { return _vehicleDocNotPresentThenDescribe; }
            set
            {
                _vehicleDocNotPresentThenDescribe = value;
                RaisePropertyChanged(() => VehicleDocNotPresentThenDescribe);
            }
        }

        private string _isVechileServiceRequired = AppResource.False;
        public string IsVechileServiceRequired
        {
            get { return _isVechileServiceRequired; }
            set
            {
                _isVechileServiceRequired = value;
                if (value == AppResource.False || value == AppResource.NA)
                {
                    IsVechileServiceRequiredThenDescribe = string.Empty;
                }
                RaisePropertyChanged(() => IsVechileServiceRequired);
            }
        }

        private string _isVechileServiceRequiredThenDescribe;
        public string IsVechileServiceRequiredThenDescribe
        {
            get { return _isVechileServiceRequiredThenDescribe; }
            set
            {
                _isVechileServiceRequiredThenDescribe = value;
                RaisePropertyChanged(() => IsVechileServiceRequiredThenDescribe);
            }
        }

        private bool _isVechileGoodCondition = true;
        public bool IsVechileGoodCondition
        {
            get { return _isVechileGoodCondition; }
            set
            {
                _isVechileGoodCondition = value;
                if (value == true)
                {
                    VechilNotInGoodConditionThenDescribe = string.Empty;
                }
                RaisePropertyChanged(() => IsVechileGoodCondition);
            }
        }

        private string _vechilNotInGoodConditionThenDescribe;
        public string VechilNotInGoodConditionThenDescribe
        {
            get { return _vechilNotInGoodConditionThenDescribe; }
            set
            {
                _vechilNotInGoodConditionThenDescribe = value;
                RaisePropertyChanged(() => VechilNotInGoodConditionThenDescribe);
            }
        }

        private bool _alert = true;
        public bool Alert
        {
            get { return _alert; }
            set
            {
                _alert = value;
                if (value == true)
                {
                    AlertIfNoDescribe = string.Empty;
                }
                RaisePropertyChanged(() => Alert);
            }
        }

        private string _alertIfNoDescribe;
        public string AlertIfNoDescribe
        {
            get { return _alertIfNoDescribe; }
            set
            {
                _alertIfNoDescribe = value;
                RaisePropertyChanged(() => AlertIfNoDescribe);
            }
        }

        private bool _isDistracted;
        public bool IsDistracted
        {
            get { return _isDistracted; }
            set
            {
                _isDistracted = value;
                if (value == true)
                {
                    DistractedIfNoDescribe = string.Empty;
                }
                RaisePropertyChanged(() => IsDistracted);
            }
        }

        private string _distractedIfNoDescribe;
        public string DistractedIfNoDescribe
        {
            get { return _distractedIfNoDescribe; }
            set
            {
                _distractedIfNoDescribe = value;
                RaisePropertyChanged(() => DistractedIfNoDescribe);
            }
        }

        private string _additionalComments;
        public string AdditionalComments
        {
            get { return _additionalComments; }
            set
            {
                _additionalComments = value;
                RaisePropertyChanged(() => AdditionalComments);
            }
        }


        #endregion

        #region Commands
        public ICommand SubmitCommand => new Command(() => SubmitForm());
        public ICommand ClearCommand => new Command(() => ClearForm());
        #endregion

        #region Constructors
        public FieldInspectionViewModel(IUserService userService,
            ILocationService locationService,
            IFieldInspectionService fieldInspectionService,
             IAzureStorageService azureStorageService)
        {
            _userService = userService;
            _locationService = locationService;
            _azureStorageService = azureStorageService;
            _fieldInspectionService = fieldInspectionService;
        }
        #endregion


        #region Overriden Methods

        public async override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Field_Inspection;

            LoadData();
            await GetFieldInspectionOfficerList();

            DialogService.HideLoading(); //This loader was opened when clicked on field inspection option on sitemenuviewmodel.

            await base.InitializeAsync(query);
            return;
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            var selectedInspectedOfficer = GetCachedProperty<FieldInspectedOfficer>(nameof(SelectedInspectedOfficer), data, ref isCachedFromPreviousSession);
            if (selectedInspectedOfficer != null && InspectedOfficers != null)
            {
                SelectedInspectedOfficer = InspectedOfficers.Where(o => o.UserId == selectedInspectedOfficer.UserId).FirstOrDefault();
            }

            OtherInspectedOfficerIfNotInList = GetCachedProperty<string>(nameof(OtherInspectedOfficerIfNotInList), data, ref isCachedFromPreviousSession);

            OfficerFiles = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(OfficerFiles), data, ref isCachedFromPreviousSession);

            bool isAlertCached;
            var alert = GetCachedBoolProperty(nameof(Alert), data, ref isCachedFromPreviousSession, out isAlertCached);
            if (isAlertCached)
                Alert = alert;

            AlertIfNoDescribe = GetCachedProperty<string>(nameof(AlertIfNoDescribe), data, ref isCachedFromPreviousSession);

            bool isDistractedCached;
            var isDistracted = GetCachedBoolProperty(nameof(IsDistracted), data, ref isCachedFromPreviousSession, out isDistractedCached);
            if (isDistractedCached)
                IsDistracted = isDistracted;

            DistractedIfNoDescribe = GetCachedProperty<string>(nameof(DistractedIfNoDescribe), data, ref isCachedFromPreviousSession);

            bool properUniformCached;
            var properUniform = GetCachedBoolProperty(nameof(ProperUniform), data, ref isCachedFromPreviousSession, out properUniformCached);
            if (properUniformCached)
                ProperUniform = properUniform;

            ProperUniformIfNoDescribe = GetCachedProperty<string>(nameof(ProperUniformIfNoDescribe), data, ref isCachedFromPreviousSession);

            bool isProperlyGroomedCached;
            var isProperlyGroomed = GetCachedBoolProperty(nameof(IsProperlyGroomed), data, ref isCachedFromPreviousSession, out isProperlyGroomedCached);
            if (isProperlyGroomedCached)
                IsProperlyGroomed = isProperlyGroomed;

            ProperlyGroomedIfNoDescribe = GetCachedProperty<string>(nameof(ProperlyGroomedIfNoDescribe), data, ref isCachedFromPreviousSession);

            bool validLicenseCached;
            var validLicense = GetCachedBoolProperty(nameof(ValidLicense), data, ref isCachedFromPreviousSession, out validLicenseCached);
            if (validLicenseCached)
                ValidLicense = validLicense;

            LicenseNotValidThenDescribe = GetCachedProperty<string>(nameof(LicenseNotValidThenDescribe), data, ref isCachedFromPreviousSession);

            bool darCompletedCached;
            var darCompleted = GetCachedBoolProperty(nameof(DarCompleted), data, ref isCachedFromPreviousSession, out darCompletedCached);
            if (darCompletedCached)
                DarCompleted = darCompleted;

            DarNotCompletedDescribe = GetCachedProperty<string>(nameof(DarNotCompletedDescribe), data, ref isCachedFromPreviousSession);

            bool knownPostOrderCached;
            var knownPostOrder = GetCachedBoolProperty(nameof(KnownPostOrder), data, ref isCachedFromPreviousSession, out knownPostOrderCached);
            if (knownPostOrderCached)
                KnownPostOrder = knownPostOrder;

            IfOfficerDontKnowPostOrderDescribe = GetCachedProperty<string>(nameof(IfOfficerDontKnowPostOrderDescribe), data, ref isCachedFromPreviousSession);

            bool adminQuestionCached;
            var adminQuestion = GetCachedBoolProperty(nameof(AdminQuestion), data, ref isCachedFromPreviousSession, out adminQuestionCached);
            if (adminQuestionCached)
                AdminQuestion = adminQuestion;

            IfAdminQuestionsWhatAreThey = GetCachedProperty<string>(nameof(IfAdminQuestionsWhatAreThey), data, ref isCachedFromPreviousSession);

            bool isVechileGoodConditionCached;
            var isVechileGoodCondition = GetCachedBoolProperty(nameof(IsVechileGoodCondition), data, ref isCachedFromPreviousSession, out isVechileGoodConditionCached);
            if (isVechileGoodConditionCached)
                IsVechileGoodCondition = isVechileGoodCondition;

            VechilNotInGoodConditionThenDescribe = GetCachedProperty<string>(nameof(VechilNotInGoodConditionThenDescribe), data, ref isCachedFromPreviousSession);

            VehicleFiles = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(VehicleFiles), data, ref isCachedFromPreviousSession);

            IsVechileServiceRequired = GetCachedProperty<string>(nameof(IsVechileServiceRequired), data, ref isCachedFromPreviousSession);
            IsVechileServiceRequiredThenDescribe = GetCachedProperty<string>(nameof(IsVechileServiceRequiredThenDescribe), data, ref isCachedFromPreviousSession);

            IsVechileDocPresent = GetCachedProperty<string>(nameof(IsVechileDocPresent), data, ref isCachedFromPreviousSession);
            VehicleDocNotPresentThenDescribe = GetCachedProperty<string>(nameof(VehicleDocNotPresentThenDescribe), data, ref isCachedFromPreviousSession);

            MeetClient = GetCachedProperty<string>(nameof(MeetClient), data, ref isCachedFromPreviousSession);
            WhyYouNotMeetWithClientDescribe = GetCachedProperty<string>(nameof(WhyYouNotMeetWithClientDescribe), data, ref isCachedFromPreviousSession);

            AdditionalComments = GetCachedProperty<string>(nameof(AdditionalComments), data, ref isCachedFromPreviousSession);
            
            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        private void LoadData()
        {
            var user = _userService.GetLoggedInUserInfo();
            Officer = user.FullName;
            _customerID = (int)user.CustomerId;
            _userID = user.UserId;
            _reportOpenedDateAndTime = DateTime.Now;
            SelectWorkSite = SiteMenuViewModel.Site;

        }

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(SelectedInspectedOfficer));
        }

        #endregion


        #region Private Methods

        private Task GetFieldInspectionOfficerList()
        {
            var tcs = new TaskCompletionSource();

            CallApi(

                apiMethod: async () => await _fieldInspectionService.GetFieldInspectionOfficerList(),

                onSuccess: (response) =>
                {
                    var data = response.GetApiDataList<FieldInspectedOfficer>();
                    var list = (List<FieldInspectedOfficer>)data;
                    var otherObject = new FieldInspectedOfficer()
                    {
                        UserName = AppConstants.TypeNA
                    };
                    list.Insert(0, otherObject);
                    InspectedOfficers = new ObservableCollection<FieldInspectedOfficer>(list);
      

                    tcs.TrySetResult();
                },

                onFailure: () =>
                {
                    tcs.TrySetResult();
                },

                isBackground: true

            );

            return tcs.Task;
        }

        private async void SubmitForm()
        {

            if (!Validator.Validate())
                return;

            if (fieldOfficerOpenedLocation == null)
            {
                DialogService.ShowMessage(AppResource.Alert, AppResource.Unable_Fetch_Location);
                return;
            }

            var createFieldInspectionRequest = new CreateFieldInspectionRequest
            {
                ClientSiteId = _clientSideID.ToString(),
                CustomerId = _customerID.ToString(),
                ClientId = _clientID.ToString(),
                InspectedOfficerId = _selectedInspectedOfficer.UserId.ToString(),
                MeetClient = MeetClient == AppResource.True,
                MeetClientDescription = WhyYouNotMeetWithClientDescribe,
                Darcompleted = DarCompleted,
                DarDescription = DarNotCompletedDescribe,
                OpenedDate = _reportOpenedDateAndTime.ToString("O"),
                ProperUniform = ProperUniform,
                ProperUniformDescription = ProperUniformIfNoDescribe,
                ValidLicenses = ValidLicense,
                ValidLicensesDescription = LicenseNotValidThenDescribe,
                AdminQuestions = AdminQuestion,
                AdminQuestionsDescription = IfAdminQuestionsWhatAreThey,
                KnowPostOrders = KnownPostOrder,
                KnowPostOrderDescription = IfOfficerDontKnowPostOrderDescribe,
                OpenedLatitude = fieldOfficerOpenedLocation.Latitude.ToString(""),
                OpenedLongitude = fieldOfficerOpenedLocation.Longitude.ToString(""),
                InspectedOfficer = _selectedInspectedOfficer.UserName,
                OtherInspectedOfficer = OtherInspectedOfficerIfNotInList,
                IsProperGroomed = IsProperlyGroomed,
                ProperlyGroomed = ProperlyGroomedIfNoDescribe,
                AdditionalComments = AdditionalComments,
                IsVehicleDocsPresent = IsVechileDocPresent == AppResource.True,
                VehicleDocsPresent = VehicleDocNotPresentThenDescribe,
                IsVehicleServiceRequired = IsVechileServiceRequired == AppResource.True,
                IsVehicleGoodCondition = IsVechileGoodCondition,
                IsAlert = Alert,
                AlertDescription = AlertIfNoDescribe,
                IsDistracted = IsDistracted,
                DistractedDescription = DistractedIfNoDescribe,
                IsAttachmentAdded = (OfficerFiles != null && OfficerFiles.Count > 0) || (VehicleFiles != null && VehicleFiles.Count > 0)
            };

            CallApi(
                apiMethod: async () => await _fieldInspectionService.CreateFieldInspectionRequest(createFieldInspectionRequest),

                onSuccess: async (response) =>
                {
                    var fileSetToUpload = new List<FilesUploadData>();

                    if (OfficerFiles != null && OfficerFiles.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_fieldInspectionService).CacheFiles(OfficerFiles.ToList(), response.CachedDataId, EntityRequest.EntityTypeInspectionReport, AppConstants.PurposeReports, AppConstants.RelatedSectionOfficer);
                        }
                        else
                        {
                            fileSetToUpload.Add(new FilesUploadData
                            {
                                Section = AppConstants.RelatedSectionOfficer,
                                Files = OfficerFiles.ToList()
                            });
                        }
                    }

                    if (VehicleFiles != null && VehicleFiles.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_fieldInspectionService).CacheFiles(VehicleFiles.ToList(), response.CachedDataId, EntityRequest.EntityTypeInspectionReport, AppConstants.PurposeReports, AppConstants.RelatedSectionVehicle);
                        }
                        else
                        {
                            fileSetToUpload.Add(new FilesUploadData
                            {
                                Section = AppConstants.RelatedSectionVehicle,
                                Files = VehicleFiles.ToList()
                            });
                        }
                    }

                    if(fileSetToUpload.Count > 0 && !response.IsCached)
                    {
                        var reportId = response.Data.reportId;

                        var request = new EntityRequest
                        {
                            EntityId = reportId,
                            EntityTypeId = EntityRequest.EntityTypeInspectionReport
                        };

                        var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, fileSetToUpload, request);

                        if (!uploaded)
                        {
                            await NavigationService.PopAsync();
                            DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                            return;
                        }
                    }

                    OnSubmitCompleted(response);
                }
            );
        }

        private async void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Field_Inspection_Report_Submit);
        }

        private void ClearForm()
        {
            Validator.Reset();

            AlertIfNoDescribe = string.Empty;
            DistractedIfNoDescribe = string.Empty;
            IfOfficerDontKnowPostOrderDescribe = string.Empty;
            IsVechileServiceRequiredThenDescribe = string.Empty;
            LicenseNotValidThenDescribe = string.Empty;
            ProperlyGroomedIfNoDescribe = string.Empty;
            ProperUniformIfNoDescribe = string.Empty;
            WhyYouNotMeetWithClientDescribe = string.Empty;
            VechilNotInGoodConditionThenDescribe = string.Empty;
            VehicleDocNotPresentThenDescribe = string.Empty;
            DarNotCompletedDescribe = string.Empty;
            AdditionalComments = string.Empty;
            IfAdminQuestionsWhatAreThey = string.Empty;
            OtherInspectedOfficerIfNotInList = string.Empty;
            SelectedInspectedOfficer = null;
            OfficerFiles?.Clear();
            VehicleFiles?.Clear();

            ClearCachedProperties();
        }


        #endregion

        #region Public Methods

        public void SetFieldInspectionOpenLocation(Location location)
        {
            fieldOfficerOpenedLocation = location;
        }

        #endregion


    }
}
