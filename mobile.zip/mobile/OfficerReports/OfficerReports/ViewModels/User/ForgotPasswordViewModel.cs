﻿using OfficerReports.Constants;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.User
{
    public class ForgotPasswordViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IForgotService _forgotService;

        #endregion


        #region Bindable Properties

        private string _email;
        public string Email
        {
            get { return _email; }
            set
            {
                _email = value;
                RaisePropertyChanged(() => Email);
            }
        }

        #endregion


        #region Commands

        public ICommand SubmitCommand => new Command(() =>  Submit());
        public ICommand GoBackCommand => new Command(() =>  GoBack());
        #endregion


        #region Constructors

        public ForgotPasswordViewModel(IForgotService forgotService)
        {
            _forgotService = forgotService;
        }

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
#if DEBUG
            Email = "dheeraj.solanki4@gmail.com";
#endif
            return base.InitializeAsync(query);
        }


        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(Email));
        }

        #endregion


        #region Private Methods

        private void Submit()
        {
            if (!Validator.Validate())
                return;

            CallApi(

                apiMethod: async () => await _forgotService.ForgotPassword(Email),

                onSuccess: (response) => {
                    ClearForm();
                    DialogService.ShowMessage(AppResource.Alert, response.Message);
                }

             );

        }

        private void GoBack()
        {
            NavigationService.PopAsync();
        }

        private void ClearForm()
        {
            Validator.Reset();

            Email = String.Empty;
        }

        #endregion


    }
}
