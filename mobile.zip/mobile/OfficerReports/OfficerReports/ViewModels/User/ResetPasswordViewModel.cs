﻿using System;
using OfficerReports.ViewModels.Base;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Authentication;
using System.Windows.Input;
using OfficerReports.Models.Authentication;

namespace OfficerReports.ViewModels.User
{
    public class ResetPasswordViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IAuthenticationService _authenticationService;

        #endregion


        #region Bindable Properties

        private string _username;
        public string Username
        {
            get { return _username; }
            set
            {
                _username = value;
                RaisePropertyChanged(() => Username);
            }
        }

        private string _oldPassword;
        public string OldPassword
        {
            get { return _oldPassword; }
            set
            {
                _oldPassword = value;
                RaisePropertyChanged(() => OldPassword);
            }
        }

        private string _newPassword;
        public string NewPassword
        {
            get { return _newPassword; }
            set
            {
                _newPassword = value;
                RaisePropertyChanged(() => NewPassword);
            }
        }

        private string _confirmPassword;
        public string ConfirmPassword
        {
            get { return _confirmPassword; }
            set
            {
                _confirmPassword = value;
                RaisePropertyChanged(() => ConfirmPassword);
            }
        }

        #endregion


        #region Commands

        public ICommand SubmitCommand => new Command(() => Submit());

        #endregion


        #region Constructors

        public ResetPasswordViewModel(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

        #endregion


        #region Overriden Methods

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(Username));
            Validator.AddField(nameof(OldPassword));
            Validator.AddField(nameof(NewPassword));
            Validator.AddField(nameof(ConfirmPassword));
        }

        #endregion


        #region Private Methods

        private void Submit()
        {
            if (!Validator.Validate())
                return;

            var request = new ResetPasswordRequest
            {
                UserName = Username,
                OldPassword = OldPassword,
                Password = NewPassword,
                ConfirmPassword = ConfirmPassword
            };

            CallApi(

                apiMethod: async () => await _authenticationService.ResetPassword(request),

                onSuccess: async(response) => {
                    await NavigationService.PopAsync();
                    DialogService.ShowMessage(AppResource.Alert, response.Message);
                }

             );

        }

        private void ClearForm()
        {
            Validator.Reset();

            Username = String.Empty;
            OldPassword = String.Empty;
            NewPassword = String.Empty;
            ConfirmPassword = String.Empty;
        }

        #endregion
    }
}

