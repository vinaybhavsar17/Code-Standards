﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using OfficerReports.Models.PostOrder;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.PostOrder;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;

namespace OfficerReports.ViewModels.PostOrder
{
    public class PostOrderViewModel : ViewModelBase
    {

        #region Internal Variables/Constants
        private IPostOrderService _postOrderService;
        private IUserService _userService;
        private string _fileUrl;
        #endregion


        #region Bindable Properties

        private string _officer;
        public string Officer
        {
            get { return _officer; }
            set
            {
                _officer = value;
                RaisePropertyChanged(() => Officer);
            }
        }

        private string _client;
        public string Client
        {
            get { return _client; }
            set
            {
                _client = value;
                RaisePropertyChanged(() => Client);
            }
        }

        private string _site;
        public string Site
        {
            get { return _site; }
            set
            {
                _site = value;
                RaisePropertyChanged(() => Site);
            }
        }

        private string _address;
        public string Address
        {
            get { return _address; }
            set
            {
                _address = value;
                RaisePropertyChanged(() => Address);
            }
        }

        private string _clientName;
        public string ClientName
        {
            get { return _clientName; }
            set
            {
                _clientName = value;
                RaisePropertyChanged(() => ClientName);
            }
        }

        private string _clientPhone;
        public string ClientPhone
        {
            get { return _clientPhone; }
            set
            {
                _clientPhone = value;
                RaisePropertyChanged(() => ClientPhone);
            }
        }

        private string _maintenancePersonName;
        public string MaintenancePersonName
        {
            get { return _maintenancePersonName; }
            set
            {
                _maintenancePersonName = value;
                RaisePropertyChanged(() => MaintenancePersonName);
            }
        }

        private string _maintenancePersonPhone;
        public string MaintenancePersonPhone
        {
            get { return _maintenancePersonPhone; }
            set
            {
                _maintenancePersonPhone = value;
                RaisePropertyChanged(() => MaintenancePersonPhone);
            }
        }

        private string _policeDepatmentName;
        public string PoliceDepatmentName
        {
            get { return _policeDepatmentName; }
            set
            {
                _policeDepatmentName = value;
                RaisePropertyChanged(() => PoliceDepatmentName);
            }
        }

        private string _policeDepatmentPhone;
        public string PoliceDepatmentPhone
        {
            get { return _policeDepatmentPhone; }
            set
            {
                _policeDepatmentPhone = value;
                RaisePropertyChanged(() => PoliceDepatmentPhone);
            }
        }

        private string _towingCompanyName;
        public string TowingCompanyName
        {
            get { return _towingCompanyName; }
            set
            {
                _towingCompanyName = value;
                RaisePropertyChanged(() => TowingCompanyName);
            }
        }

        private string _towingCompanyPhone;
        public string TowingCompanyPhone
        {
            get { return _towingCompanyPhone; }
            set
            {
                _towingCompanyPhone = value;
                RaisePropertyChanged(() => TowingCompanyPhone);
            }
        }

        private string _comments;
        public string Comments
        {
            get { return _comments; }
            set
            {
                _comments = value;
                RaisePropertyChanged(() => Comments);
            }
        }

        private string _fileName;
        public string FileName
        {
            get { return _fileName; }
            set
            {
                _fileName = value;
                RaisePropertyChanged(() => FileName);
            }
        }

        private bool _isFileAvaialable;
        public bool IsFileAvaialable
        {
            get { return _isFileAvaialable; }
            set
            {
                _isFileAvaialable = value;
                RaisePropertyChanged(() => IsFileAvaialable);
            }
        }

        #endregion


        #region Override Method

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Post_Orders;
            LoadData();
            GetPostOrderDetails();
            return base.InitializeAsync(query);
        }


        #endregion

        #region Commands
        public ICommand ViewFileCommand => new Command(() => OpenFile());
        
        #endregion


        #region Constructors
        public PostOrderViewModel(IUserService userService, IPostOrderService postOrderService)
        {
            _postOrderService = postOrderService;
            _userService = userService;
        }
        #endregion


        #region Overriden Methods

        #endregion


        #region Private Methods

        private void LoadData()
        {
            var user = _userService.GetLoggedInUserInfo();
            Officer = user.FullName;
            Site = SiteMenuViewModel.Site.SiteName.ToString();
            Client = SiteMenuViewModel.Site.ClientName.ToString();
        }

        private void GetPostOrderDetails()
        {
            CallApi(

               apiMethod: async () => await _postOrderService.GetPostOrder(),

               onSuccess: (response) => {
                   var result = response.ProcessedData;
                   var list = (List<PostOrderDetail>)result;
                   LoadPostOrderDetails(list[0]);
               }
            );
        }

        private void LoadPostOrderDetails(PostOrderDetail objectPostOrderDetails) {
            ClientName = objectPostOrderDetails.ClientContact;
            ClientPhone = objectPostOrderDetails.Contact;
            MaintenancePersonName = objectPostOrderDetails.MaintenanceContact;
            MaintenancePersonPhone = objectPostOrderDetails.MaintenancePhone;
            PoliceDepatmentName = objectPostOrderDetails.PoliceContact;
            PoliceDepatmentPhone = objectPostOrderDetails.PolicePhone;
            TowingCompanyName = objectPostOrderDetails.TowingContact;
            TowingCompanyPhone = objectPostOrderDetails.TowingPhone;
            Comments = objectPostOrderDetails.PostOrderComments;
            Address = objectPostOrderDetails.Address1;
            FileName = objectPostOrderDetails.PoOriginalFileName;
            var url = objectPostOrderDetails.PoFileUrl;
            if (url != "")
            {
                _fileUrl = url.ToString();
                IsFileAvaialable = true;
            }
            else
            {
                IsFileAvaialable = false;
            }
        }

        private void OpenFile()
        {
            NavigationService.PushAsync(new PdfViewerView(_fileUrl));
        }

        #endregion


        #region Public Methods


        #endregion



    }
}
