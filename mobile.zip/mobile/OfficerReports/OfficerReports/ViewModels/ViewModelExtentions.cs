using OfficerReports.ViewModels.Authentication;
using OfficerReports.ViewModels.ClockInOut;
using OfficerReports.ViewModels.DailyActivityReport;
using OfficerReports.ViewModels.Incident;
using OfficerReports.ViewModels.FieldInspection;
using OfficerReports.ViewModels.MaintenanceReport;
using OfficerReports.ViewModels.ParkingViolation;
using OfficerReports.ViewModels.PolicyManual;
using OfficerReports.ViewModels.Site;
using OfficerReports.ViewModels.User;
using OfficerReports.ViewModels.Vacation;
using OfficerReports.ViewModels.Scheduler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.ViewModels.PassOnLog;
using OfficerReports.ViewModels.TourTracker;
using OfficerReports.ViewModels.PostOrder;
using OfficerReports.ViewModels.TemperatureLog;
using OfficerReports.ViewModels.VisitorCheckInOut;
using OfficerReports.ViewModels.TruckCheckInOut;
using OfficerReports.ViewModels.Chat;
using OfficerReports.ViewModels.SiteCheckReport;

namespace OfficerReports.ViewModels
{
    public static class ViewModelExtentions
    {
        public static MauiAppBuilder ConfigureViewModels(this MauiAppBuilder builder)
        {
            builder.Services.AddTransient<LoginViewModel>();
            builder.Services.AddTransient<MenuViewModel>();
            builder.Services.AddTransient<VacationRequestViewModel>();
            builder.Services.AddTransient<VacationReviewViewModel>();
            builder.Services.AddTransient<PolicyManualViewModel>();
            builder.Services.AddTransient<PolicyManualDetailViewModel>();
            builder.Services.AddTransient<SiteMenuViewModel>();
            builder.Services.AddTransient<ClockInOutViewModel>();
            builder.Services.AddTransient<ForgotPasswordViewModel>();
            builder.Services.AddTransient<ForgotUsernameViewModel>();
            builder.Services.AddTransient<SiteListViewModel>();
            builder.Services.AddTransient<DailyActivityReportViewModel>();
            builder.Services.AddTransient<IncidentReportViewModel>();
            builder.Services.AddTransient<MaintenanceReportViewModel>();
            builder.Services.AddTransient<FieldInspectionViewModel>();
            builder.Services.AddTransient<PdfViewerViewModel>();
            builder.Services.AddTransient<IncidentChecklistViewModel>();
            builder.Services.AddTransient<ParkingViolationSearchViewModel>();
            builder.Services.AddTransient<ParkingViolationReportViewModel>();
            builder.Services.AddTransient<ParkingViolationSearchResultViewModel>();
            builder.Services.AddTransient<ParkingViolationDetailsViewModel>();
            builder.Services.AddTransient<PassOnLogWriteViewModel>();
            builder.Services.AddTransient<PassOnLogReadViewModel>();
            builder.Services.AddTransient<PassOnLogDetailViewModel>();
            builder.Services.AddTransient<TourTrackerViewModel>();
            builder.Services.AddTransient<PreviousScansViewModel>();
            builder.Services.AddTransient<PostOrderViewModel>();
            builder.Services.AddTransient<TemperatureLogViewModel>();
            builder.Services.AddTransient<VisitorCheckOutViewModel>();
            builder.Services.AddTransient<VisitorCheckInViewModel>();
            builder.Services.AddTransient<VisitorCheckOutDetailViewModel>();
            builder.Services.AddTransient<TruckCheckInViewModel>();
            builder.Services.AddTransient<TruckCheckOutViewModel>();
            builder.Services.AddTransient<TruckCheckOutDetailViewModel>();
            builder.Services.AddTransient<ChatGroupsViewModel>();
            builder.Services.AddTransient<SiteCheckReportViewModel>();
            builder.Services.AddTransient<OtpViewModel>();
            builder.Services.AddTransient<MimicViewModel>();
            builder.Services.AddTransient<AsotLogViewModel>();
            builder.Services.AddTransient<CustomReportViewModel>();
            builder.Services.AddTransient<ChatMessageViewModel>();
            builder.Services.AddTransient<SchedulerViewModel>();
            builder.Services.AddTransient<ResetPasswordViewModel>();

            return builder;
        }
    }
}
