﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.PassOnLog;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.PassOnLog;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.PassOnLog;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.PassOnLog
{
    public class PassOnLogReadViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IPassOnLogService _passOnLogService;

        #endregion


        #region Bindable Properties

        private ObservableCollection<PassOnLogRecord> _passOnLogRead;
        public ObservableCollection<PassOnLogRecord> PassOnLogRead
        {
            get { return _passOnLogRead; }
            set
            {
                _passOnLogRead = value;
                RaisePropertyChanged(() => PassOnLogRead);
            }

        }

        #endregion

     
        #region Commands
         public ICommand SelectPassOnLogReadCommand => new Command<PassOnLogRecord>((passOnLogRead) => SelectPassOnRead(passOnLogRead));

         #endregion

              
        #region Constructor        

        public PassOnLogReadViewModel(IPassOnLogService passOnLogService)
        {
            _passOnLogService = passOnLogService;
        }

        #endregion


        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Pass_On_Log_Read;
            FetchPassOnLogRecords();
            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Method
        
        private void SelectPassOnRead(PassOnLogRecord passOnLogRead)
        {
            NavigationService.PushAsync(new PassOnLogDetailView(passOnLogRead));
        }
    
        private void FetchPassOnLogRecords()
        {
           
            CallApi(

               apiMethod: async () => await _passOnLogService.GetPassOnLogEntry(),
               onSuccess: (response) => {
                   var result = (List<PassOnLogRecord>)response.ProcessedData;
                   PassOnLogRead = new ObservableCollection<PassOnLogRecord>(result);
               }
            );
        }
        #endregion
    }
}
