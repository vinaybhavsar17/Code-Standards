﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.PassOnLog;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.PassOnLog;
using OfficerReports.Services.Storage;
using OfficerReports.ViewModels.Base;
using OfficerReports.Services.Base;
using OfficerReports.Models.Base;
using System.Collections.ObjectModel;

namespace OfficerReports.ViewModels.PassOnLog
{
    public class PassOnLogWriteViewModel : FormPageBaseViewModel
    {
        #region Internal Variables/Constants
        private IAzureStorageService _azureStorageService;
        private IPassOnLogService _passOnLogService;
        #endregion


        #region Bindable Properties

        private string _postShift;
        public string PostShift
        {
            get { return _postShift; }
            set
            {
                _postShift = value;
                RaisePropertyChanged(() => PostShift);
            }
        }

        private string _note;
        public string Note
        {
            get { return _note; }
            set
            {
                _note = value;
                RaisePropertyChanged(() => Note);
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }
        #endregion

        #region Constructor

        public PassOnLogWriteViewModel(IAzureStorageService azureStorageService, IPassOnLogService passOnLogService)
        {
            _azureStorageService = azureStorageService;
            _passOnLogService = passOnLogService;
        }

        #endregion

        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            var task = base.InitializeAsync(query);
            HeaderTitle = AppResource.Pass_On_Log_Write;
            return task;
        }

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(PostShift));
            Validator.AddField(nameof(Note));
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            PostShift = GetCachedProperty<string>(nameof(PostShift), data, ref isCachedFromPreviousSession);
            Note = GetCachedProperty<string>(nameof(Note), data, ref isCachedFromPreviousSession);

            Files = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(Files), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        protected override void SubmitForm()
        {
            var createPassOnLogReport = new CreatePassOnLogReportRequest
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                PostShift = PostShift,
                Note = Note,
                IsAttachmentAdded = Files != null && Files.Count > 0
            };

            CallApi(
                apiMethod: async () => await _passOnLogService.CreatePassOnLogReport(createPassOnLogReport),

                onSuccess: async (response) => {

                    if (Files != null && Files.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_passOnLogService).CacheFiles(Files.ToList(), response.CachedDataId, EntityRequest.EntityTypePassOnLog, AppConstants.PurposeReports);
                        }
                        else
                        {
                            var reportId = response.Data.reportId;

                            var request = new EntityRequest
                            {
                                EntityId = reportId,
                                EntityTypeId = EntityRequest.EntityTypePassOnLog
                            };

                            var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, Files.ToList(), request);

                            if (!uploaded)
                            {
                                await NavigationService.PopAsync();
                                DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                return;
                            }
                        }
                    }
                    OnSubmitCompleted(response);
                }
            );


        }

        protected override void ClearForm()
        {
            PostShift = string.Empty;
            Note = string.Empty;
            Files?.Clear();

            ClearCachedProperties();
        }

        protected async override void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Pass_On_Log_Report_Submit);
        }

        #endregion



        #region Private Methods


        #endregion
    }
}
