﻿using OfficerReports.ApiClient;
using OfficerReports.Interfaces;
using OfficerReports.Models;
using OfficerReports.Models.PassOnLog;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.PassOnLog;
using OfficerReports.Services.Storage;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.PassOnLog
{
    public class PassOnLogDetailViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        public PassOnLogRecord PassOnLog { get; set; }

        private IPassOnLogService _passOnLogService;
        private IFileStorageService _fileStorageService;

        #endregion

        #region Bindable Properties

        private PassOnLogDetailRecord _passOnLogDetailRecord;
        public PassOnLogDetailRecord PassOnLogDetailRecord
        {
            get { return _passOnLogDetailRecord; }
            set
            {
                _passOnLogDetailRecord = value;
                RaisePropertyChanged(() => PassOnLogDetailRecord);
            }
        }

        private ObservableCollection<EntityFile> _mediaUrlList;
        public ObservableCollection<EntityFile> MediaUrlList
        {
            get { return _mediaUrlList; }
            set
            {
                _mediaUrlList = value;
                RaisePropertyChanged(() => MediaUrlList);
            }
        }

        #endregion

        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.POL_Entry_Details;

            GetPassOnLogEntryDetail(PassOnLog.PassOnLogId.ToString());

            return base.InitializeAsync(query);
        }
        #endregion

        #region Commands

        public ICommand MarkAsReadCommand => new Command(() => MarkAsRead());
        public ICommand SelectFileUrlCommand => new Command<EntityFile>((objecFileUrl) => SelectedFileObject(objecFileUrl));

        #endregion


        #region Constructors
        public PassOnLogDetailViewModel(IPassOnLogService passOnLogService, IFileStorageService fileStorageService)
        {
            _passOnLogService = passOnLogService;
            _fileStorageService = fileStorageService;
        }

        #endregion

        #region Private Methods

        private void GetPassOnLogEntryDetail(string passOnLogId)
        {
            CallApi(

                apiMethod: async () => await _passOnLogService.GetPassOnLogEntryDetails(passOnLogId),

                onSuccess: (response) =>
                {
                    PassOnLogDetailRecord = (PassOnLogDetailRecord)response.ProcessedData;
                    MediaUrlList = new ObservableCollection<EntityFile>(PassOnLogDetailRecord.ProcessedEntities);
                }
             );
        }

        private void SelectedFileObject(EntityFile objecFileUrl)
        {
            PlatformServices.DownloadFile(objecFileUrl);
        }

        private void MarkAsRead()
        {
            var changeReadStatusRequest = new ChangeReadStatusRequest
            {
                PassOnLogId = PassOnLog.PassOnLogId
            };

            CallApi(

                apiMethod: async () => await _passOnLogService.ChangeMarkAsReadStatus(changeReadStatusRequest),

                onSuccess: (response) =>
                {
                    PassOnLogDetailRecord.IsRead = true;
                    PassOnLog.IsRead = true; //This is set to true so that when you go back, status is updated there also.
                    RaisePropertyChanged(() => PassOnLogDetailRecord);

                    DialogService.ShowMessage(AppResource.Success, AppResource.POL_Entry_Updated);
                }
             );
        }


        #endregion
    }
}
