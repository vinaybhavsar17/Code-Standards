﻿using OfficerReports.Interfaces;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Authentication;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.OfflineBrowsing;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using OfficerReports.Views.Authentication;
using OfficerReports.Views.BarcodeScanner;
using OfficerReports.Views.ClockInOut;
using OfficerReports.Views.DailyActivityReport;
using OfficerReports.Views.PolicyManual;
using OfficerReports.Views.Site;
using OfficerReports.Views.Vacation;
using OfficerReports.Views.Scheduler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels
{
    public class MenuViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IDataSyncService _dataSyncService;

        public static Models.Authentication.User LoggedInUser { get; private set; }

        #endregion

        #region Constructor

        public MenuViewModel(IDataSyncService dataSyncService)
        {
            _dataSyncService = dataSyncService;
        }

        #endregion

        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            _dataSyncService.Init();

            return base.InitializeAsync(query);
        }

        #endregion

        #region Commands

        public ICommand ViewSchedulerCommand => new Command(() => OpenSchedulerPage());

        public ICommand SelectWorkSiteCommand => new Command(() => OpenSelectWorkSitePage());

        public ICommand PolicyManualCommand => new Command(() => OpenPolicyManualPage());

        public ICommand VacationRequestCommand => new Command(() => OpenVacationRequestPage());

        public ICommand VacationReviewCommand => new Command(() => OpenVacationReviewPage());

        public ICommand SignOutCommand => new Command(() => SignOut(this));

        #endregion

        #region Private Methods

        private void OpenSchedulerPage()
        {
            NavigationService.PushAsync(new SchedulerView());
        }

        private void OpenSelectWorkSitePage()
        {
            NavigationService.PushAsync(new SiteListView());
        }

        private void OpenPolicyManualPage()
        {
            NavigationService.PushAsync(new PolicyManualView());
        }

        private void OpenVacationRequestPage()
        {
            NavigationService.PushAsync(new VacationRequestView());
        }

        private void OpenVacationReviewPage()
        {
            NavigationService.PushAsync(new VacationReviewView());
        }

        #endregion


        #region Public Methods

        public static async void SignOut(ViewModelBase viewModel)
        {
            if (viewModel == null)
                return;

            var isConfirmed = await viewModel.DialogService.Confirm(AppResource.Logout_Confirmation);
            if (!isConfirmed)
                return;

            var authenticationService = App.ServiceProvider.GetRequiredService<IAuthenticationService>();

            viewModel.CallApi(

                apiMethod: async () => await authenticationService.Logout(),

                onSuccess: (response) =>
                {
                    
                },

                isBackground: true
            );

            MessagingCenter.Send<object>(viewModel, App.MESSAGE_LOGOUT);
        }

        public void SetLoggedInUser(Models.Authentication.User user)
        {
            LoggedInUser = user;
        }

        #endregion
    }
}
