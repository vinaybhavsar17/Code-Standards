﻿using Newtonsoft.Json;
using OfficerReports.ApiClient;
using OfficerReports.Constants;
using OfficerReports.Helpers;
using OfficerReports.Models;
using OfficerReports.Models.Chat;
using OfficerReports.Services.Chat;
using OfficerReports.Services.Storage;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using OfficerReports.Services.OfflineBrowsing;
using Nito.AsyncEx;
using Realms;
using static Android.Content.ClipData;

namespace OfficerReports.ViewModels.Chat
{
    public class ChatMessageViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IMessagingService _messagingService;
        private ISignalRClient _signalRClient;
        private IAzureStorageService _azureStorageService;
        private ChatMessagesRequest _chatMessagesRequest;
        private ChatMessagesResult _chatMessagesResult;
        private const int _pageSize = 25;
        private int _messagesCount = 0;

        public ChatGroup SelectedChatGroup { get; set; }

        #endregion


        #region Bindable Properties

        private ObservableCollection<MessageGroup> _messages;
        public ObservableCollection<MessageGroup> Messages
        {
            get { return _messages; }
            set
            {
                _messages = value;
                RaisePropertyChanged(() => Messages);
            }
        }

        private string _messageText;
        public string MessageText
        {
            get { return _messageText; }
            set
            {
                _messageText = value;
                RaisePropertyChanged(() => MessageText);
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }

        #endregion


        #region Commands

        public ICommand LoadMoreChatMessagesCommand => new Command(() => LoadMoreChatMessages());
        public ICommand SendMessageCommand => new Command(() => SendMessage());
        public ICommand SendFileCommand => new Command(() => SendFile());
        public ICommand OpenFileCommand => new Command<ImageContent>((imageContent) => OpenFile(imageContent));

        #endregion


        #region Constructors

        public ChatMessageViewModel(IMessagingService messagingService,
                                    ISignalRClient signalRClient,
                                    IAzureStorageService azureStorageService)
        {
            _messagingService = messagingService;
            _signalRClient = signalRClient;
            _azureStorageService = azureStorageService;
        }

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = SelectedChatGroup.GroupDisplayName;

            GetChatMessages(true);

            JoinChatGroup();

            Connectivity.ConnectivityChanged += InternetConnectivityChanged;

            MessagingCenter.Subscribe<ISignalRClient, string>(this, AppConstants.MessageReceiveChat, (sender, message) =>
            {
                var messageObj = new Message(message);

                if (messageObj.MessageContent.GroupId != SelectedChatGroup.GroupId)
                    return;

                var lastMessageGroup = Messages[0];
                MessageGroup secondLastMessageGroup = null;
                if(Messages.Count > 1)
                    secondLastMessageGroup = Messages[1];

                Console.WriteLine(lastMessageGroup[0].CreatedDate.ToLongTimeString());
                Console.WriteLine(messageObj.CreatedDate.ToLongTimeString());
                Console.WriteLine(DateTime.Compare(lastMessageGroup[0].CreatedDate, messageObj.CreatedDate));

                var duplicateMessagesInLastGroup = lastMessageGroup.Where(m => m.CreatedDate == messageObj.CreatedDate && messageObj.MessageContent.UserId == MenuViewModel.LoggedInUser.UserId).ToList();
                var duplicateMessagesInSecondLastGroup = secondLastMessageGroup?.Where(m => m.CreatedDate == messageObj.CreatedDate && messageObj.MessageContent.UserId == MenuViewModel.LoggedInUser.UserId).ToList();

                if (duplicateMessagesInLastGroup.Count() == 0 && (duplicateMessagesInSecondLastGroup == null || duplicateMessagesInSecondLastGroup.Count() == 0))
                    InsertMessage(messageObj);
            });

            MessagingCenter.Subscribe<DataSyncService>(this, AppConstants.MessageOfflineUpdate, (sender) =>
            {
                Dispatcher.Dispatch(() =>
                {
                    GetChatMessages(true);
                });
            });

            return base.InitializeAsync(query);
        }

        public override void OnDestroy()
        {
            base.OnDestroy();

            Connectivity.ConnectivityChanged -= InternetConnectivityChanged;

            MessagingCenter.Unsubscribe<ISignalRClient, string>(this, AppConstants.MessageReceiveChat);
            MessagingCenter.Unsubscribe<DataSyncService>(this, AppConstants.MessageOfflineUpdate);
        }

        #endregion

        #region Private Methods

        private void InternetConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            if (NetworkUtility.IsInternetConnected)
            {
                JoinChatGroup();
            }
        }

        private async void JoinChatGroup()
        {
            int numOfRetry = 10;
            while (_signalRClient.IsConnecting)
            {
                if (numOfRetry == 0)
                    break;

                await Task.Delay(3000);
                numOfRetry--;
            }

            if (!_signalRClient.IsConnected)
                return;

            _signalRClient.SendMessage(ApiConstants.SignalRMethod_JoinGroup, SelectedChatGroup.GroupName, MenuViewModel.LoggedInUser.UserName);
        }

        private void GetChatMessages(bool isBackground = false)
        {
            _chatMessagesRequest = new ChatMessagesRequest
            {
                GroupId = SelectedChatGroup.GroupId,                
                CurrentTimeZone = TimeZoneInfo.Local.Id,
                GridFilters = new Paging
                {
                    First = 0,
                    Rows = _pageSize,
                    SortOrder = Paging.SortOrderDescending,
                    SortField = "createdDate"
                }
            };

            CallApi(

                apiMethod: async () => await _messagingService.GetChatMessages(_chatMessagesRequest),

                onSuccess: (response) =>
                {
                    _chatMessagesResult = (ChatMessagesResult)response.ProcessedData;

                    var records = AddOfflineMessages(_chatMessagesResult.Records);

                    Messages = new ObservableCollection<MessageGroup>();
                    AddMessages(records);

                    SelectedChatGroup.Msgcount = 0;
                    MessagingCenter.Send<ISignalRClient, string>(App.ServiceProvider.GetRequiredService<ISignalRClient>(), AppConstants.MessageNewChat, "");
                },

                onFailure: () =>
                {
                    var records = AddOfflineMessages(new List<Message>());

                    Messages = new ObservableCollection<MessageGroup>();
                    AddMessages(records);
                },

                isBackground: isBackground
            );
        }

        private void LoadMoreChatMessages()
        {
            if (IsBusy)
                return;

            if (_chatMessagesResult == null || _messagesCount >= _chatMessagesResult.Count)
                return;

            _chatMessagesRequest.GridFilters.First = _messagesCount;

            IsBusy = true;
            CallApi(

               apiMethod: async () => await _messagingService.GetChatMessages(_chatMessagesRequest),

               onSuccess: (response) => {
                   var result = (ChatMessagesResult)response.ProcessedData;

                   AddMessages(result.Records);

                   IsBusy = false;
               },

               isBackground: true,

               onFailure: () =>
               {
                   IsBusy = false;
               }
            );
        }

        private void InsertMessage(Message newMessage)
        {
            if (Messages == null || newMessage == null)
                return;

            var newMessageDate = newMessage.CreatedDate;
            var messageGroup = Messages.FirstOrDefault();
            if (messageGroup != null && messageGroup.MessageDate.ToLocalTime().Date == newMessageDate.ToLocalTime().Date)
            {
                var index = Messages.IndexOf(messageGroup);
                messageGroup.Insert(0, newMessage);
            }
            else
            {
                messageGroup = new MessageGroup
                {
                    MessageDate = newMessage.CreatedDate
                };
                messageGroup.Add(newMessage);
                Messages.Insert(0, messageGroup);
            }

            _messagesCount++;
        }

        private void AddMessage(Message newMessage)
        {
            if (Messages == null || newMessage == null)
                return;

            var newMessageDate = newMessage.CreatedDate;
            var messageGroup = Messages.LastOrDefault();
            if (messageGroup != null && messageGroup.MessageDate.ToLocalTime().Date == newMessageDate.ToLocalTime().Date)
            {
                messageGroup.Add(newMessage);
            }
            else
            {
                messageGroup = new MessageGroup
                {
                    MessageDate = newMessage.CreatedDate
                };
                messageGroup.Add(newMessage);
                Messages.Add(messageGroup);
            }

            if(!newMessage.MessageContent.IsOffline)
                _messagesCount++;
        }

        private void AddMessages(List<Message> newMessages)
        {
            if (Messages == null || newMessages == null)
                return;

            foreach (var newMessage in newMessages)
            {
                AddMessage(newMessage);
            }
        }

        private List<Message> AddOfflineMessages(List<Message> records)
        {
            var realm = RealmService.GetRealm();
            var offlineRecords = realm.All<MessageDto>().Where(r => r.GroupId == SelectedChatGroup.GroupId && r.UserId == MenuViewModel.LoggedInUser.UserId);

            foreach (var offlineRecord in offlineRecords)
            {
                var message = offlineRecord.ToMessage();
                message.MessageContent.IsOffline = true;
                message.CreatedDate = message.MessageContent.DateTime;

                var images = FetchCachedFiles(offlineRecord.Id, message.MessageContent);
                if(images != null)
                    message.MessageContent.Images = images;

                records.Add(message);
            }

            var sortedRecords = records.OrderByDescending((m) => m.CreatedDate).ToList();

            return sortedRecords;
        }

        private void SendMessage()
        {
            if (string.IsNullOrWhiteSpace(MessageText))
                return;

            var messageSent = SendMessageToUi();

            Task.Run(async () =>
            {
                await SendMessageToSignalR(messageSent);

                MessageText = string.Empty;
            });
        }

        private void SendFile()
        {
            if ((Files == null || Files.Count == 0))
                return;

            var messageSent = SendMessageToUi();

            Task.Run(async () =>
            {
                await SendMessageToSignalR(messageSent);

                Files?.Clear();
            });
        }

        private MessageContent SendMessageToUi()
        {
            var messageContent = new MessageContent
            {
                DateTime = DateTime.UtcNow,
                FullName = MenuViewModel.LoggedInUser.FullName,
                GroupId = SelectedChatGroup.GroupId,
                Message = MessageText,
                Type = MessageContent.MessageType.Chat,
                UserId = MenuViewModel.LoggedInUser.UserId
            };

            if(Files != null && Files.Count > 0)
            {
                var images = new List<ImageContent>();

                foreach (var file in Files)
                {
                    images.Add(new ImageContent
                    {
                        Image = file.Image,
                        FullName = messageContent.FullName,
                        DateTime = messageContent.DateTime
                    });
                }

                messageContent.Images = images;
            }

            var message = new Message(messageContent);
            message.CreatedDate = messageContent.DateTime;
            message.IsRead = true;

            InsertMessage(message);

            return messageContent;
        }

        private async Task SendMessageToSignalR(MessageContent messageContent)
        {
            string messageText = null;
            Guid chatId = Guid.NewGuid();

            if (Files != null && Files.Count > 0)
            {
                var uploadedFiles = await _azureStorageService.UploadFiles(AppConstants.PurposeChatMessaging, Files.ToList());

                if (uploadedFiles != null)
                {
                    StringBuilder messageBuilder = new StringBuilder();

                    foreach (var file in uploadedFiles)
                    {
                        var imgTagStr = $"<img src=\"{file.AzureFileUrl}\" />";
                        messageBuilder.Append(imgTagStr);
                    }

                    if(messageContent.Message != null && !string.IsNullOrEmpty(messageContent.Message))
                        messageBuilder.Append(messageContent.Message);

                    messageText = messageBuilder.ToString();

                    messageContent.Message = messageText;
                }
                else
                {
                    CacheFiles(chatId, Files.ToList(), AppConstants.PurposeChatMessaging);
                }
            }

            var chatMessage = new MessageDto
            {
                Id = chatId,
                User = MenuViewModel.LoggedInUser.UserName,
                MsgText = JsonConvert.SerializeObject(messageContent),
                GroupName = SelectedChatGroup.GroupName,
                GroupId = SelectedChatGroup.GroupId,
                CustomerId = SelectedChatGroup.CustomerId,
                UserId = MenuViewModel.LoggedInUser.UserId
            };

            var result = await _signalRClient.SendMessage(ApiConstants.SignalRMethod_SendMessage, chatMessage.ToDynamic());

            if (!result)
            {
                var realm = RealmService.GetRealm();
                realm.Write(() =>
                {
                    realm.Add(chatMessage);
                });

                messageContent.IsOffline = true;
            }
        }

        private void CacheFiles(Guid chatId, List<Models.FileInfo> files, string purpose)
        {
            try
            {
                using var realm = RealmService.GetRealm();

                realm.Write(() =>
                {
                    foreach (var file in files)
                    {
                        var fileInfoDto = (FileInfoDto)file.ToRealmObject();
                        fileInfoDto.ReportId = chatId;
                        fileInfoDto.Purpose = purpose;
                        realm.Add(fileInfoDto, true);
                    }
                });
            }
            catch (Exception ex)
            {
            }
        }

        private List<ImageContent> FetchCachedFiles(Guid chatId, MessageContent messageContent)
        {
            List<ImageContent> filesToReturn = null;

            try
            {
                using var realm = RealmService.GetRealm();

                var files = realm.All<FileInfoDto>().Where((r) => r.ReportId == chatId).ToList();

                foreach (var file in files)
                {
                    if (filesToReturn == null)
                        filesToReturn = new List<ImageContent>();

                    filesToReturn.Add(new ImageContent
                    {
                        Image = FileImageSource.FromFile(file.ImageSource),
                        FullName = messageContent.FullName,
                        DateTime = messageContent.DateTime
                    });
                }
            }
            catch (Exception ex)
            {
            }

            return filesToReturn;
        }

        private void OpenFile(ImageContent imageContent)
        {
            NavigationService.PushModalAsync(new ImageViewerView(imageContent.Image));
        }

        #endregion
    }
}
