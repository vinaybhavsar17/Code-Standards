﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Chat;
using OfficerReports.Services.Chat;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.Chat;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.Chat
{
    public class ChatGroupsViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IMessagingService _messagingService;
        private IUserService _userService;
        private ChatGroupsRequest _officerChatGroupsRequest;
        private ChatGroupsRequest _siteChatGroupsRequest;
        private ChatGroupsResult _officerChatGroupsResult;
        private ChatGroupsResult _siteChatGroupsResult;
        private const int _pageSize = 25;

        #endregion


        #region Bindable Properties

        private ObservableCollection<ChatGroup> _officerChatGroups;
        public ObservableCollection<ChatGroup> OfficerChatGroups
        {
            get { return _officerChatGroups; }
            set
            {
                _officerChatGroups = value;
                RaisePropertyChanged(() => OfficerChatGroups);
            }
        }

        private ObservableCollection<ChatGroup> _siteChatGroups;
        public ObservableCollection<ChatGroup> SiteChatGroups
        {
            get { return _siteChatGroups; }
            set
            {
                _siteChatGroups = value;
                RaisePropertyChanged(() => SiteChatGroups);
            }
        }

        private bool _isOfficerChatGroupsBusy;
        public bool IsOfficerChatGroupsBusy
        {
            get { return _isOfficerChatGroupsBusy; }
            set
            {
                _isOfficerChatGroupsBusy = value;
                RaisePropertyChanged(() => IsOfficerChatGroupsBusy);
            }
        }

        private bool _isSiteChatGroupsBusy;
        public bool IsSiteChatGroupsBusy
        {
            get { return _isSiteChatGroupsBusy; }
            set
            {
                _isSiteChatGroupsBusy = value;
                RaisePropertyChanged(() => IsSiteChatGroupsBusy);
            }
        }

        private UnreadMessageCount _unreadMessageCount;
        public UnreadMessageCount UnreadMessageCount
        {
            get { return _unreadMessageCount; }
            set
            {
                _unreadMessageCount = value;
                OnPropertyChanged(nameof(UnreadMessageCount));
            }
        }

        #endregion


        #region Commands

        public ICommand LoadMoreOfficerChatGroupsCommand => new Command(() => LoadMoreOfficerChatGroups());

        public ICommand LoadMoreSiteChatGroupsCommand => new Command(() => LoadMoreSiteChatGroups());

        public ICommand OpenChatMessageViewCommand => new Command<ChatGroup>((chatGroup) => OpenChatMessageView(chatGroup));

        #endregion


        #region Constructors

        public ChatGroupsViewModel(IMessagingService messagingService, IUserService userService)
        {
            _messagingService = messagingService;
            _userService = userService;
        }

        #endregion

        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            GetOfficerChatGroups();
            GetSiteChatGroups();

            MessagingCenter.Subscribe<SiteMenuViewModel, UnreadMessageCount>(this, AppConstants.MessageCountUpdate, (sender, unreadMessageCount) =>
            {
                UnreadMessageCount = unreadMessageCount;

                UpdateGroupsMessageCount();
            });

            return base.InitializeAsync(query);
        }

        public override void OnDestroy()
        {
            base.OnDestroy();

            MessagingCenter.Unsubscribe<SiteMenuViewModel, UnreadMessageCount>(this, AppConstants.MessageCountUpdate);
        }

        #endregion

        #region Private Methods

        private void GetOfficerChatGroups()
        {
            var user = _userService.GetLoggedInUserInfo();

            _officerChatGroupsRequest = new ChatGroupsRequest
            {
                UserId = user.UserId,
                CurrentTimeZone = TimeZoneInfo.Local.Id,
                GridFilters = new Paging
                {
                    First = 0,
                    Rows = _pageSize,
                    SortOrder = Paging.SortOrderDescending,
                    SortField = String.Empty
                }
            };

            CallApi(

                apiMethod: async () => await _messagingService.GetChatGroups(_officerChatGroupsRequest),

                onSuccess: (response) =>
                {
                    _officerChatGroupsResult = (ChatGroupsResult)response.ProcessedData;
                    OfficerChatGroups = new ObservableCollection<ChatGroup>(_officerChatGroupsResult.Records);
                }

            );
        }

        private void LoadMoreOfficerChatGroups()
        {
            if (IsOfficerChatGroupsBusy)
                return;

            if (OfficerChatGroups.Count >= _officerChatGroupsResult.Count)
                return;

            _officerChatGroupsRequest.GridFilters.First = OfficerChatGroups.Count;

            IsOfficerChatGroupsBusy = true;
            CallApi(

               apiMethod: async () => await _messagingService.GetChatGroups(_officerChatGroupsRequest),

               onSuccess: (response) => {
                   var result = (ChatGroupsResult)response.ProcessedData;

                   foreach (var record in result.Records)
                   {
                       OfficerChatGroups.Add(record);
                   }

                   IsOfficerChatGroupsBusy = false;
               },

               isBackground: true,

               onFailure: () =>
               {
                   IsOfficerChatGroupsBusy = false;
               }
            );
        }

        private void GetSiteChatGroups()
        {
            var user = _userService.GetLoggedInUserInfo();

            _siteChatGroupsRequest = new ChatGroupsRequest
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                CurrentTimeZone = TimeZoneInfo.Local.Id,
                GridFilters = new Paging
                {
                    First = 0,
                    Rows = _pageSize,
                    SortOrder = Paging.SortOrderDescending,
                    SortField = String.Empty
                }
            };

            CallApi(

                apiMethod: async () => await _messagingService.GetChatGroups(_siteChatGroupsRequest),

                onSuccess: (response) =>
                {
                    _siteChatGroupsResult = (ChatGroupsResult)response.ProcessedData;
                    SiteChatGroups = new ObservableCollection<ChatGroup>(_siteChatGroupsResult.Records);
                },

                isBackground: true

            );
        }

        private void LoadMoreSiteChatGroups()
        {
            if (IsSiteChatGroupsBusy)
                return;

            if (SiteChatGroups.Count >= _siteChatGroupsResult.Count)
                return;

            _siteChatGroupsRequest.GridFilters.First = SiteChatGroups.Count;

            IsSiteChatGroupsBusy = true;
            CallApi(

               apiMethod: async () => await _messagingService.GetChatGroups(_siteChatGroupsRequest),

               onSuccess: (response) => {
                   var result = (ChatGroupsResult)response.ProcessedData;

                   foreach (var record in result.Records)
                   {
                       SiteChatGroups.Add(record);
                   }

                   IsSiteChatGroupsBusy = false;
               },

               isBackground: true,

               onFailure: () =>
               {
                   IsSiteChatGroupsBusy = false;
               }
            );
        }

        private void OpenChatMessageView(ChatGroup chatGroup)
        {
            NavigationService.PushAsync(new ChatMessageView(chatGroup));
        }

        private void UpdateGroupsMessageCount()
        {
            if(UnreadMessageCount.OfficerUnreadMessagesCount > 0 || UnreadMessageCount.SiteUnreadMessagesCount > 0)
            {
                foreach (var group in UnreadMessageCount.GroupMessagesCount)
                {
                    ChatGroup groupToUpdate = null;

                    if (UnreadMessageCount.OfficerUnreadMessagesCount > 0)
                        groupToUpdate = OfficerChatGroups.Where((g) => g.GroupId == group.GroupId).FirstOrDefault();
                    else if (UnreadMessageCount.SiteUnreadMessagesCount > 0)
                        groupToUpdate = SiteChatGroups.Where((g) => g.GroupId == group.GroupId).FirstOrDefault();

                    if (groupToUpdate != null)
                        groupToUpdate.Msgcount = group.Count;
                }
            }
        }

        //This method is invoked when user switches between officer groups and site groups tab
        public void ChatGroupSwitched(int index)
        {
        }

        #endregion
    }
}
