﻿using OfficerReports.ApiClient;
using OfficerReports.Models.Site;
using OfficerReports.Models.SOS;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Asot;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.SOS;
using OfficerReports.Models.Authentication;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using OfficerReports.Views.Chat;
using OfficerReports.Views.ClockInOut;
using OfficerReports.Views.DailyActivityReport;
using OfficerReports.Views.FieldInspection;
using OfficerReports.Views.Incident;
using OfficerReports.Views.MaintenanceReport;
using OfficerReports.Views.ParkingViolation;
using OfficerReports.Views.PassOnLog;
using OfficerReports.Views.PostOrder;
using OfficerReports.Views.Site;
using OfficerReports.Views.SiteCheckReport;
using OfficerReports.Views.TemperatureLog;
using OfficerReports.Views.TourTracker;
using OfficerReports.Views.TruckCheckInOut;
using OfficerReports.Views.VisitorCheckInOut;
using System.Windows.Input;
using OfficerReports.Views.Scheduler;
using OfficerReports.Services.Authentication;
using OfficerReports.Helpers;
using OfficerReports.Views.PolicyManual;
using OfficerReports.Views.Vacation;
using System.Collections.ObjectModel;
using OfficerReports.Constants;
using OfficerReports.Services.Site;
using OfficerReports.Models.Chat;
using OfficerReports.ViewModels.Chat;
using OfficerReports.Services.Base;

namespace OfficerReports.ViewModels
{
    public class SiteMenuViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private ILocationService _locationService;
        private IAuthenticationService _authenticationService;
        private ISosService _sosService;
        private ISignalRClient _signalRClient;
        private IAsotService _asotService;
        private ISiteService _siteService;
        private static bool _susbcribedMessageCenter;

        public static ClientSite Site { get; private set; }

        #endregion Internal Variables/Constants

        #region Bindable Properties

        private bool _showSiteCheckOption;

        public bool ShowSiteCheckOption
        {
            get { return _showSiteCheckOption; }
            set
            {
                _showSiteCheckOption = value;
                RaisePropertyChanged(() => ShowSiteCheckOption);
            }
        }

        private bool _showFieldInspectionOption;
        public bool ShowFieldInspectionOption
        {
            get { return _showFieldInspectionOption; }
            set
            {
                _showFieldInspectionOption = value;
                RaisePropertyChanged(() => ShowFieldInspectionOption);
            }
        }

        private ObservableCollection<SiteMenuItem> _customReports;
        public ObservableCollection<SiteMenuItem> CustomReports
        {
            get { return _customReports; }
            set
            {
                _customReports = value;
                OnPropertyChanged(nameof(CustomReports));
            }
        }

        private UnreadMessageCount _unreadMessageCount;
        public UnreadMessageCount UnreadMessageCount
        {
            get { return _unreadMessageCount; }
            set
            {
                _unreadMessageCount = value;
                OnPropertyChanged(nameof(UnreadMessageCount));
            }
        }

        #endregion



        #region Constructors

        public SiteMenuViewModel(
            ILocationService locationService,
            IAuthenticationService authenticationService,
            ISignalRClient signalRClient,
            ISosService sosService,
            IAsotService asotService,
            ISiteService siteService)
        {
            _locationService = locationService;
            _authenticationService = authenticationService;
            _signalRClient = signalRClient;
            _asotService = asotService;
            _sosService = sosService;
            _siteService = siteService;
        }

        #endregion Constructors

        #region Commands

        public ICommand ClockInOutCommand => new Command(() => OpenClockInOutPage());

        public ICommand ViewSchedulerCommand => new Command(() => OpenSchedulerPage());

        public ICommand DailyActivityReportCommand => new Command(() => OpenDailyActivityReportPage());

        public ICommand IncidentReportCommand => new Command(() => OpenIncidentReportPage());

        public ICommand SiteCheckReportCommand => new Command(() => OpenSiteCheckReportPage());

        public ICommand FieldInspectionCommand => new Command(() => OpenFieldInspectionPage());

        public ICommand MaintenanceReportCommand => new Command(() => OpenMaintenanceReportPage());

        public ICommand ParkingViolationReportCommand => new Command(() => OpenParkingViolationReportPage());

        public ICommand IncidentChecklistCommand => new Command(() => OpenIncidentChecklistPage());

        public ICommand ParkingViolationSearchCommand => new Command(() => OpenParkingViolationSearchPage());

        public ICommand PassOnLogWriteCommand => new Command(() => OpenPassOnLogWritePage());

        public ICommand PostOrderCommand => new Command(() => OpenPostOrderPage());

        public ICommand TourTrackerCommand => new Command(() => OpenTourTrackerPage());

        public ICommand PassOnLogReadCommand => new Command(() => OpenPassOnLogReadPage());

        public ICommand TemperatureLogCommand => new Command(() => OpenTemperatureLogPage());

        public ICommand SignOutCommand => new Command(() => SignOut());

        public ICommand VisitorCheckOutLogCommand => new Command(() => OpenVisitorCheckOutLogPage());

        public ICommand VisitorCheckInCommand => new Command(() => OpenVisitorCheckInPage());

        public ICommand TruckCheckInCommand => new Command(() => OpenTruckCheckInPage());

        public ICommand TruckCheckOutCommand => new Command(() => OpenTruckCheckOutPage());

        public ICommand PolicyManualCommand => new Command(() => OpenPolicyManualPage());

        public ICommand VacationRequestCommand => new Command(() => OpenVacationRequestPage());

        public ICommand VacationReviewCommand => new Command(() => OpenVacationReviewPage());

        public ICommand SwitchSiteCommand => new Command(() => OpenSiteListViewPage());

        public ICommand ChatCommand => new Command(() => OpenChatGroupsPage());

        public ICommand AsotLogCommand => new Command(() => OpenAsotLogPage());

        public ICommand SosAlertCommand => new Command(() => SendSosAlert());

        public ICommand CustomReportCommand => new Command<SiteMenuItem>((customReportRecord) => OpenCustomReportPage(customReportRecord));

        #endregion Commands

        #region Overriden Methods

        public override async Task InitializeAsync(IDictionary<string, object> query)
        {
            ShowSiteCheckOption = MenuViewModel.LoggedInUser.MobilePetrolEnabled;
            ShowFieldInspectionOption = MenuViewModel.LoggedInUser.RoleName == Models.Authentication.User.SupervisorRole || MenuViewModel.LoggedInUser.RoleName == Models.Authentication.User.CustomerRole;

            Dispatcher.DispatchDelayed(TimeSpan.FromMilliseconds(500), async() =>
            {
                _locationService.StartLocationTracking(); //This will start tracking user's location and broadcast a message via messaging center. You an subscribe to receive updates.

                _signalRClient.Connect(() =>
                {
                    RegisterChatNotifications();
                }); //This is a multi purpose signalR client and should be used for any signalR related work through out the app. Do not attempt to connect it again. Currently we are connecting it when user selects a site and disconnecting when user logs out.

                _asotService.Init(_signalRClient); // This will listen for location updates via messaging center and send a message via signalR when there is an update.

                GetCustomReports();

                if (!AuthTokenManager.IsMimic)
                {
                    await SubmitSigninLog();
                }
            });

            await base.InitializeAsync(query);
            return;
        }

        public override void OnDestroy()
        {
            base.OnDestroy();

            MessagingCenter.Unsubscribe<ISignalRClient, string>(this, AppConstants.MessageNewChat);
            _susbcribedMessageCenter = false;
        }

        public override void OnAppearing()
        {
            base.OnAppearing();

            if (!_susbcribedMessageCenter)
            {
                MessagingCenter.Subscribe<ISignalRClient, string>(this, AppConstants.MessageNewChat, async (sender, message) =>
                {
                    GetUnreadNotificationsCount();
                });

                _susbcribedMessageCenter = true;
            }

            GetUnreadNotificationsCount();

            GetMasterData();
        }

        #endregion Overriden Methods

        #region Private Methods

        private void GetMasterData()
        {
            var isMasterDataCached = (_siteService as ApiBaseService).IsDataCached<MasterDataDto>();

            CallApi(

                apiMethod: async () => await _siteService.GetAllReportsMasterData(Site.ClientSiteId),

                onSuccess: (response) =>
                {
                    
                },

                isBackground: isMasterDataCached

            );
        }

        private async Task SubmitSigninLog()
        {
            var location = await _locationService.GetCurrentLocation();
            if (location == null)
                return;

            var signinLog = new SigninLog
            {
                ClientSiteId = Site.ClientSiteId,
                Latitude = location.Latitude,
                Longitude = location.Longitude,
                IsSignin = true,
                IsTourTracker = MenuViewModel.LoggedInUser.TourTrackingEnabled,
                DeviceInfo = DeviceInfo.Platform.ToString(),
                DeviceType = "mobile",
                TourTrackerVersion = "string"
            };
            CallApi
            (
                apiMethod: async () => await _authenticationService.SubmitSigninLog(signinLog),

                onSuccess: (response) =>
                {
                },

                isBackground: true
            );
        }

        private void OpenClockInOutPage()
        {
            NavigationService.PushAsync(new ClockInOutView());
        }

        private void OpenSchedulerPage()
        {
            NavigationService.PushAsync(new SchedulerView());
        }

        private void OpenDailyActivityReportPage()
        {
            NavigationService.PushAsync(new DailyActivityReportView());
        }

        private void OpenIncidentReportPage()
        {
            NavigationService.PushAsync(new IncidentReportView());
        }

        private void OpenFieldInspectionPage()
        {
            CheckUserLocationAndPushOnFieldInspection();
        }

        private void OpenMaintenanceReportPage()
        {
            NavigationService.PushAsync(new MaintenanceReportView());
        }

        private void OpenParkingViolationReportPage()
        {
            NavigationService.PushAsync(new ParkingViolationReportView());
        }

        private void OpenIncidentChecklistPage()
        {
            NavigationService.PushAsync(new IncidentChecklistView());
        }

        private void OpenParkingViolationSearchPage()
        {
            NavigationService.PushAsync(new ParkingViolationSearchView());
        }

        private void OpenPassOnLogWritePage()
        {
            NavigationService.PushAsync(new PassOnLogWriteView());
        }

        private void OpenPassOnLogReadPage()
        {
            NavigationService.PushAsync(new PassOnLogReadView());
        }

        private void OpenPostOrderPage()
        {
            NavigationService.PushAsync(new PostOrderView());
        }

        private void OpenTourTrackerPage()
        {
            NavigationService.PushAsync(new TourTrackerView());
        }

        private void OpenTemperatureLogPage()
        {
            NavigationService.PushAsync(new TemperatureLogView());
        }

        private void OpenVisitorCheckOutLogPage()
        {
            NavigationService.PushAsync(new VisitorCheckOutView());
        }

        private void OpenVisitorCheckInPage()
        {
            NavigationService.PushAsync(new VisitorCheckInView());
        }

        private void OpenTruckCheckInPage()
        {
            NavigationService.PushAsync(new TruckCheckInView());
        }

        private void OpenTruckCheckOutPage()
        {
            NavigationService.PushAsync(new TruckCheckOutView());
        }

        private void OpenPolicyManualPage()
        {
            NavigationService.PushAsync(new PolicyManualView());
        }

        private void OpenVacationRequestPage()
        {
            NavigationService.PushAsync(new VacationRequestView());
        }

        private void OpenVacationReviewPage()
        {
            NavigationService.PushAsync(new VacationReviewView());
        }

        private void OpenSiteListViewPage()
        {
            NavigationService.PushAsync(new SiteListView());
        }

        private void OpenChatGroupsPage()
        {
            NavigationService.PushAsync(new ChatGroupsView(UnreadMessageCount));
        }

        private void OpenAsotLogPage()
        {
            NavigationService.PushAsync(new AsotLogView());
        }

        private void OpenSiteCheckReportPage()
        {
            NavigationService.PushAsync(new SiteCheckReportView());
        }

        private void OpenCustomReportPage(SiteMenuItem customerReportRecord)
        {
            NavigationService.PushAsync(new CustomReportView(customerReportRecord));
        }

        private async void CheckUserLocationAndPushOnFieldInspection()
        {
            DialogService.ShowLoading(); //This loader will get closed after fetching location and field inspection officer list on field inspection view model.

            var userLocation = await _locationService.GetCurrentLocation();

            if (userLocation != null)
            {
                await NavigationService.PushAsync(new FieldInspectionView(userLocation));
            }
            else
            {
                DialogService.HideLoading();
            }
        }

        private void SignOut()
        {
            MenuViewModel.SignOut(this);
        }

        private async void SendSosAlert()
        {
            var userLocation = await _locationService.GetCurrentLocation(isBackground: false);
            if (userLocation != null)
            {
                var sosRequest = new SosAlertRequest()
                {
                    Latitude = userLocation.Latitude,
                    Longitude = userLocation.Longitude,
                    ClientSiteId = Site.ClientSiteId
                };

                CallApi(
                    apiMethod: async () => await _sosService.SendSOSAlert(sosRequest),
                    onSuccess: (response) =>
                    {
                        DialogService.ShowMessage(AppResource.Success, AppResource.Sos_Alert_Sent);
                    }
                );
            }
        }

        private void GetCustomReports()
        {
            CallApi(

               apiMethod: async () => await _siteService.GetSiteMenu(),

               onSuccess: (response) => {
                   var siteMenuItems = (List<SiteMenuItem>)response.ProcessedData;
                   var customReportRecords = siteMenuItems.Where((r) => r.Category == AppConstants.SiteMenuCustomReport).ToList();
                   CustomReports = new ObservableCollection<SiteMenuItem>(customReportRecords);
               },

               isBackground: true
            );
        }

        private void GetUnreadNotificationsCount()
        {
            CallApi(

               apiMethod: async () => await _siteService.GetUnreadNotificationsCount(),

               onSuccess: (response) => {
                   UnreadMessageCount = (UnreadMessageCount)response.ProcessedData;

                   MessagingCenter.Send<SiteMenuViewModel, UnreadMessageCount>(this, AppConstants.MessageCountUpdate, UnreadMessageCount);
               },

               isBackground: true
            );
        }

        private void RegisterChatNotifications()
        {
            _signalRClient.SendMessage(ApiConstants.SignalRMethod_JoinGroup, MenuViewModel.LoggedInUser.CustomerId.ToString(), "");
        }

        #endregion Private Methods

        #region Public Methods

        public void SetSite(ClientSite site)
        {
            Site = site;
        }

        #endregion Public Methods
    }
}