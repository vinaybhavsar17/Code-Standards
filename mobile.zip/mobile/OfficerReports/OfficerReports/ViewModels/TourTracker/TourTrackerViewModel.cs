﻿using OfficerReports.Constants;
using OfficerReports.Helpers;
using OfficerReports.Models.TourTracker;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.TourTracker;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.BarcodeScanner;
using OfficerReports.Views.TourTracker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.TourTracker
{
    public class TourTrackerViewModel : ViewModelBase
    {

        #region Internal Variables/Constants

        private ITourTrackerService _tourTrackerService;
        private ILocationService _locationService;
        private List<PreviousScan> _previousScans;

        #endregion


        #region Bindable Properties

        private string _connectionType;
        public string ConnectionType
        {
            get { return _connectionType; }
            set
            {
                _connectionType = value;
                OnPropertyChanged(nameof(ConnectionType));
            }
        }

        private PreviousScan _lastScan;
        public PreviousScan LastScan
        {
            get { return _lastScan; }
            set
            {
                _lastScan = value;
                OnPropertyChanged(nameof(LastScan));
            }
        }

        #endregion


        #region Constructors

        #endregion


        #region Commands

        public ICommand ScanQrCodeCommand => new Command(() => OpenQRCodeScanner());

        public ICommand PreviousScansCommand => new Command(() => OpenPreviousScansPage());

        #endregion


        #region Constructors

        public TourTrackerViewModel(ITourTrackerService tourTrackerService, ILocationService locationService)
        {
            _tourTrackerService = tourTrackerService;
            _locationService = locationService;
        }

        #endregion


        #region Overriden Methods

        public override async Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Tour_Tracker;

            ConnectionType = await NetworkUtility.GetConnectionType();

            GetPreviousScans();

            await base.InitializeAsync(query);
            return;
        }

        public override void OnAppearing()
        {
            base.OnAppearing();

            Connectivity.ConnectivityChanged += InternetConnectivityChanged;
        }

        public override void OnDisappearing()
        {
            base.OnDisappearing();

            Connectivity.ConnectivityChanged -= InternetConnectivityChanged;
        }

        #endregion


        #region Private Methods

        private void GetPreviousScans(bool isBackground = false)
        {
            if (isBackground)
                IsBusy = true;

            CallApi(
                apiMethod: async () => await _tourTrackerService.GetPreviousScans(),

                onSuccess: (response) =>
                {
                    _previousScans = response.ProcessedData as List<PreviousScan>;

                    LastScan = _previousScans?.FirstOrDefault();

                    IsBusy = false;
                },

                isBackground: isBackground
            );
        }

        private void OpenQRCodeScanner()
        {
            var barcodeScannerView = new BarcodeScannerView();
            barcodeScannerView.OnBarcodeScanned += async(s, e) =>
            {
                await NavigationService.PopModalAsync();

                try
                {
                    var scannedDataElements = e.Value.Split("|");
                    var tourStopId = int.Parse(scannedDataElements[1]);

                    if (scannedDataElements[0].Equals(AppConstants.QrCodeIdentifier))
                        SubmitTourScan(tourStopId);
                    else
                        DialogService.ShowMessage(AppResource.Alert, AppResource.Invalid_Qr_Code);
                }
                catch (Exception)
                {
                    DialogService.ShowMessage(AppResource.Alert, AppResource.Invalid_Qr_Code);
                }
            };
            NavigationService.PushModalAsync(barcodeScannerView);
        }

        private void SubmitTourScan(int tourStopId)
        {
            var tourStopScan = new TourStopScan
            {
                SiteTourStopId = tourStopId,
                TourStopTypeId = 1,
                ScanDate = DateTime.Now.ToString("O"),
                DeviceInfo = DeviceInfo.Platform.ToString(),
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId
            };

            CallApi(
                apiMethod: async () => await _tourTrackerService.SubmitTourStopScan(tourStopScan),

                onSuccess: (response) =>
                {
                    if (response.IsCached)
                    {
                        DialogService.ShowMessage(AppResource.Success, response.Message);
                    }
                    else
                    {
                        var tourStop = response.ProcessedData as TourStop;

                        var message = $"{AppResource.Successfully_Scanned}: {tourStop.TourStopName}\n\n{tourStop.Description}";
                        DialogService.ShowMessage(AppResource.Scan_Saved, message);

                        GetPreviousScans(isBackground: true);
                    }
                }
            );
        }

        private void OpenPreviousScansPage()
        {
            NavigationService.PushAsync(new PreviousScansView(_previousScans));
        }

        private async void InternetConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            ConnectionType = await NetworkUtility.GetConnectionType();
        }

        #endregion


        #region Public Methods

        #endregion

    }
}
