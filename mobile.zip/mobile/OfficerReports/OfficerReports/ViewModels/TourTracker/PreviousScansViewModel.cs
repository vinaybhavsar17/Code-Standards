﻿using OfficerReports.Models.TourTracker;
using OfficerReports.Resources.Strings;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ViewModels.TourTracker
{
    public class PreviousScansViewModel : ViewModelBase
    {
        #region Bindable Properties

        private ObservableCollection<PreviousScan> _previousScans;
        public ObservableCollection<PreviousScan> PreviousScans
        {
            get { return _previousScans; }
            set
            {
                _previousScans = value;
                OnPropertyChanged(nameof(PreviousScans));
            }
        }

        #endregion

        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Previous_Scans;

            return base.InitializeAsync(query);
        }

        #endregion
    }
}
