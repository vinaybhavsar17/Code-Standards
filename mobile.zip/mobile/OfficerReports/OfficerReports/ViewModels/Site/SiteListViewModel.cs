﻿using OfficerReports.Constants;
using OfficerReports.Helpers;
using OfficerReports.Interfaces;
using OfficerReports.Models.Authentication;
using OfficerReports.Models.Base;
using OfficerReports.Models.Site;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.Site;
using OfficerReports.Services.User;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.Site
{
    public class SiteListViewModel : ViewModelBase
    {

        #region Internal Variables/Constants

        private ISiteService _siteService;
        private IUserService _userService;

        #endregion


        #region Bindable Properties

        private ObservableCollection<ClientSite> _sites;
        public ObservableCollection<ClientSite> Sites
        {
            get { return _sites; }
            set {
                _sites = value; 
                RaisePropertyChanged(() => Sites);
            }

        }

        #endregion


        #region Commands

        public ICommand SelectSiteCommand => new Command<ClientSite>((site) => SelectSite(site));

        #endregion


        #region Constructor

        public SiteListViewModel(ISiteService siteService, IUserService userService)
        {
            _siteService = siteService;
            _userService = userService;
        }

        #endregion


        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Select_Site;
            ShowSites();
            return base.InitializeAsync(query);
        }

        public override void OnResume()
        {
            base.OnResume();

            if(Sites == null)
                ShowSites();
        }

        #endregion


        #region Private Method

        private void ShowSites() {
           
            var user = _userService.GetLoggedInUserInfo();

            if (user.RoleName == Models.Authentication.User.OfficerRole)
            {
                GetSitesInRange();
            }
            else
            {
                GetAllSites();
            }
        }


        private void GetSitesInRange() 
        {
            CallApi(

                apiMethod: async () => await _siteService.GetSitesInRange(),

                onSuccess: (response) => 
                { 
                    OnSiteListReceived(response);
                }
             );
        }

        private void GetAllSites()
        {
            CallApi(

                apiMethod: async () => await _siteService.GetAllSites(),

                onSuccess: (response) =>
                {
                    OnSiteListReceived(response);
                }

            );
        }

        private void OnSiteListReceived(ApiResponse response)
        {
            var list = (List<ClientSite>)response.ProcessedData;
            Sites = new ObservableCollection<ClientSite>(list);
        }

        private void SelectSite(ClientSite site)
        {
            ReportCacheManager.ClearAllData();
            NavigationService.PushToRoot(new SiteMenuView(site));
        }

        #endregion


        #region Public Methods

        #endregion

    }
}
