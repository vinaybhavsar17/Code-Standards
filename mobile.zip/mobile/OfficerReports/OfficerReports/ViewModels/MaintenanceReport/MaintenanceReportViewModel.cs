﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.MaintenanceReport;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Base;
using OfficerReports.Services.MaintenanceReport;
using OfficerReports.Services.Storage;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.MaintenanceReport
{
    public class MaintenanceReportViewModel : ViewModelBase
    {

        #region Internal Variables/Constants
        private IUserService _userService;
        private IAzureStorageService _azureStorageService;
        private IMaintenanceReportService _maintenanceRequestReportService;

        private int _clientSideID;
        private int _userID;
        #endregion


        #region Bindable Properties

        private string _officer;
        public string Officer
        {
            get { return _officer; }
            set
            {
                _officer = value;
                RaisePropertyChanged(() => Officer);
            }
        }

        private string _client;
        public string Client
        {
            get { return _client; }
            set
            {
                _client = value;
                RaisePropertyChanged(() => Client);
            }
        }

        private string _site;
        public string Site
        {
            get { return _site; }
            set
            {
                _site = value;
                RaisePropertyChanged(() => Site);
            }
        }

        private ObservableCollection<MaintenanceTypeItem> _maintenanceTypes;
        public ObservableCollection<MaintenanceTypeItem> MaintenanceTypes
        {
            get { return _maintenanceTypes; }
            set
            {
                _maintenanceTypes = value;
                OnPropertyChanged(nameof(MaintenanceTypes));
            }
        }

        private MaintenanceTypeItem _selectedMaintenanceType;
        public MaintenanceTypeItem SelectedMaintenanceType
        {
            get { return _selectedMaintenanceType; }
            set
            {
                _selectedMaintenanceType = value;
                if (value != null)
                {
                    if (_selectedMaintenanceType.TypeDataName == AppConstants.MaintenanceTypeOther)
                    {
                        OtherMaintenanceTypeFieldIsEnabled = true;
                    }
                    else {
                        IfMaintenanceTypeNotInListThenWhatType = string.Empty;
                        OtherMaintenanceTypeFieldIsEnabled = false;

                    }
                }
                
                OnPropertyChanged(nameof(SelectedMaintenanceType));
            }
        }

        private bool _otherMaintenanceTypeFieldIsEnabled;
        public bool OtherMaintenanceTypeFieldIsEnabled
        {
            get { return _otherMaintenanceTypeFieldIsEnabled; }
            set
            {
                _otherMaintenanceTypeFieldIsEnabled = value;
                OnPropertyChanged(nameof(OtherMaintenanceTypeFieldIsEnabled));
            }
        }


        private ObservableCollection<string> _emailClientYesOrNo;
        public ObservableCollection<string> EmailClientYesOrNo
        {
            get { return _emailClientYesOrNo; }
            set
            {
                _emailClientYesOrNo = value;
                OnPropertyChanged(nameof(EmailClientYesOrNo));
            }
        }

        private int _selectedItemIndexEmailClient;
        public int SelectedItemIndexEmailClient
        {
            get { return _selectedItemIndexEmailClient; }
            set
            {
                _selectedItemIndexEmailClient = value;
                OnPropertyChanged(nameof(SelectedItemIndexEmailClient));
            }
        }

        private string _selectedItemEmailClient;
        public string SelectedItemEmailClient
        {
            get { return _selectedItemEmailClient; }
            set
            {
                _selectedItemEmailClient = value;
                OnPropertyChanged(nameof(SelectedItemEmailClient));
            }
        }

        private string _emailClient;
        public string EmailClient
        {
            get { return _emailClient; }
            set
            {
                _emailClient = value;
                RaisePropertyChanged(() => EmailClient);
            }
        }

        private string _ifMaintenanceTypeNotInListThenWhatType;
        public string IfMaintenanceTypeNotInListThenWhatType
        {
            get { return _ifMaintenanceTypeNotInListThenWhatType; }
            set
            {
                _ifMaintenanceTypeNotInListThenWhatType = value;
                RaisePropertyChanged(() => IfMaintenanceTypeNotInListThenWhatType);
            }
        }

        private string _details;
        public string Details
        {
            get { return _details; }
            set
            {
                _details = value;
                RaisePropertyChanged(() => Details);
            }
        }

        private string _whoHasBeenNotified;
        public string WhoHasBeenNotified
        {
            get { return _whoHasBeenNotified; }
            set
            {
                _whoHasBeenNotified = value;
                RaisePropertyChanged(() => WhoHasBeenNotified);
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }

        #endregion


        #region Commands

        public ICommand SubmitCommand => new Command(() => SubmitForm());
        public ICommand ClearCommand => new Command(() => ClearForm());

        #endregion

        #region Constructor

        public MaintenanceReportViewModel(
            IUserService userService,
            IAzureStorageService azureStorageService,
            IMaintenanceReportService maintenanceRequestReportService
        )
        {
            _userService = userService;
            _azureStorageService = azureStorageService;
            _maintenanceRequestReportService = maintenanceRequestReportService;
        }

        #endregion


        #region  Override Methods
        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Maintenance_Request;
            LoadData();
            GetMaintenanceTypes();
            return base.InitializeAsync(query);
        }

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(MaintenanceTypes));
            Validator.AddField(nameof(EmailClient));
            Validator.AddField(nameof(Details));
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            var selectedMaintenanceType = GetCachedProperty<MaintenanceTypeItem>(nameof(SelectedMaintenanceType), data, ref isCachedFromPreviousSession);
            if (selectedMaintenanceType != null && MaintenanceTypes != null)
            {
                SelectedMaintenanceType = MaintenanceTypes.Where(o => o.TypeDataId == selectedMaintenanceType.TypeDataId).FirstOrDefault();
            }

            IfMaintenanceTypeNotInListThenWhatType = GetCachedProperty<string>(nameof(IfMaintenanceTypeNotInListThenWhatType), data, ref isCachedFromPreviousSession);
            Details = GetCachedProperty<string>(nameof(Details), data, ref isCachedFromPreviousSession);
            WhoHasBeenNotified = GetCachedProperty<string>(nameof(WhoHasBeenNotified), data, ref isCachedFromPreviousSession);
            SelectedItemEmailClient = GetCachedProperty<string>(nameof(SelectedItemEmailClient), data, ref isCachedFromPreviousSession);
            Files = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(Files), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        #endregion

        #region Private Methods

        private void LoadData()
        {
            var user = _userService.GetLoggedInUserInfo();
            Officer = user.FullName;
            _userID = user.UserId;
            _clientSideID = SiteMenuViewModel.Site.ClientSiteId;
            Site = SiteMenuViewModel.Site.SiteName;
            Client = SiteMenuViewModel.Site.ClientName;

            var list = new List<string>
            {
              AppResource.No,
              AppResource.Yes
             };

            EmailClientYesOrNo = new ObservableCollection<string>(list);
        }

        private void GetMaintenanceTypes()
        {
            CallApi(

               apiMethod: async () => await _maintenanceRequestReportService.GetMaintenanceTypes(),

               onSuccess: (response) => {
                   var result = response.ProcessedData;
                   MaintenanceType objectList = result as MaintenanceType;
                   var data = objectList.Data;
                   var list = (List<MaintenanceTypeItem>)data;
                   MaintenanceTypes = new ObservableCollection<MaintenanceTypeItem>(list);

               }
            );
        }


        private void SubmitForm()
        {

            if (!Validator.Validate())
                return;

            var createMaintenanceReportRequest = new CreateMaintenanceReportRequest
            {
                ClientSiteId = _clientSideID.ToString(),
                MaintenanceTypeId = _selectedMaintenanceType.TypeDataId.ToString(),
                TypeIfOther = IfMaintenanceTypeNotInListThenWhatType,
                Details = Details,
                Notification = WhoHasBeenNotified,
                EmailClient = _selectedItemIndexEmailClient.ToString(),
                IsAttachmentAdded = Files != null && Files.Count > 0
            };

            CallApi(
                apiMethod: async () => await _maintenanceRequestReportService.CreateMaintenanceReportRequest(createMaintenanceReportRequest),

                onSuccess: async (response) => {

                    if (Files != null && Files.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_maintenanceRequestReportService).CacheFiles(Files.ToList(), response.CachedDataId, EntityRequest.EntityTypeMaintenanceReport, AppConstants.PurposeReports);
                        }
                        else
                        {
                            var reportId = response.Data.reportId;

                            var request = new EntityRequest
                            {
                                EntityId = reportId,
                                EntityTypeId = EntityRequest.EntityTypeMaintenanceReport
                            };

                            var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, Files.ToList(), request);

                            if (!uploaded)
                            {
                                await NavigationService.PopAsync();
                                DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                return;
                            }
                        }
                    }
                    OnSubmitCompleted(response);
                }
            );

        }

        private async void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Maintenance_Report_Submited);
        }

        private void ClearForm()
        {
            Validator.Reset();

            Details = string.Empty;
            WhoHasBeenNotified = String.Empty;
            IfMaintenanceTypeNotInListThenWhatType = String.Empty;
            SelectedMaintenanceType = null;
            SelectedItemIndexEmailClient = -1;

            Files?.Clear();

            ClearCachedProperties();
        }

            #endregion

        }
}
