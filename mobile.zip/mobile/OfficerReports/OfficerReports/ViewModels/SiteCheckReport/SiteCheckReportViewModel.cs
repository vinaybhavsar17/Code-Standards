﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.SiteCheckReport;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.SiteCheckReport;
using OfficerReports.Services.Storage;
using OfficerReports.Services.User;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels.Base;

namespace OfficerReports.ViewModels.SiteCheckReport
{
    public class SiteCheckReportViewModel : FormPageBaseViewModel
    {
        #region Internal Variables/Constants
        private IUserService _userService;
        private IAzureStorageService _azureStorageService;
        private ISiteCheckReportService _siteCheckReportService;
        #endregion

        #region Bindable Properties
       
        private string _details;
        public string Details
        {
            get { return _details; }
            set
            {
                _details = value;
                RaisePropertyChanged(() => Details);
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }
        #endregion

        #region constructor
        public SiteCheckReportViewModel(IUserService userService, IAzureStorageService azureStorageService, ISiteCheckReportService siteCheckReportService)
        {
            _userService = userService;
            _azureStorageService = azureStorageService;
            _siteCheckReportService = siteCheckReportService;
        }
        #endregion 

        #region override methods
        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            var task = base.InitializeAsync(query);
            HeaderTitle = AppResource.Site_Check_Report;
            return task;
        }

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(Details));
        }
        #endregion

        #region Private Methods
      

        protected override void SubmitForm()
        {
            var createSiteCheckReport = new CreateSiteCheckReport
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                Details = Details,
                ClientId = SiteMenuViewModel.Site.ClientId,
                IsAttachmentAdded = Files != null && Files.Count > 0
            };

            CallApi(
                apiMethod: async () => await _siteCheckReportService.CreateSiteCheckReport(createSiteCheckReport),

                onSuccess: async (response) =>
                {
                    if (Files != null && Files.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_siteCheckReportService).CacheFiles(Files.ToList(), response.CachedDataId, EntityRequest.EntityTypeSiteCheckReport, AppConstants.PurposeReports);
                        }
                        else
                        {
                            var reportId = response.Data.reportId;
                            var request = new EntityRequest
                            {
                                EntityId = reportId,
                                EntityTypeId = EntityRequest.EntityTypeSiteCheckReport
                            };

                            var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, Files.ToList(), request);

                            if (!uploaded)
                            {
                                await NavigationService.PopAsync();
                                DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                return;
                            }
                        }
                    }
                    OnSubmitCompleted(response);
                }
            );
        }

        protected override void ClearForm()
        {
            Details = string.Empty;
            Files?.Clear();
        }

        protected override async void OnSubmitCompleted(ApiResponse response)
        {
            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Site_Check_Report_Submitted);
        }
        #endregion
    }
}
