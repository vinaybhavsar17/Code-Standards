﻿using OfficerReports.Models.PolicyManual;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.PolicyManual;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.PolicyManual;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.PolicyManual
{
    public class PolicyManualViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IPolicyManualService _policyManualService;

        #endregion


        #region Bindable Properties

        private ObservableCollection<PolicyManualGroup> _policyManuals;
        public ObservableCollection<PolicyManualGroup> PolicyManuals
        {
            get { return _policyManuals; }
            set
            {
                _policyManuals = value;
                RaisePropertyChanged(() => PolicyManuals);
            }
        }

        #endregion


        #region Commands

        public ICommand SelectPolicyCommand => new Command<Models.PolicyManual.PolicyManual>((policyManual) => OpenPolicyDetailsPage(policyManual));

        #endregion


        #region Constructors

        public PolicyManualViewModel(IPolicyManualService policyManualService)
        {
            _policyManualService = policyManualService;
        }

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Policy_Manual;

            GetPolicyManual();

            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Methods

        private void GetPolicyManual()
        {
            CallApi(

                apiMethod: async () => await _policyManualService.GetAllPolicyManuals(),

                onSuccess: (response) =>
                {
                    var list = (List<PolicyManualGroup>)response.ProcessedData;
                    PolicyManuals = new ObservableCollection<PolicyManualGroup>(list);
                }

            );
        }

        private void OpenPolicyDetailsPage(Models.PolicyManual.PolicyManual policyManual)
        {
            if (policyManual == null)
                return;

            //SelectedPolicyManual = null;

            NavigationService.PushAsync(new PolicyManualDetailView(policyManual));
        }

        #endregion


        #region Public Methods

        #endregion
    }
}
