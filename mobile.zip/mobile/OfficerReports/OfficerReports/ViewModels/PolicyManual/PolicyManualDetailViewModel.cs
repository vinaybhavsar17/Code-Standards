﻿using OfficerReports.Resources.Strings;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.PolicyManual
{
    public class PolicyManualDetailViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        #endregion


        #region Bindable Properties

        private Models.PolicyManual.PolicyManual _policyManual;
        public Models.PolicyManual.PolicyManual PolicyManual
        {
            get { return _policyManual; }
            set
            {
                _policyManual = value;

                CreationDate = value.CreatedDate;
                Category = value.PolicyManualMainCategory;
                SubCategory = value.PolicyManualSubCategory;
                Title = value.Title;
                Details = value.Details;
                FileName = value.OriginalFileName;

                RaisePropertyChanged(() => PolicyManual);
            }
        }

        private DateTime _creationDate;
        public DateTime CreationDate
        {
            get { return _creationDate; }
            set
            {
                _creationDate = value;
                RaisePropertyChanged(() => CreationDate);
            }
        }
      
        private string _category;
        public string Category
        {
            get { return _category; }
            set
            {
                _category = value;
                RaisePropertyChanged(() => Category);
            }
        }

        private string _subCategory;
        public string SubCategory
        {
            get { return _subCategory; }
            set
            {
                _subCategory = value;
                RaisePropertyChanged(() => SubCategory);
            }
        }

        private string _title;
        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
                RaisePropertyChanged(() => Title);
            }
        }

        private string _details;
        public string Details
        {
            get { return _details; }
            set
            {
                _details = value;
                RaisePropertyChanged(() => Details);
            }
        }

        private string _fileName;
        public string FileName
        {
            get { return _fileName; }
            set
            {
                _fileName = value;
                RaisePropertyChanged(() => FileName);
            }
        }

        #endregion


        #region Commands

        public ICommand OpenFileCommand => new Command(() => OpenFile());

        #endregion


        #region Constructors

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Policy_Manual_Detail;

            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Methods

        private void OpenFile()
        {
            NavigationService.PushAsync(new PdfViewerView(PolicyManual.FileUrl));
        }

        #endregion


        #region Public Methods

        #endregion
    }
}
