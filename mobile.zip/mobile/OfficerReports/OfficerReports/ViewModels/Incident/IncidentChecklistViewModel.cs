﻿using OfficerReports.Models.Incident;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Incident;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ViewModels.Incident
{
    public class IncidentChecklistViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IUserService _userService;
        private IIncidentService _incidentService;

        #endregion


        #region Bindable Properties

        private string _officer;
        public string Officer
        {
            get { return _officer; }
            set
            {
                _officer = value;
                RaisePropertyChanged(() => Officer);
            }
        }

        private string _client;
        public string Client
        {
            get { return _client; }
            set
            {
                _client = value;
                RaisePropertyChanged(() => Client);
            }
        }

        private string _site;
        public string Site
        {
            get { return _site; }
            set
            {
                _site = value;
                RaisePropertyChanged(() => Site);
            }
        }

        private ObservableCollection<IncidentChecklistGroup> _incidentsChecklist;
        public ObservableCollection<IncidentChecklistGroup> IncidentsChecklist
        {
            get { return _incidentsChecklist; }
            set
            {
                _incidentsChecklist = value;
                RaisePropertyChanged(() => IncidentsChecklist);
            }
        }

        #endregion


        #region Constructor

        public IncidentChecklistViewModel(IUserService userService, IIncidentService incidentService)
        {
            _userService = userService;
            _incidentService = incidentService;
        }

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Incident_Checklist;

            LoadData();

            GetIncidentChecklist();

            return base.InitializeAsync(query);
        }

        #endregion

        #region Private Methods

        private void LoadData()
        {
            var user = _userService.GetLoggedInUserInfo();
            Officer = user.FullName;
            Site = SiteMenuViewModel.Site.SiteName;
            Client = SiteMenuViewModel.Site.ClientName;
        }

        private void GetIncidentChecklist()
        {
            CallApi(

                apiMethod: async () => await _incidentService.GetIncidentChecklist(),

                onSuccess: (response) =>
                {
                    var list = (List<IncidentChecklistGroup>)response.ProcessedData;
                    IncidentsChecklist = new ObservableCollection<IncidentChecklistGroup>(list);
                }

            );
        }

        #endregion

    }
}
