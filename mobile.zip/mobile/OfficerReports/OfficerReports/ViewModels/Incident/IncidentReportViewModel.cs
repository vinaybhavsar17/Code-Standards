﻿using Azure;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.Incident;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Base;
using OfficerReports.Services.Incident;
using OfficerReports.Services.Storage;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.Incident
{
    public class IncidentReportViewModel : ViewModelBase
    {

        #region Internal Variables/Constants
        private IUserService _userService;
        private IIncidentService _incidentReportService;
        private IAzureStorageService _azureStorageService;
        private int _userID;
        private string _policeCalled;

        private DateTime IncidentDateTime
        {
            get
            {
                var value = default(DateTime);
                try
                {
                    value = DateTime.ParseExact(DateTimeOfIncident, AppConstants.DateTimeFormat, null);
                }
                catch (Exception ex)
                {

                }

                return value;
            }
        }

        #endregion

        #region Bindable Properties
        private ObservableCollection<string> _isPoliceCalled;
        public ObservableCollection<string> IsPoliceCalled
        {
            get { return _isPoliceCalled; }
            set
            {
                _isPoliceCalled = value;
                OnPropertyChanged(nameof(IsPoliceCalled));
            }
        }

        private string _selectedItemPoliceCalled;
        public string SelectedItemPoliceCalled
        {
            get { return _selectedItemPoliceCalled; }
            set
            {
                _selectedItemPoliceCalled = value;
                OnPropertyChanged(nameof(SelectedItemPoliceCalled));
            }
        }

        private int _selectedItemIndexPoliceCalled;
        public int SelectedItemIndexPoliceCalled
        {
            get { return _selectedItemIndexPoliceCalled; }
            set
            {
                _selectedItemIndexPoliceCalled = value;
                if (value == 0)
                {
                    PoliceCalledEntryIsEnabled = true;
                }
                else
                {
                    PoliceCalledEntryIsEnabled = false;
                }
                _policeCalled = value.ToString();
                OnPropertyChanged(nameof(SelectedItemIndexPoliceCalled));
            }
        }

        private bool _policeCalledEntryIsEnabled;
        public bool PoliceCalledEntryIsEnabled
        {
            get { return _policeCalledEntryIsEnabled; }
            set
            {
                _policeCalledEntryIsEnabled = value;
                OnPropertyChanged(nameof(PoliceCalledEntryIsEnabled));
            }
        }

        private ObservableCollection<IncidentTypeItem> _incidentTypeItems;
        public ObservableCollection<IncidentTypeItem> IncidentTypeItems
        {
            get { return _incidentTypeItems; }
            set
            {
                _incidentTypeItems = value;
                RaisePropertyChanged(() => IncidentTypeItems);
            }
        }

        private int _selectedItemIndexIncidentTypeItem;
        public int SelectedItemIndeIncidentTypeItem
        {
            get { return _selectedItemIndexIncidentTypeItem; }
            set
            {
                _selectedItemIndexIncidentTypeItem = value;
                OnPropertyChanged(nameof(SelectedItemIndeIncidentTypeItem));
            }
        }

        private bool _otherIncidentTypeEnableDisable;
        public bool OtherIncidentTypeEnableDisable
        {
            get { return _otherIncidentTypeEnableDisable; }
            set
            {
                _otherIncidentTypeEnableDisable = value;
                OnPropertyChanged(nameof(OtherIncidentTypeEnableDisable));
            }
        }


        private IncidentTypeItem _selectedIncidentType;
        public IncidentTypeItem SelectedIncidentType
        {
            get { return _selectedIncidentType; }
            set
            {
                _selectedIncidentType = value;
                if (value != null) {
                    if (_selectedIncidentType.TypeDataName == AppConstants.TypeOther)
                    {
                        OtherIncidentTypeEnableDisable = true;
                    }
                    else
                    {
                        OtherIncidentType = string.Empty;
                        OtherIncidentTypeEnableDisable = false;
                    }
                }
              
                OnPropertyChanged(nameof(SelectedIncidentType));
            }
        }


        private string _officer;
        public string Officer
        {
            get { return _officer; }
            set
            {
                _officer = value;
                RaisePropertyChanged(() => Officer);
            }
        }

        private string _client;
        public string Client
        {
            get { return _client; }
            set
            {
                _client = value;
                RaisePropertyChanged(() => Client);
            }
        }

        private string _site;
        public string Site
        {
            get { return _site; }
            set
            {
                _site = value;
                RaisePropertyChanged(() => Site);
            }
        }

        private string _incidentReportNumber;
        public string IncidentReportNumber
        {
            get { return _incidentReportNumber; }
            set
            {
                _incidentReportNumber = value;
                RaisePropertyChanged(() => IncidentReportNumber);
            }
        }

        private string _dateTimeOfIncident;
        public string DateTimeOfIncident
        {
            get { return _dateTimeOfIncident; }
            set
            {
                _dateTimeOfIncident = value;
                RaisePropertyChanged(() => DateTimeOfIncident);
            }
        }

        private string _otherIncidentType;
        public string OtherIncidentType
        {
            get { return _otherIncidentType; }
            set
            {
                _otherIncidentType = value;
                RaisePropertyChanged(() => OtherIncidentType);
            }
        }

        private string _victimNames;
        public string VictimNames
        {
            get { return _victimNames; }
            set
            {
                _victimNames = value;
                RaisePropertyChanged(() => VictimNames);
            }
        }

        private string _victimContactInfo;
        public string VictimContactInfo
        {
            get { return _victimContactInfo; }
            set
            {
                _victimContactInfo = value;
                RaisePropertyChanged(() => VictimContactInfo);
            }
        }

        private string _suspectName;
        public string SuspectName
        {
            get { return _suspectName; }
            set
            {
                _suspectName = value;
                RaisePropertyChanged(() => SuspectName);
            }
        }

        private string _suspectContactInfo;
        public string SuspectContactInfo
        {
            get { return _suspectContactInfo; }
            set
            {
                _suspectContactInfo = value;
                RaisePropertyChanged(() => SuspectContactInfo);
            }
        }

        private string _witnessName;
        public string WitnessName
        {
            get { return _witnessName; }
            set
            {
                _witnessName = value;
                RaisePropertyChanged(() => WitnessName);
            }
        }

        private string _witnessContactInfo;
        public string WitnessContactInfo
        {
            get { return _witnessContactInfo; }
            set
            {
                _witnessContactInfo = value;
                RaisePropertyChanged(() => WitnessContactInfo);
            }
        }

        private string _incidentLocation;
        public string IncidentLocation
        {
            get { return _incidentLocation; }
            set
            {
                _incidentLocation = value;
                RaisePropertyChanged(() => IncidentLocation);
            }
        }

        private string _incidentSummary;
        public string IncidentSummary
        {
            get { return _incidentSummary; }
            set
            {
                _incidentSummary = value;
                RaisePropertyChanged(() => IncidentSummary);
            }
        }

        private string _whyPoliceNotCalled;
        public string WhyPoliceNotCalled
        {
            get { return _whyPoliceNotCalled; }
            set
            {
                _whyPoliceNotCalled = value;
                RaisePropertyChanged(() => WhyPoliceNotCalled);
            }
        }

        private string _fireTruckNumber;
        public string FireTruckNumber
        {
            get { return _fireTruckNumber; }
            set
            {
                _fireTruckNumber = value;
                RaisePropertyChanged(() => FireTruckNumber);
            }
        }

        private string _ambulanceNumber;
        public string AmbulanceNumber
        {
            get { return _ambulanceNumber; }
            set
            {
                _ambulanceNumber = value;
                RaisePropertyChanged(() => AmbulanceNumber);
            }
        }

        private string _policeNamesAndBadges;
        public string PoliceNamesAndBadges
        {
            get { return _policeNamesAndBadges; }
            set
            {
                _policeNamesAndBadges = value;
                RaisePropertyChanged(() => PoliceNamesAndBadges);
            }
        }

        private string _incidentDetail;
        public string IncidentDetail
        {
            get { return _incidentDetail; }
            set
            {
                _incidentDetail = value;
                RaisePropertyChanged(() => IncidentDetail);
            }
        }

        private string _officerDetails;
        public string OfficerDetail
        {
            get { return _officerDetails; }
            set
            {
                _officerDetails = value;
                RaisePropertyChanged(() => OfficerDetail);
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }

        #endregion

        #region Commands
        public ICommand SubmitCommand => new Command(() => SubmitForm());
        public ICommand ClearCommand => new Command(() => ClearForm());
        #endregion

        #region Constructors
        public IncidentReportViewModel
            (IUserService userService,
            IIncidentService incidentReportService,
            IAzureStorageService azureStorageService)
        {
            _userService = userService;
            _incidentReportService = incidentReportService;
            _azureStorageService = azureStorageService;
        }
        #endregion

        #region Overriden Methods
        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Incident_Report;
            LoadData();
            GetIncidentTypes(); 
            return base.InitializeAsync(query);
        }

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(DateTimeOfIncident));
            Validator.AddField(nameof(IncidentType));
            Validator.AddField(nameof(IncidentLocation));
            Validator.AddField(nameof(IncidentSummary));
            Validator.AddField(nameof(OfficerDetail));
            Validator.AddField(nameof(IncidentDetail));
            Validator.AddField(nameof(IsPoliceCalled));
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            IncidentReportNumber = GetCachedProperty<string>(nameof(IncidentReportNumber), data, ref isCachedFromPreviousSession);
            DateTimeOfIncident = GetCachedProperty<string>(nameof(DateTimeOfIncident), data, ref isCachedFromPreviousSession);

            var selectedIncidentType = GetCachedProperty<IncidentTypeItem>(nameof(SelectedIncidentType), data, ref isCachedFromPreviousSession);
            if (selectedIncidentType != null && IncidentTypeItems != null)
            {
                SelectedIncidentType = IncidentTypeItems.Where(o => o.TypeDataId == selectedIncidentType.TypeDataId).FirstOrDefault();
            }

            OtherIncidentType = GetCachedProperty<string>(nameof(OtherIncidentType), data, ref isCachedFromPreviousSession);
            VictimNames = GetCachedProperty<string>(nameof(VictimNames), data, ref isCachedFromPreviousSession);
            VictimContactInfo = GetCachedProperty<string>(nameof(VictimContactInfo), data, ref isCachedFromPreviousSession);
            SuspectName = GetCachedProperty<string>(nameof(SuspectName), data, ref isCachedFromPreviousSession);
            SuspectContactInfo = GetCachedProperty<string>(nameof(SuspectContactInfo), data, ref isCachedFromPreviousSession);
            WitnessName = GetCachedProperty<string>(nameof(WitnessName), data, ref isCachedFromPreviousSession);
            WitnessContactInfo = GetCachedProperty<string>(nameof(WitnessContactInfo), data, ref isCachedFromPreviousSession);
            IncidentLocation = GetCachedProperty<string>(nameof(IncidentLocation), data, ref isCachedFromPreviousSession);
            IncidentSummary = GetCachedProperty<string>(nameof(IncidentSummary), data, ref isCachedFromPreviousSession);

            SelectedItemPoliceCalled = GetCachedProperty<string>(nameof(SelectedItemPoliceCalled), data, ref isCachedFromPreviousSession);
            WhyPoliceNotCalled = GetCachedProperty<string>(nameof(WhyPoliceNotCalled), data, ref isCachedFromPreviousSession);
            FireTruckNumber = GetCachedProperty<string>(nameof(FireTruckNumber), data, ref isCachedFromPreviousSession);
            AmbulanceNumber = GetCachedProperty<string>(nameof(AmbulanceNumber), data, ref isCachedFromPreviousSession);
            PoliceNamesAndBadges = GetCachedProperty<string>(nameof(PoliceNamesAndBadges), data, ref isCachedFromPreviousSession);

            IncidentDetail = GetCachedProperty<string>(nameof(IncidentDetail), data, ref isCachedFromPreviousSession);
            Files = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(Files), data, ref isCachedFromPreviousSession);
            OfficerDetail = GetCachedProperty<string>(nameof(OfficerDetail), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        #endregion

        #region Private Methods

        private void LoadData()
        {
            var user = _userService.GetLoggedInUserInfo();
            Officer = user.FullName;
            _userID = user.UserId;
            Site = SiteMenuViewModel.Site.SiteName;
            Client = SiteMenuViewModel.Site.ClientName;
            DateTimeOfIncident = DateTime.Now.ToString(AppConstants.DateTimeFormat);
            var list = new List<string>
            {
              AppResource.No,
              AppResource.Yes
             };

            IsPoliceCalled = new ObservableCollection<string>(list);
            PoliceCalledEntryIsEnabled = false;



        }

        private void GetIncidentTypes() {

            CallApi(

               apiMethod: async () => await _incidentReportService.GetIncidentTypes(),

               onSuccess: (response) => {
                   var result = response.ProcessedData;

                   IncidentType objectList = result as IncidentType;
                   var data = objectList.Data;
                   var list = (List<IncidentTypeItem>)data;
                   IncidentTypeItems = new ObservableCollection<IncidentTypeItem>(list);
               }
            );
        }


        private void SubmitForm()
        {
              if (!Validator.Validate())
                return;

            var createIncidentReportRequest = new CreateIncidentReportRequest
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId.ToString(),
                OfficerId = _userID.ToString(),
                IncidentTypeId = _selectedIncidentType.TypeDataId.ToString(),
                IncidentReportNumber = IncidentReportNumber,
                IncidentDate = IncidentDateTime.ToString("O"),
                IncidentOtherType = OtherIncidentType,
                IncidentLocation = IncidentLocation,
                IncidentSummary = IncidentSummary,
                IncidentDetails = IncidentDetail,
                VictimName = VictimNames,
                VictimContactInfo = VictimContactInfo,
                SuspectNames = SuspectName,
                SuspectContactInfo = SuspectContactInfo,
                WitnessNames = WitnessName,
                WitnessContactInfo = WitnessContactInfo,
                PoliceCalled = _policeCalled,
                WhyPoliceNotCalled = WhyPoliceNotCalled,
                PoliceInfo = PoliceNamesAndBadges,
                FireTruckNumber = FireTruckNumber,
                AmbulanceNumber = AmbulanceNumber,
                OfficerActions = OfficerDetail,
                IsAttachmentAdded = Files != null && Files.Count > 0
            };

            CallApi(
                apiMethod: async () => await _incidentReportService.CreateIncidentReportRequest(createIncidentReportRequest),

                onSuccess: async (response) => {

                    if (Files != null && Files.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_incidentReportService).CacheFiles(Files.ToList(), response.CachedDataId, EntityRequest.EntityTypeIncidentReport, AppConstants.PurposeReports);
                        }
                        else
                        {
                            var reportId = response.Data.reportId;

                            var request = new EntityRequest
                            {
                                EntityId = reportId,
                                EntityTypeId = EntityRequest.EntityTypeIncidentReport
                            };

                            var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, Files.ToList(), request);

                            if (!uploaded)
                            {
                                await NavigationService.PopAsync();
                                DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                return;
                            }
                        }
                    }
                    OnSubmitCompleted(response);
                }
            );
        }

        private async void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Incident_Report_Submit_Succesfully);
        }

        private void ClearForm()
        {
            Validator.Reset();

            IncidentReportNumber = string.Empty;
            OtherIncidentType = string.Empty;
            VictimNames = string.Empty;
            VictimContactInfo = string.Empty;
            SuspectName = string.Empty;
            SuspectContactInfo = string.Empty;
            WitnessName = string.Empty;
            WitnessContactInfo = string.Empty;
            WhyPoliceNotCalled = string.Empty;
            FireTruckNumber = string.Empty;
            AmbulanceNumber = string.Empty;
            PoliceNamesAndBadges = string.Empty;
            IncidentDetail = string.Empty;
            OfficerDetail = string.Empty;
            DateTimeOfIncident = string.Empty;
            IncidentLocation = string.Empty;
            IncidentSummary = string.Empty;
            OfficerDetail = string.Empty;
            IncidentDetail = string.Empty;
            SelectedIncidentType = null;
            SelectedItemIndexPoliceCalled = -1;

            Files?.Clear();

            ClearCachedProperties();
        }

        #endregion

        #region Public Methods

        #endregion
    }
}
