﻿
using Microsoft.CSharp.RuntimeBinder;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using OfficerReports.Helpers;
using OfficerReports.Interfaces;
using OfficerReports.Models.Base;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Dialog;
using OfficerReports.Services.Navigation;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace OfficerReports.ViewModels.Base
{
    public abstract class ViewModelBase : ExtendedBindableObject, IQueryAttributable
    {
        public readonly IDialogService DialogService;
        public readonly INavigationService NavigationService;
        public readonly ILogger<ViewModelBase> Logger;
        public readonly ValidationHelper Validator;
        public IContentUpdater ContentUpdater;

        private bool _isInitialized;

        public bool IsInitialized
        {
            get => _isInitialized;

            set
            {
                _isInitialized = value;
                OnPropertyChanged(nameof(IsInitialized));
            }
        }

        private string _headerTitle;
        public string HeaderTitle
        {
            get => _headerTitle;
            set
            {
                _headerTitle = value;
                OnPropertyChanged(nameof(HeaderTitle));
            }
        }

        private bool _multipleInitialization;

        public bool MultipleInitialization
        {
            get => _multipleInitialization;

            set
            {
                _multipleInitialization = value;
                OnPropertyChanged(nameof(MultipleInitialization));
            }
        }

        private bool _isBusy;

        public bool IsBusy
        {
            get => _isBusy;

            set
            {
                _isBusy = value;
                OnPropertyChanged(nameof(IsBusy));
            }
        }

        private ObservableDictionary<string, bool> _isValid;
        public ObservableDictionary<string, bool> IsValid
        {
            get { return _isValid; }
            set
            {
                _isValid = value;
                RaisePropertyChanged(() => IsValid);
            }
        }

        private bool IsReadyToCache { get; set; }

        public virtual ICommand NavigationBackCommand => new Command(() => { 
            NavigationService.PopAsync();
            OnDestroy();
        });

        public ViewModelBase()
        {
            DialogService = App.ServiceProvider.GetRequiredService<IDialogService>();
            NavigationService = App.ServiceProvider.GetRequiredService<INavigationService>();
            Logger = App.ServiceProvider.GetRequiredService<ILogger<ViewModelBase>>();

            IsValid = new ObservableDictionary<string, bool>();
            IsValid.PropertyChanged += (s, e) =>
            {
                if(e.PropertyName.Equals("Values"))
                    RaisePropertyChanged(() => IsValid);
            };
            Validator = new ValidationHelper(IsValid);

            SetValidationFields();
        }

        public virtual Task InitializeAsync (IDictionary<string, object> query)
        {
            IsInitialized = true;

            var obj = ReportCacheManager.GetData(this.GetType().Name);
            LoadCachedProperties(obj);

            return Task.FromResult (false);
        }

        public virtual void OnDestroy()
        {

        }

        public virtual void OnBackButtonPressed()
        {
            OnDestroy();
        }

        public virtual void OnDisappearing()
        {

        }

        public virtual void OnAppearing()
        {

        }

        public virtual void OnResume()
        {

        }

        public virtual void LoadCachedProperties(IDictionary<string, string> data)
        {
            IsReadyToCache = true;
        }

        protected TType GetCachedProperty<TType>(string key, IDictionary<string, string> data, ref bool isCached)
        {
            var returnValue = default(TType);

            if (data.ContainsKey(key))
            {
                var value = data[key]?.ToString();
                if (!string.IsNullOrEmpty(value))
                {
                    returnValue = JsonConvert.DeserializeObject<TType>(value);
                    isCached = true;
                }
            }

            return returnValue;
        }

        protected bool GetCachedBoolProperty(string key, IDictionary<string, string> data, ref bool isSessionCached, out bool isPropertyCached)
        {
            var returnValue = default(bool);
            isPropertyCached = false;

            if (data.ContainsKey(key))
            {
                var value = data[key]?.ToString();
                if (!string.IsNullOrEmpty(value))
                {
                    returnValue = JsonConvert.DeserializeObject<bool>(value);
                    isSessionCached = true;
                    isPropertyCached = true;
                }
            }

            return returnValue;
        }

        protected void ClearCachedProperties()
        {
            ReportCacheManager.ClearData(this.GetType().Name);
        }

        public async void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            if (!IsInitialized)
            {
                IsInitialized = true;
                await InitializeAsync(query);
            }
        }

        protected virtual void SetValidationFields()
        {

        }

        protected override void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            base.OnPropertyChanged(propertyName);

            if (!IsReadyToCache)
                return;

            var property = this.GetType().GetProperty(propertyName);
            var propertyValue = property.GetValue(this);

            if (property.DeclaringType == typeof(ViewModelBase))
                return;

            if (propertyValue == null)
                return;

            var isDefaultValue = (bool)GetType().GetMethod("IsDefaultValue").MakeGenericMethod(property.PropertyType).Invoke(this, new object[] { propertyValue });
            if (isDefaultValue && property.PropertyType != typeof(bool))
                return;

            ReportCacheManager.SetValue(GetType().Name, propertyName, propertyValue);
        }

        public bool IsDefaultValue<TType>(object value)
        {
            return value.Equals(default(TType));
        }

        public async void CallApi<TResult>(Func<Task<TResult>> apiMethod, Action<TResult> onSuccess, bool isBackground = false, Action onFailure = null) where TResult : ApiResponse
        {
            if (!MainThread.IsMainThread)
                throw new Exception("This CallApi method in ViewModelBase.cs class cannot be executed from inside a thread. Run it on main ui thread");

            try
            {
                if (!isBackground)
                    DialogService.ShowLoading();

                ApiResponse result = await apiMethod();

                if (!isBackground)
                    DialogService.HideLoading();

                if (result == null)
                {
                    if (!isBackground)
                        DialogService.ShowMessage(AppResource.Alert, AppResource.Something_Went_Wrong);

                    onFailure?.Invoke();
                    return;
                }

                if (result.IgnoreResponse)
                    return;

                if (result.IsUnauthorized)
                {
                    MessagingCenter.Send<object>(this, App.MESSAGE_LOGOUT);
                    DialogService.ShowMessage(AppResource.Alert, AppResource.Session_Expired);

                    onFailure?.Invoke();
                    return;
                }

                try
                {
                    if ((bool)result.Data.isPasswordExipred)
                    {
                        MessagingCenter.Send<object>(this, App.MESSAGE_PASSWORD_EXPIRED);
                        DialogService.ShowMessage(AppResource.Alert, result.Message);

                        onFailure?.Invoke();
                        return;
                    }
                }
                catch (RuntimeBinderException ex)
                {

                }

                if (!result.IsSuccess)
                {
                    if (!isBackground)
                    {
                        if (!string.IsNullOrEmpty(result.Message))
                            DialogService.ShowMessage(AppResource.Alert, result.Message);
                        else if (result.Errors != null)
                        {
                            var msg = $"{result.Title}";

                            foreach (var error in result.Errors)
                            {
                                var name = error.Name;
                                var value = error.Value;

                                msg += $"\n\n{name}:";

                                foreach (var item in value)
                                {
                                    msg += $"\n{item}";
                                }
                            }

                            DialogService.ShowMessage(AppResource.Alert, msg);
                        }
                        else
                            DialogService.ShowMessage(AppResource.Alert, AppResource.Something_Went_Wrong);
                    }

                    onFailure?.Invoke();
                    return;
                }

                onSuccess((TResult)result);

                ContentUpdater?.OnContentUpdate();
            }
            catch (Exception ex)
            {
                if (!isBackground)
                {
                    DialogService.HideLoading();
                    DialogService.ShowMessage(AppResource.Alert, AppResource.Something_Went_Wrong);
                }

                onFailure?.Invoke();

                Logger.LogError("Failed while calling API method => " + apiMethod.ToString() + "\n" + ex.Message);
            }
        }
    }
}