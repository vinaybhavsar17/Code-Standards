﻿using OfficerReports.Services.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using OfficerReports.Models.Base;

namespace OfficerReports.ViewModels.Base
{
    public abstract class FormPageBaseViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IUserService _userService;

        #endregion


        #region Bindable Properties

        private string _officer;
        public string Officer
        {
            get { return _officer; }
            set
            {
                _officer = value;
                RaisePropertyChanged(() => Officer);
            }
        }

        private string _client;
        public string Client
        {
            get { return _client; }
            set
            {
                _client = value;
                RaisePropertyChanged(() => Client);
            }
        }

        private string _site;
        public string Site
        {
            get { return _site; }
            set
            {
                _site = value;
                RaisePropertyChanged(() => Site);
            }
        }

        #endregion


        #region Commands

        public ICommand SubmitCommand => new Command(() => SubmitFormBase());
        public ICommand ClearCommand => new Command(() => ClearFormBase());

        #endregion


        #region Constructor

        public FormPageBaseViewModel()
        {
            _userService = App.ServiceProvider.GetRequiredService<IUserService>();
        }

        #endregion


        #region  Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            LoadData();
            return base.InitializeAsync(query);
        }

        #endregion


        #region Protected Methods

        private void LoadData()
        {
            var user = _userService.GetLoggedInUserInfo();
            Officer = user?.FullName;
            Site = SiteMenuViewModel.Site?.SiteName;
            Client = SiteMenuViewModel.Site?.ClientName;
        }

        #endregion

        #region Abstract Methods

        private void SubmitFormBase()
        {
            if (!Validator.Validate())
                return;

            SubmitForm();
        }
        protected abstract void SubmitForm();

        private void ClearFormBase()
        {
            Validator.Reset();

            ClearForm();
        }
        protected abstract void ClearForm();

        protected abstract void OnSubmitCompleted(ApiResponse response);

        #endregion
    }
}
