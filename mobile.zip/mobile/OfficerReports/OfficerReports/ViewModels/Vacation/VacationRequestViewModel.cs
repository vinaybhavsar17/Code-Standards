﻿using OfficerReports.Constants;
using OfficerReports.Models.Base;
using OfficerReports.Models.Vacation;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.User;
using OfficerReports.Services.Vacation;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Newtonsoft.Json;
using OfficerReports.Helpers;

namespace OfficerReports.ViewModels.Vacation
{
    public class VacationRequestViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IVacationService _vacationService;
        private IUserService _userService;

        private DateTime StartDateTime { 
            get 
            {
                var value = default(DateTime);
                try
                {
                    value = DateTime.ParseExact(StartDate, AppConstants.DateFormat, null);
                }
                catch (Exception ex)
                {
                    
                }

                return value;
            } 
        }

        private DateTime EndDateTime
        {
            get
            {
                var value = default(DateTime);
                try
                {
                    value = DateTime.ParseExact(EndDate, AppConstants.DateFormat, null);
                }
                catch (Exception ex)
                {

                }

                return value;
            }
        }

        #endregion

        #region Bindable Properties

        private string _phone;
        public string Phone
        {
            get { return _phone; }
            set
            {
                _phone = value;
                RaisePropertyChanged(() => Phone);
            }
        }

        private string _email;
        public string Email
        {
            get { return _email; }
            set
            {
                _email = value;
                RaisePropertyChanged(() => Email);
            }
        }

        private string _startDate;
        public string StartDate
        {
            get { return _startDate; }
            set
            {
                _startDate = value;
                RaisePropertyChanged(() => StartDate);
            }
        }

        private string _endDate;
        public string EndDate
        {
            get { return _endDate; }
            set
            {
                _endDate = value;
                RaisePropertyChanged(() => EndDate);
            }
        }

        private string _reason;
        public string Reason
        {
            get { return _reason; }
            set
            {
                _reason = value;
                RaisePropertyChanged(() => Reason);
            }
        }

        #endregion

        #region Commands

        public ICommand SubmitCommand => new Command(() => SubmitForm());

        public ICommand ClearCommand => new Command(() => ClearForm());

        #endregion

        #region Constructors

        public VacationRequestViewModel(IVacationService vacationService, IUserService userService)
        {
            _vacationService = vacationService;
            _userService = userService;
        }

        #endregion

        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Vacation_Request;

            LoadUserInfo();

            return base.InitializeAsync(query);
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            var phone = GetCachedProperty<string>(nameof(Phone), data, ref isCachedFromPreviousSession);
            if (phone != default(string))
                Phone = phone;

            var email = GetCachedProperty<string>(nameof(Email), data, ref isCachedFromPreviousSession);
            if (email != default(string))
                Email = email;

            var startDate = GetCachedProperty<string>(nameof(StartDate), data, ref isCachedFromPreviousSession);
            if (startDate != default(string))
                StartDate = startDate;

            var endDate = GetCachedProperty<string>(nameof(EndDate), data, ref isCachedFromPreviousSession);
            if (endDate != default(string))
                EndDate = endDate;

            Reason = GetCachedProperty<string>(nameof(Reason), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        #endregion

        #region Private Methods

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(Email));
            Validator.AddField(nameof(StartDate));
            Validator.AddField(nameof(EndDate));
            Validator.AddField(nameof(Reason));
        }

        private void LoadUserInfo()
        {
            var user = _userService.GetLoggedInUserInfo();

            var cachedPhone = ReportCacheManager.GetValue(GetType().Name, nameof(Phone));
            if (string.IsNullOrEmpty(cachedPhone))
            {
                Phone = user.Phone;
                ReportCacheManager.DeleteValue(GetType().Name, nameof(Phone));
            }

            var cachedEmail = ReportCacheManager.GetValue(GetType().Name, nameof(Email));
            if (string.IsNullOrEmpty(cachedEmail))
            {
                Email = user.Email;
                ReportCacheManager.DeleteValue(GetType().Name, nameof(Email));
            }

            var cachedStartDate = ReportCacheManager.GetValue(GetType().Name, nameof(StartDate));
            if (string.IsNullOrEmpty(cachedStartDate))
            {
                StartDate = DateTime.Today.ToString(AppConstants.DateFormat);
                ReportCacheManager.DeleteValue(GetType().Name, nameof(StartDate));
            }

            var cachedEndDate = ReportCacheManager.GetValue(GetType().Name, nameof(EndDate));
            if (string.IsNullOrEmpty(cachedEndDate))
            {
                EndDate = DateTime.Today.ToString(AppConstants.DateFormat);
                ReportCacheManager.DeleteValue(GetType().Name, nameof(EndDate));
            }
        }

        private void SubmitForm()
        {
            if (!Validator.Validate())
                return;

            var createVacationRequest = new CreateVacationRequest
            {
                Phone = Phone,
                EmailAddress = Email,
                StartDate = StartDateTime.ToString("O"),
                EndDate = EndDateTime.ToString("O"),
                Comments = Reason,
                CurrentTimezone = TimeZoneInfo.Local.Id
            };

            CallApi(

                apiMethod: async () => await _vacationService.CreateVacationRequest(createVacationRequest),

                onSuccess: async(response) => {
                    ClearCachedProperties();

                    await NavigationService.PopAsync();

                    if (response.IsCached)
                        DialogService.ShowMessage(AppResource.Success, response.Message);
                    else
                        DialogService.ShowMessage(AppResource.Success, AppResource.Vacation_Request_Success);
                }

            );
        }

        private void ClearForm()
        {
            Validator.Reset();

            Phone = string.Empty;
            Email = string.Empty;
            StartDate = string.Empty;
            EndDate = string.Empty;
            Reason = string.Empty;

            ClearCachedProperties();
        }

        #endregion
    }
}
