﻿using OfficerReports.Models.Vacation;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Vacation;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.Vacation
{
    public class VacationReviewViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IVacationService _vacationService;

        #endregion


        #region Bindable Properties

        private ObservableCollection<VacationRequest> _vacationRequests;
        public ObservableCollection<VacationRequest> VacationRequests
        {
            get { return _vacationRequests; }
            set
            {
                _vacationRequests = value;
                RaisePropertyChanged(() => VacationRequests);
            }
        }

        #endregion


        #region Commands

        public ICommand WithdrawCommand => new Command<VacationRequest>((vacationRequest) => WithdrawVacationRequest(vacationRequest));

        public ICommand ShowCommentsCommand => new Command<VacationRequest>((vacationRequest) => ShowComments(vacationRequest));

        #endregion


        #region Constructors

        public VacationReviewViewModel(IVacationService vacationService)
        {
            _vacationService = vacationService;
        }

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Vacation_Request_Review;

            GetVacationRequests();

            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Methods

        private void GetVacationRequests()
        {
            CallApi(

                apiMethod: async () => await _vacationService.GetVacationRequests(),

                onSuccess: (response) => 
                {
                    var list = (List<VacationRequest>)response.ProcessedData;
                    VacationRequests = new ObservableCollection<VacationRequest>(list);
                }

            );
        }

        private async void WithdrawVacationRequest(VacationRequest vacationRequest)
        {
            var isConfirmed = await DialogService.Confirm(AppResource.Withdraw_Confirmation);
            if (!isConfirmed)
                return;

            CallApi(

                apiMethod: async () => await _vacationService.WithdrawVacationRequest(vacationRequest.VacationRequestId.ToString()),

                onSuccess: (response) => {
                    DialogService.ShowMessage(AppResource.Success, AppResource.Withdraw_Success_Message);

                    //Refresh list
                    GetVacationRequests();
                }

            );
        }

        private void ShowComments(VacationRequest vacationRequest)
        {
            DialogService.ShowMessage(AppResource.Reason, vacationRequest.Comments);
        }

        #endregion


        #region Public Methods

        #endregion
    }
}
