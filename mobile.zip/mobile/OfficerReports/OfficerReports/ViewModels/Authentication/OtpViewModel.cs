﻿using OfficerReports.Resources.Strings;
using OfficerReports.Services.Authentication;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.Authentication
{
    public class OtpViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IAuthenticationService _authenticationService;

        public Models.Authentication.User User { get; set; }

        public dynamic AdminCredentials { get; set; }

        #endregion


        #region Bindable Properties

        private string _otp;
        public string Otp
        {
            get { return _otp; }
            set
            {
                _otp = value;
                RaisePropertyChanged(() => Otp);

                if (_otp.Length == 4)
                    IsOtpValid = true;
                else
                    IsOtpValid = false;
            }
        }

        private bool _isOtpValid;
        public bool IsOtpValid
        {
            get { return _isOtpValid; }
            set
            {
                _isOtpValid = value;
                RaisePropertyChanged(() => IsOtpValid);
            }
        }

        private bool _showValidation;
        public bool ShowValidation
        {
            get { return _showValidation; }
            set
            {
                _showValidation = value;
                RaisePropertyChanged(() => ShowValidation);
            }
        }

        #endregion



        #region Constructors

        public OtpViewModel(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

        #endregion


        #region Commands

        public ICommand OtpSubmitCommand => new Command(() => OtpSubmit());
        public ICommand OtpResendCommand => new Command(() => OtpResend());

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Methods

        private void OtpSubmit()
        {
            ShowValidation = !IsOtpValid;

            if (!IsOtpValid)
                return;

            CallApi(

                apiMethod: async () => await _authenticationService.CheckOtp(Otp, User.AccessToken),

                onSuccess: (response) => {

                    NavigationService.ReplacePage(new MimicView(AdminCredentials));

                }

            );
        }

        private void OtpResend()
        {
            CallApi(

                apiMethod: async () => await _authenticationService.ResendOtp("admin"),

                onSuccess: (response) => {

                    Otp = String.Empty;
                    DialogService.ShowMessage(AppResource.Alert, "Otp resent successfully");

                }

            );
        }

        #endregion


        #region Public Methods


        #endregion
    }
}
