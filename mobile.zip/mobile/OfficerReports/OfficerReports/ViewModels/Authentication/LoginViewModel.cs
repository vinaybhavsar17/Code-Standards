﻿using OfficerReports.Resources.Strings;
using OfficerReports.Services.Authentication;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using OfficerReports.Views.Authentication;
using OfficerReports.Views.User;
using System.Windows.Input;

namespace OfficerReports.ViewModels.Authentication
{
    public class LoginViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IAuthenticationService _authenticationService;

        #endregion Internal Variables/Constants

        #region Bindable Properties

        private string _username;

        public string Username
        {
            get { return _username; }
            set
            {
                _username = value;
                RaisePropertyChanged(() => Username);
            }
        }

        private string _password;

        public string Password
        {
            get { return _password; }
            set
            {
                _password = value;
                RaisePropertyChanged(() => Password);
            }
        }

        #endregion Bindable Properties

        #region Commands

        public ICommand LoginCommand => new Command(() => Login());

        public ICommand ForgotUsernameCommand => new Command(() => ForgotUsername());

        public ICommand ForgotPasswordCommand => new Command(() => ForgotPassword());

        #endregion Commands

        #region Constructors

        public LoginViewModel(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

        #endregion Constructors

        #region Private Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
#if DEBUG
            Username = "vinaybhavsar";
            Password = "Vinay@123";
#endif

            return base.InitializeAsync(query);
        }

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(Username));
            Validator.AddField(nameof(Password));
        }

        private void Login()
        {
            if (!Validator.Validate())
                return;

            CallApi(

                apiMethod: async () => await _authenticationService.Login(Username, Password),

                onSuccess: (response) =>
                {
                    var user = (Models.Authentication.User)response.ProcessedData;

                    if(user != null)
                    {
                        if(!user.RoleName.Equals(Models.Authentication.User.AdminRole))
                        {
                            NavigationService.PushToRoot(new MenuView(user));

                            DialogService.ShowMessage(AppResource.Location_Access_Title, AppResource.Location_Access_Message);
                        }
                        else
                        {
                            dynamic adminCredentials = new
                            {
                                Username = Username,
                                Password = Password
                            };
                            NavigationService.PushAsync(new OtpView(user, adminCredentials));
                        }
                    }
                }

            );
        }

        private void ForgotUsername()
        {
            NavigationService.PushAsync(new ForgotUsernameView());
        }

        private void ForgotPassword()
        {
            NavigationService.PushAsync(new ForgotPasswordView());
        }

        #endregion Private Methods
    }
}