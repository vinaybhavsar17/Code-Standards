﻿using OfficerReports.Constants;
using OfficerReports.Helpers;
using OfficerReports.Models.Authentication;
using OfficerReports.Models.Base;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Authentication;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ViewModels.Authentication
{
    public class MimicViewModel : FormPageBaseViewModel
    {
        #region Internal Variables/Constants

        private IAuthenticationService _authenticationService;

        public dynamic AdminCredentials { get; set; }

        #endregion

        #region Bindable Properties

        private string _newServiceUrl;
        public string NewServiceUrl
        {
            get { return _newServiceUrl; }
            set
            {
                _newServiceUrl = value;
                RaisePropertyChanged(() => NewServiceUrl);
            }
        }

        private string _mimicUsername;
        public string MimicUsername
        {
            get { return _mimicUsername; }
            set
            {
                _mimicUsername = value;
                RaisePropertyChanged(() => MimicUsername);
            }
        }

        private string _mimicLatitude;
        public string MimicLatitude
        {
            get { return _mimicLatitude; }
            set
            {
                _mimicLatitude = value;
                RaisePropertyChanged(() => MimicLatitude);
            }
        }

        private string _mimicLongitude;
        public string MimicLongitude
        {
            get { return _mimicLongitude; }
            set
            {
                _mimicLongitude = value;
                RaisePropertyChanged(() => MimicLongitude);
            }
        }

        #endregion


        #region Constructors

        public MimicViewModel(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

        #endregion


        #region override methods

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(NewServiceUrl));
            Validator.AddField(nameof(MimicUsername));
        }

        protected override void ClearForm()
        {
            NewServiceUrl = String.Empty;
            MimicUsername = String.Empty;
            MimicLatitude = String.Empty;
            MimicLongitude = String.Empty;
        }

        protected override void OnSubmitCompleted(ApiResponse response)
        {
        }

        protected override void SubmitForm()
        {
            CallApi<ApiResponse>(

                apiMethod: async () => await _authenticationService.MimicLogin(MimicUsername, AdminCredentials, NewServiceUrl),

                onSuccess: (response) => {

                    var user = (Models.Authentication.User)response.ProcessedData;

                    if (user.RoleName != null &&
                        !user.RoleName.Equals(Models.Authentication.User.SiteUserRole) &&
                        !user.RoleName.Equals(Models.Authentication.User.ClientUserRole) &&
                        !user.RoleName.Equals(Models.Authentication.User.CcrRole))
                    {
                        NavigationService.PushToRoot(new MenuView(user));

                        DialogService.ShowMessage(AppResource.Location_Access_Title, AppResource.Location_Access_Message);

                        var mimicData = new MimicData
                        {
                            MimicUrl = NewServiceUrl,
                            MimicUserName = MimicUsername,
                            MimicLatitude = MimicLatitude,
                            MimicLongitude = MimicLongitude
                        };
                        MessagingCenter.Send<MimicViewModel, MimicData>(this, AppConstants.MessageMimicStart, mimicData);
                    }
                    else
                    {
                        DialogService.ShowMessage(AppResource.Alert, AppResource.Mimic_Validation_Message);
                    }

                }

            );
        }

        #endregion
    }
}
