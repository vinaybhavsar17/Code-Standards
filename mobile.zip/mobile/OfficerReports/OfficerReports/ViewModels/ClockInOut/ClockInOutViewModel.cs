﻿using OfficerReports.Models.ClockInOut;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.ClockInOut;
using OfficerReports.Services.LocationService;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.ClockInOut;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.ClockInOut
{
    public class ClockInOutViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IClockInOutService _clockInOutService;
        private ILocationService _locationService;
        private int _clockInOutId;
        private bool _isClockedIn;
        private int _currentClockType;

        #endregion


        #region Bindable Properties

        private string _currentClockStatus;
        public string CurrentClockStatus
        {
            get { return _currentClockStatus; }
            set
            {
                _currentClockStatus = value;
                RaisePropertyChanged(() => CurrentClockStatus);
            }
        }

        private DateTime _currentClockTime;
        public DateTime CurrentClockTime
        {
            get { return _currentClockTime; }
            set
            {
                _currentClockTime = value;
                RaisePropertyChanged(() => CurrentClockTime);
            }
        }

        private string _clockTimeTitle;
        public string ClockTimeTitle
        {
            get { return _clockTimeTitle; }
            set
            {
                _clockTimeTitle = value;
                RaisePropertyChanged(() => ClockTimeTitle);
            }
        }

        private string _currentClockComment;
        public string CurrentClockComment
        {
            get { return _currentClockComment; }
            set
            {
                _currentClockComment = value;
                RaisePropertyChanged(() => CurrentClockComment);
            }
        }

        private string _clockCommentTitle;
        public string ClockCommentTitle
        {
            get { return _clockCommentTitle; }
            set
            {
                _clockCommentTitle = value;
                RaisePropertyChanged(() => ClockCommentTitle);
            }
        }

        private bool _isBreakButtonVisible;
        public bool IsBreakButtonVisible
        {
            get { return _isBreakButtonVisible; }
            set
            {
                _isBreakButtonVisible = value;
                RaisePropertyChanged(() => IsBreakButtonVisible);
            }
        }

        private string _breakButtonText;
        public string BreakButtonText
        {
            get { return _breakButtonText; }
            set
            {
                _breakButtonText = value;
                RaisePropertyChanged(() => BreakButtonText);
            }
        }

        private bool _isShiftButtonVisible;
        public bool IsShiftButtonVisible
        {
            get { return _isShiftButtonVisible; }
            set
            {
                _isShiftButtonVisible = value;
                RaisePropertyChanged(() => IsShiftButtonVisible);
            }
        }

        private string _shiftButtonText;
        public string ShiftButtonText
        {
            get { return _shiftButtonText; }
            set
            {
                _shiftButtonText = value;
                RaisePropertyChanged(() => ShiftButtonText);
            }
        }

        private bool _isLunchButtonVisible;
        public bool IsLunchButtonVisible
        {
            get { return _isLunchButtonVisible; }
            set
            {
                _isLunchButtonVisible = value;
                RaisePropertyChanged(() => IsLunchButtonVisible);
            }
        }

        private string _lunchButtonText;
        public string LunchButtonText
        {
            get { return _lunchButtonText; }
            set
            {
                _lunchButtonText = value;
                RaisePropertyChanged(() => LunchButtonText);
            }
        }

        private ObservableCollection<ClockEntry> _clockEntries;
        public ObservableCollection<ClockEntry> ClockEntries
        {
            get { return _clockEntries; }
            set
            {
                _clockEntries = value;
                RaisePropertyChanged(() => ClockEntries);
            }
        }

        #endregion


        #region Commands

        public ICommand BreakCommand => new Command(() => OnBreakAction());

        public ICommand LunchCommand => new Command(() => OnLunchAction());

        public ICommand ShiftCommand => new Command(() => OnShiftAction());

        public ICommand ViewDetailsCommand => new Command<ClockEntry>((clockEntry) => OpenInOutCommentsPopup(clockEntry));

        #endregion


        #region Constructors

        public ClockInOutViewModel(IClockInOutService clockInOutService, ILocationService locationService)
        {
            _clockInOutService = clockInOutService;
            _locationService = locationService;
        }

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Clock_In_Out;

            GetClockInOutDetails(isBackground: false);

            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Methods

        private Task GetClockInOutDetails(bool isBackground)
        {
            var tcs = new TaskCompletionSource();

            CallApi(

                apiMethod: async () => await _clockInOutService.GetClockInOutDetails(),

                onSuccess: (response) =>
                {
                    var list = (List<ClockEntry>)response.ProcessedData;
                    ClockEntries = new ObservableCollection<ClockEntry>(list);

                    SetupData();

                    tcs.TrySetResult();
                },

                isBackground: isBackground,

                onFailure: () =>
                {
                    tcs.TrySetResult();
                }
            );

            return tcs.Task;
        }

        private void SetupData()
        {
            var currentClockEntry = ClockEntries.FirstOrDefault();

            if (currentClockEntry == null)
            {
                _isClockedIn = false;

                CurrentClockStatus = AppResource.NA;
                ClockTimeTitle = AppResource.Last_Clockin_Date;
                ClockCommentTitle = AppResource.Clock_In_Comment;

                IsShiftButtonVisible = true;
                IsLunchButtonVisible = false;
                IsBreakButtonVisible = false;
                ShiftButtonText = AppResource.Start_Shift_Arriving;

                return;
            }

            _isClockedIn = currentClockEntry.OutClockTypeId == null;
            _clockInOutId = currentClockEntry.ClockInOutId;

            if (_isClockedIn)
            {
                CurrentClockStatus = AppResource.Clocked_In;
                ClockTimeTitle = AppResource.Last_Clockin_Date;
                CurrentClockTime = (DateTime)currentClockEntry.InDateLocal;
                ClockCommentTitle = AppResource.Clock_Out_Comment;
                _currentClockType = (int)currentClockEntry.InClockTypeId;

                IsBreakButtonVisible = true;
                IsLunchButtonVisible = true;
                IsShiftButtonVisible = true;

                BreakButtonText = AppResource.Go_On_Break;
                LunchButtonText = AppResource.Go_To_Lunch;
                ShiftButtonText = AppResource.End_Shift_Leaving;
            }
            else
            {
                CurrentClockStatus = AppResource.Clocked_Out;
                ClockTimeTitle = AppResource.Last_Clockout_Date;
                CurrentClockTime = (DateTime)currentClockEntry.OutDateLocal;
                ClockCommentTitle = AppResource.Clock_In_Comment;
                _currentClockType = (int)currentClockEntry.OutClockTypeId;

                switch (_currentClockType)
                {
                    case ClockType.BREAK:
                        IsBreakButtonVisible = true;
                        IsLunchButtonVisible = false;
                        IsShiftButtonVisible = false;
                        BreakButtonText = AppResource.Return_From_Break;
                        break;

                    case ClockType.LUNCH:
                        IsLunchButtonVisible = true;
                        IsBreakButtonVisible = false;
                        IsShiftButtonVisible = false;
                        LunchButtonText = AppResource.Return_From_Lunch;
                        break;

                    case ClockType.SHIFT:
                        IsShiftButtonVisible = true;
                        IsLunchButtonVisible = false;
                        IsBreakButtonVisible = false;
                        ShiftButtonText = AppResource.Start_Shift_Arriving;
                        break;

                    default:
                        break;

                }
            }
        }

        private async void OnBreakAction()
        {
            DialogService.ShowLoading();

            if (_isClockedIn)
                await ClockOut(ClockType.BREAK);
            else
                await ClockIn(ClockType.BREAK);

            DialogService.HideLoading();
        }

        private async void OnLunchAction()
        {
            DialogService.ShowLoading();

            if (_isClockedIn)
                await ClockOut(ClockType.LUNCH);
            else
                await ClockIn(ClockType.LUNCH);

            DialogService.HideLoading();
        }

        private async void OnShiftAction()
        {
            DialogService.ShowLoading();

            if (_isClockedIn)
                await ClockOut(ClockType.SHIFT);
            else
                await ClockIn(ClockType.SHIFT);

            DialogService.HideLoading();
        }

        private Task<bool> IsUserWithinSiteArea(Location location)
        {
            var tcs = new TaskCompletionSource<bool>();
            CallApi
            (
                apiMethod: async() => await _clockInOutService.IsUserWithinSiteArea(location),

                onSuccess: (response) =>
                {
                    tcs.TrySetResult(true);
                },

                onFailure: () =>
                {
                    tcs.TrySetResult(false);
                }
            );
            return tcs.Task;
        }

        private async Task ClockIn(int clockTypeId)
        {
            var tcs = new TaskCompletionSource();

            var userLocation = await _locationService.GetCurrentLocation(isBackground: true);

            if (userLocation == null)
            {
                tcs.TrySetResult();
                return;
            }

            if (!await IsUserWithinSiteArea(userLocation))
            {
                tcs.TrySetResult();
                return;
            }

            CallApi
            (
                apiMethod: async()  => await _clockInOutService.ClockIn(clockTypeId, CurrentClockComment, userLocation),

                onSuccess: async(response) =>
                {
                    CurrentClockComment = String.Empty;

                    DialogService.ShowMessage(AppResource.Success, AppResource.Clock_In_Success);

                    await GetClockInOutDetails(isBackground: true);

                    tcs.TrySetResult();
                },

                isBackground: true,

                onFailure: () =>
                {
                    tcs.TrySetResult();
                }
            );

            return;
        }

        private async Task ClockOut(int clockTypeId)
        {
            var tcs = new TaskCompletionSource();

            var userLocation = await _locationService.GetCurrentLocation(isBackground: true);

            if (userLocation == null)
            {
                tcs.TrySetResult();
                return;
            }

            if (!await IsUserWithinSiteArea(userLocation))
            {
                tcs.TrySetResult();
                return;
            }

            CallApi
            (
                apiMethod: async () => await _clockInOutService.ClockOut(clockTypeId, _clockInOutId, CurrentClockComment, userLocation),

                onSuccess: async(response) =>
                {
                    CurrentClockComment = String.Empty;

                    DialogService.ShowMessage(AppResource.Success, AppResource.Clock_Out_Success);

                    await GetClockInOutDetails(isBackground: true);

                    tcs.TrySetResult();
                },

                isBackground: true,

                onFailure: () =>
                {
                    tcs.TrySetResult();
                }
            );

            return;
        }

        private void OpenInOutCommentsPopup(ClockEntry clockEntry)
        {
            NavigationService.ShowPopup(new ClockInOutPopup(clockEntry.InComment, clockEntry.OutComment));
        }

        #endregion


        #region Public Methods

        #endregion
    }
}
