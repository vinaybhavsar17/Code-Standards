﻿using Newtonsoft.Json;
using OfficerReports.Constants;
using OfficerReports.Converters;
using OfficerReports.Helpers;
using OfficerReports.Interfaces;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.Site;
using OfficerReports.Models.TruckCheckInOut;
using OfficerReports.Resources.Strings;
using OfficerReports.Services;
using OfficerReports.Services.Base;
using OfficerReports.Services.Site;
using OfficerReports.Services.Storage;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static Android.Provider.ContactsContract.CommonDataKinds;

namespace OfficerReports.ViewModels
{
    public class CustomReportViewModel : FormPageBaseViewModel
    {
        #region Internal Variables/Constants

        private SiteMenuItemDetails _siteMenuItemDetails;
        private CustomReportControls _customReportControls;
        private ISiteService _siteService;
        private ICustomReportService _customReportService;
        private IAzureStorageService _azureStorageService;
        public ICustomReportRenderer CustomReportRenderer;
        public SiteMenuItem SiteMenuItem { get; set; }

        #endregion


        #region Bindable Properties

        private ObservableDictionary<string, object> _customReportFields;
        public ObservableDictionary<string, object> CustomReportFields
        {
            get { return _customReportFields; }
            set
            {
                _customReportFields = value;
                RaisePropertyChanged(() => CustomReportFields);
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }

        #endregion


        #region Constructors

        public CustomReportViewModel(ISiteService siteService,
            ICustomReportService customReportService,
            IAzureStorageService azureStorageService)
        {
            _siteService = siteService;
            _customReportService = customReportService;
            _azureStorageService = azureStorageService;
        }

        #endregion


        #region Overridden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = SiteMenuItem.ActivityName;

            GetCustomReportJson();

            return base.InitializeAsync(query);
        }

        protected override void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            base.OnPropertyChanged(propertyName);

            if(propertyName == nameof(Files))
                ReportCacheManager.SetValue($"{GetType().Name}_{SiteMenuItem.ActivityId}", nameof(Files), Files);
        }

        protected override void ClearForm()
        {
            foreach (var item in CustomReportFields)
            {
                if (item.Value is string)
                    CustomReportFields[item.Key] = string.Empty;
                else if (item.Value is ObservableCollection<CheckboxField> checkboxes)
                {
                    foreach (var checkbox in checkboxes)
                    {
                        checkbox.Value = false;
                    }
                    CustomReportFields[item.Key] = new ObservableCollection<CheckboxField>(checkboxes.ToList());
                }
                else
                    CustomReportFields[item.Key] = null;
            }

            Files?.Clear();

            RaisePropertyChanged(() => CustomReportFields);

            ClearCache();
        }

        protected override async void OnSubmitCompleted(ApiResponse response)
        {
            ClearCache();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, string.Format(AppResource.Custom_Report_Submitted_Successfully, SiteMenuItem.ActivityName));
        }

        protected async override void SubmitForm()
        {
            await Dispatcher.DispatchAsync(() =>
            {
                var reportDataJson = ConvertReportDataToJson();
                var customReportRequest = new CustomReportRequest
                {
                    ClientId = SiteMenuViewModel.Site.ClientId,
                    CustomerId = _siteMenuItemDetails.CustomerId,
                    ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                    CustomReportId = _siteMenuItemDetails.CustomReportId,
                    ReportDataJson = reportDataJson,
                    IsAttachmentAdded = Files != null && Files.Count > 0
                };

                CallApi(
                    apiMethod: async () => await _customReportService.CreateCustomReportRequest(customReportRequest),

                    onSuccess: async (response) =>
                    {
                        if (Files != null && Files.Count > 0)
                        {
                            if (response.IsCached)
                            {
                                ((ApiBaseService)_customReportService).CacheFiles(Files.ToList(), response.CachedDataId, 0, AppConstants.PurposeCustomReports);
                            }
                            else
                            {
                                var entityId = response.Data.entityId;
                                var entityTypeId = response.Data.entityTypeId;

                                var request = new CustomReportEntityRequest
                                {
                                    CustomReportDataId = entityId,
                                    CustomReportId = entityTypeId
                                };

                                var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeCustomReports, Files.ToList(), request);

                                if (!uploaded)
                                {
                                    await NavigationService.PopAsync();
                                    DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                    return;
                                }
                            }
                        }
                        OnSubmitCompleted(response);
                    }
                );
            });
        }

        #endregion


        #region Private Methods

        private void GetCustomReportJson()
        {
            CallApi(

               apiMethod: async () => await _siteService.GetSiteMenuItemDetails(SiteMenuItem.ActivityId),

               onSuccess: (response) => {
                   _siteMenuItemDetails = response.ProcessedData as SiteMenuItemDetails;
                   var deserializerSettings = new JsonSerializerSettings();
                   deserializerSettings.Converters.Add(new LocalDateTimeConverter());
                   _customReportControls = JsonConvert.DeserializeObject<CustomReportControls>(_siteMenuItemDetails.ReportJson, deserializerSettings);
                   CustomReportRenderer?.RenderReport(_customReportControls, _siteMenuItemDetails.UploadEnabled);

                   SetBindableProperties(_customReportControls);
               }
            );
        }

        private void SetBindableProperties(CustomReportControls customReportControls)
        {
            var cachedData = GetCachedData();
            var isCachedFromPreviousSession = false;
            CustomReportFields = new ObservableDictionary<string, object>();

            foreach (var section in customReportControls.Sections)
            {
                foreach (var field in section.Fields)
                {
                    bool isCached;

                    if (field.FieldType.Equals(AppConstants.CustomReportCheckbox))
                        isCached = InitCustomReportField($"{section.Title}{field.DisplayName}", new ObservableCollection<CheckboxField>(field.CheckBoxes), cachedData);
                    else
                        isCached = InitCustomReportField($"{section.Title}{field.DisplayName}", null, cachedData);

                    if (isCached)
                        isCachedFromPreviousSession = isCached;

                    if (field.IsMandatory)
                        Validator.AddField($"{section.Title}{field.DisplayName}");
                }
            }

            RaisePropertyChanged(() => CustomReportFields);

            CustomReportFields.PropertyChanged += CustomReportPropertyChanged;


            Files = GetCachedFiles();
            if (Files != null)
                isCachedFromPreviousSession = true;


            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        private void CustomReportPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName.Equals("Values"))
                ReportCacheManager.SetValue($"{GetType().Name}_{SiteMenuItem.ActivityId}", nameof(CustomReportFields), CustomReportFields);
        }

        private bool InitCustomReportField(string key, object defaultValue, ObservableDictionary<string, object> cachedData)
        {
            bool isCached = false;
            var value = defaultValue;
            if (cachedData != null && cachedData.ContainsKey(key))
            {
                var cachedValue = cachedData[key];
                if (cachedValue != null)
                {
                    if(defaultValue != null)
                    {
                        var defaultValueType = defaultValue.GetType();
                        var typeCastedValue = JsonConvert.DeserializeObject(cachedValue.ToString(), defaultValueType);
                        value = typeCastedValue;
                    }
                    else
                    {
                        value = cachedValue;
                    }

                    isCached = true;
                }
            }
            CustomReportFields[key] = value;

            return isCached;
        }

        private void ClearCache()
        {
            ReportCacheManager.DeleteValue($"{GetType().Name}_{SiteMenuItem.ActivityId}", nameof(CustomReportFields));
            ReportCacheManager.DeleteValue($"{GetType().Name}_{SiteMenuItem.ActivityId}", nameof(Files));
        }

        private ObservableDictionary<string, object> GetCachedData()
        {
            var dataStr = ReportCacheManager.GetValue($"{GetType().Name}_{SiteMenuItem.ActivityId}", nameof(CustomReportFields));
            return JsonConvert.DeserializeObject<ObservableDictionary<string, object>>(dataStr);
        }

        private ObservableCollection<Models.FileInfo> GetCachedFiles()
        {
            var dataStr = ReportCacheManager.GetValue($"{GetType().Name}_{SiteMenuItem.ActivityId}", nameof(Files));
            return JsonConvert.DeserializeObject<ObservableCollection<Models.FileInfo>>(dataStr);
        }

        private string ConvertReportDataToJson()
        {
            string json = null;
            try
            {
                foreach (var section in _customReportControls.Sections)
                {
                    foreach (var field in section.Fields)
                    {
                        var value = CustomReportFields[$"{section.Title}{field.DisplayName}"];
                        if (value == null)
                            continue;

                        if (field.FieldType.Equals(AppConstants.CustomReportCheckbox))
                            field.CheckBoxes = (value as ObservableCollection<CheckboxField>).ToList();
                        else if (field.FieldType.Equals(AppConstants.CustomReportDateTime))
                            field.Date = DateTime.ParseExact(value.ToString(), AppConstants.DateTimeFormat, null).ToString("O");
                        else
                            field.FieldValue = value.ToString();
                    }
                }

                json = JsonConvert.SerializeObject(_customReportControls);
            }
            catch (Exception ex)
            {
            }

            return json;
        }

        #endregion
    }
}
