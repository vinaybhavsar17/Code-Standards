﻿using OfficerReports.Resources.Strings;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ViewModels
{
    public class PdfViewerViewModel : ViewModelBase
    {
        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Pdf_Viewer;

            return base.InitializeAsync(query);
        }

        #endregion
    }
}
