﻿using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels
{
    public class AsotLogViewModel : ViewModelBase
    {
        private static AsotLogViewModel _instance;

        private static string _log = string.Empty;
        public string Log
        {
            get { return _log; }
            set
            {
                _log = value;
                RaisePropertyChanged(() => Log);
            }
        }

        public ICommand ClearLogCommand => new Command(() => ClearLog());

        public AsotLogViewModel()
        {
            _instance = this;
        }

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = "Asot Logs";

            return base.InitializeAsync(query);
        }

        public override void OnAppearing()
        {
            base.OnAppearing();

            MessagingCenter.Subscribe<string>(this, "AddLog", OnAddLog);
        }

        public override void OnDisappearing()
        {
            base.OnDisappearing();

            MessagingCenter.Unsubscribe<string>(this, "AddLog");
        }

        private void OnAddLog(string s)
        {
            RaisePropertyChanged(() => Log);
        }

        public static void AddLog(string log)
        {
            var logToAdd = $"{DateTime.Now}\n{log}\n\n";
            _log = _log.Insert(0, logToAdd);

            MessagingCenter.Send("Sender", "AddLog");
        }

        private void ClearLog()
        {
            Log = string.Empty;
            _log = string.Empty;
        }
    }
}
