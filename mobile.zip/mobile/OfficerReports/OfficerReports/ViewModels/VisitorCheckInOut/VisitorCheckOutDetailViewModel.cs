﻿using OfficerReports.Models.VisitorCheckInOut;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.VisitorCheckInOut;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.VisitorCheckInOut
{
    public class VisitorCheckOutDetailViewModel : ViewModelBase
    {

        #region Internal Variables/Constants
        private IVisitorCheckInOutService _visitorCheckInOutService;
        #endregion

        #region Bindable Properties

        private VisitorCheckOutRecord _visitorCheckOutDetail;
        public VisitorCheckOutRecord VisitorCheckOutDetail
        {
            get { return _visitorCheckOutDetail; }
            set
            {
                _visitorCheckOutDetail = value;
                RaisePropertyChanged(() => VisitorCheckOutDetail);
            }
        }


        private string _noteExit;
        public string NoteExit
        {
            get { return _noteExit; }
            set
            {
                _noteExit = value;
                RaisePropertyChanged(() => NoteExit);
            }
        }

        #endregion

        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Visitor_Details;
            return base.InitializeAsync(query);
        }
        #endregion

        #region Commands

        public ICommand VisitorCheckOutCommand => new Command(() => CheckOutVisitor());

        #endregion


        #region Constructors
        public VisitorCheckOutDetailViewModel(IVisitorCheckInOutService visitorCheckInOutService)
        {
            _visitorCheckInOutService = visitorCheckInOutService;
        }

        #endregion

        #region Private Methods
        private void CheckOutVisitor()
        {   
            var createVisitorCheckInOutRequest = new CreateVisitorCheckInOutRequest
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                VisitorLogId = _visitorCheckOutDetail.VisitorLogId,
                Company = _visitorCheckOutDetail.Company,
                VisitorName = _visitorCheckOutDetail.VisitorName,
                VisitorIdTypeId = _visitorCheckOutDetail.VisitorIdTypeId,
                VisitorIdOther = _visitorCheckOutDetail.VisitorIdOther,
                VisitorIdTypeName = _visitorCheckOutDetail.VisitorIdTypeName,
                InNotes = _visitorCheckOutDetail.InNotes,
                BadgeNumber = _visitorCheckOutDetail.BadgeNumber,
                FaceCovering = _visitorCheckOutDetail.FaceCovering,
                Lpnumber = _visitorCheckOutDetail.Lpnumber,
                Temperature = _visitorCheckOutDetail.Temperature,
                Destination = _visitorCheckOutDetail.Destination,
                OutNotes = NoteExit,
                IsOut = 1,
                OutDate = DateTime.Now.ToString("O"),
                UserId = _visitorCheckOutDetail.UserId,
                OutUserId = _visitorCheckOutDetail.UserId,
                InUserId = _visitorCheckOutDetail.UserId,
                InDate = _visitorCheckOutDetail.InDate

            };

            CallApi(
                apiMethod: async () => await _visitorCheckInOutService.UpdateVisitorCheckOutRecord(createVisitorCheckInOutRequest),
                onSuccess: (response) =>
                {
                    VisitorCheckOutDetail.IsOut = 1;
                    OnSubmitCompleted();
                }
             );
        }

        private async void OnSubmitCompleted()
        {
            await NavigationService.PopAsync();
            DialogService.ShowMessage(AppResource.Success, AppResource.Visitor_Check_Out_Success);
        }

        #endregion


    }
}
