﻿using OfficerReports.Resources.Strings;
using OfficerReports.ViewModels.Base;
using OfficerReports.Services.VisitorCheckInOut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Services.Storage;
using OfficerReports.Services.User;
using OfficerReports.Services.Base;
using OfficerReports.Models.Incident;
using System.Collections.ObjectModel;
using OfficerReports.Constants;
using OfficerReports.Models.VisitorCheckInOut;
using OfficerReports.Models.Base;
using OfficerReports.Models;

namespace OfficerReports.ViewModels.VisitorCheckInOut
{
    public class VisitorCheckInViewModel : FormPageBaseViewModel
    {

        #region Internal Variables/Constants
        private IVisitorCheckInOutService _visitorCheckInOutService;
        private IUserService _userService;
        private IAzureStorageService _azureStorageService;
        private int _userID;
        private int _clientSiteId;
        #endregion

        #region bindable properties

        private ObservableCollection<VisitorTypeItem> _visitorTypeItems;
        public ObservableCollection<VisitorTypeItem> VisitorTypeItems
        {
            get { return _visitorTypeItems; }
            set
            {
                _visitorTypeItems = value;
                RaisePropertyChanged(() => VisitorTypeItems);
            }
        }

        private VisitorTypeItem _selectedVisitorType;
        public VisitorTypeItem SelectedVisitorType
        {
            get { return _selectedVisitorType; }
            set
            {
                _selectedVisitorType = value;
                if (value != null)
                {
                    if (_selectedVisitorType.TypeDataName == AppConstants.TypeOther)
                    {
                        OtherVisitorTypeEnableDisable = true;
                    }
                    else
                    {
                        OtherVisitorType = string.Empty;
                        OtherVisitorTypeEnableDisable = false;
                    }
                }
                OnPropertyChanged(nameof(SelectedVisitorType));
            }
        }

        private bool _otherVisitorTypeEnableDisable;
        public bool OtherVisitorTypeEnableDisable
        {
            get { return _otherVisitorTypeEnableDisable; }
            set
            {
                _otherVisitorTypeEnableDisable = value;
                OnPropertyChanged(nameof(OtherVisitorTypeEnableDisable));
            }
        }

        private string _visitorName;
        public string VisitorName
        {
            get { return _visitorName; }
            set
            {
                _visitorName = value;
                RaisePropertyChanged(() => VisitorName);
            }
        }

        private string _destination;
        public string Destination
        {
            get { return _destination; }
            set
            {
                _destination = value;
                RaisePropertyChanged(() => Destination);
            }
        }

        private string _inNote;
        public string InNote
        {
            get { return _inNote; }
            set
            {
                _inNote = value;
                RaisePropertyChanged(() => InNote);
            }
        }

        private string _licencePlateNumber;
        public string LicencePlateNumber
        {
            get { return _licencePlateNumber; }
            set
            {
                _licencePlateNumber = value;
                RaisePropertyChanged(() => LicencePlateNumber);
            }
        }

        private string _badgeNumber;
        public string BadgeNumber
        {
            get { return _badgeNumber;}
            set
            {
                _badgeNumber = value;
                RaisePropertyChanged(() => BadgeNumber);
            }
        }

        private string _temperature;
        public string Temperature
        {
            get { return _temperature; }
            set
            {
                _temperature = value;
                RaisePropertyChanged(() => Temperature);
            }
        }

        private string _company;
        public string Company
        {
            get { return _company; }
            set
            {
                _company = value;
                RaisePropertyChanged(() => Company);
            }
        }
        private string _otherVisitorType;
        public string OtherVisitorType
        {
            get { return _otherVisitorType; }
            set
            {
                _otherVisitorType = value;
                RaisePropertyChanged(() => OtherVisitorType);
            }
        }

        private int _selectedVisitorTypeItem;
        public int SelectedVisitorTypeItem
        {
            get { return _selectedVisitorTypeItem; }
            set
            {
                _selectedVisitorTypeItem = value;
                OnPropertyChanged(nameof(SelectedVisitorTypeItem));
            }
        }

        private ObservableCollection<string> _faceCoveringYesOrNo;
        public ObservableCollection<string> FaceCoveringYesOrNo
        {
            get { return _faceCoveringYesOrNo; }
            set
            {
                _faceCoveringYesOrNo = value;
                OnPropertyChanged(nameof(FaceCoveringYesOrNo));
            }
        }

        private string _selectedOptionfaceCovering;
        public string SelectedOptionfaceCovering
        {
            get { return _selectedOptionfaceCovering; }
            set
            {
                _selectedOptionfaceCovering = value;
                OnPropertyChanged(nameof(SelectedOptionfaceCovering));
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }
        #endregion

        #region Constructor        
        public VisitorCheckInViewModel(IVisitorCheckInOutService visitorCheckInOutService, IUserService userService, IAzureStorageService azureStorageService)
        {
            _visitorCheckInOutService = visitorCheckInOutService;
            _userService = userService;
            _azureStorageService = azureStorageService;
        }
        #endregion



        #region Override Methods
        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Visitor_Check_In;
            LoadData();
            GetVisitorIdTypes();
            return base.InitializeAsync(query);
        }

        protected override void SetValidationFields()
        {
            base.SetValidationFields();

            Validator.AddField(nameof(VisitorName));
            Validator.AddField(nameof(Destination));
            Validator.AddField(nameof(SelectedVisitorType));
            Validator.AddField(nameof(InNote));
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            VisitorName = GetCachedProperty<string>(nameof(VisitorName), data, ref isCachedFromPreviousSession);
            Destination = GetCachedProperty<string>(nameof(Destination), data, ref isCachedFromPreviousSession);

            var selectedVisitorType = GetCachedProperty<VisitorTypeItem>(nameof(SelectedVisitorType), data, ref isCachedFromPreviousSession);
            if (selectedVisitorType != null && VisitorTypeItems != null)
            {
                SelectedVisitorType = VisitorTypeItems.Where(o => o.TypeDataId == selectedVisitorType.TypeDataId).FirstOrDefault();
            }

            OtherVisitorType = GetCachedProperty<string>(nameof(OtherVisitorType), data, ref isCachedFromPreviousSession);
            BadgeNumber = GetCachedProperty<string>(nameof(BadgeNumber), data, ref isCachedFromPreviousSession);
            LicencePlateNumber = GetCachedProperty<string>(nameof(LicencePlateNumber), data, ref isCachedFromPreviousSession);
            Temperature = GetCachedProperty<string>(nameof(Temperature), data, ref isCachedFromPreviousSession);
            SelectedOptionfaceCovering = GetCachedProperty<string>(nameof(SelectedOptionfaceCovering), data, ref isCachedFromPreviousSession);
            Company = GetCachedProperty<string>(nameof(Company), data, ref isCachedFromPreviousSession);
            InNote = GetCachedProperty<string>(nameof(InNote), data, ref isCachedFromPreviousSession);

            Files = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(Files), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        protected override void ClearForm()
        {
            Validator.Reset();

            VisitorName = string.Empty;
            Destination = string.Empty;
            OtherVisitorType = string.Empty;
            BadgeNumber = string.Empty;
            LicencePlateNumber = string.Empty;
            Temperature = string.Empty;
            SelectedOptionfaceCovering = string.Empty;
            Company = string.Empty;
            InNote = string.Empty;
            SelectedVisitorType = null;
            SelectedVisitorTypeItem = -1;

            Files?.Clear();

            ClearCachedProperties();
        }

        protected async override void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Visitor_CheckIn_Success);
        }

        protected override void SubmitForm()
        {

            var visitorCheckInRequest = new VisitorCheckInRequest
            {
                ClientSiteId = _clientSiteId,
                VisitorName = VisitorName,
                Destination = Destination,
                InNotes = InNote,
                Lpnumber = LicencePlateNumber,
                Company = Company,
                FaceCovering = SelectedOptionfaceCovering,
                BadgeNumber = BadgeNumber,
                Temperature = Temperature,
                VisitorIdTypeId = SelectedVisitorType.TypeDataId,
                VisitorIdOther = OtherVisitorType,
                InUserId = _userID.ToString(),
                UserId = _userID.ToString(),
                CreatedById = _userID.ToString(),
                InDate = DateTime.Now.ToString("O"),
                CreatedDate = DateTime.Now.ToString("O"),
                IsAttachmentAdded = Files != null && Files.Count > 0
            };
            CallApi(

                apiMethod: async () => await _visitorCheckInOutService.CreateVisitorCheckInRequest(visitorCheckInRequest),

                onSuccess: async (response) =>
                {
                    if (Files != null && Files.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_visitorCheckInOutService).CacheFiles(Files.ToList(), response.CachedDataId, EntityRequest.EntityTypeVisitorLog, AppConstants.PurposeReports);
                        }
                        else
                        {
                            var reportId = response.Data.reportId;
                            var request = new EntityRequest
                            {
                                EntityId = reportId,
                                EntityTypeId = EntityRequest.EntityTypeVisitorLog
                            };

                            var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, Files.ToList(), request);

                            if (!uploaded)
                            {
                                await NavigationService.PopAsync();
                                DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                return;
                            }
                        }
                    }
                    OnSubmitCompleted(response);
                }
            );
        }
        #endregion

        #region private methods
        private void LoadData()
        {
            _clientSiteId = SiteMenuViewModel.Site.ClientSiteId;
            var user = _userService.GetLoggedInUserInfo();
            _userID = user.UserId;
            var list = new List<string>
            {
              AppResource.No,
              AppResource.Yes
            };
            FaceCoveringYesOrNo = new ObservableCollection<string>(list);
        }

        private void GetVisitorIdTypes()
        {
            CallApi(
               apiMethod: async () => await _visitorCheckInOutService.GetVisitorIdTypes(),
               onSuccess: (response) => {
                   var result = response.ProcessedData;
                   VisitorIdType objectList = result as VisitorIdType;
                   var data = objectList.Data;
                   var list = (List<VisitorTypeItem>)data;
                   VisitorTypeItems = new ObservableCollection<VisitorTypeItem>(list);
               }
            );
        }
        #endregion
    }
}

