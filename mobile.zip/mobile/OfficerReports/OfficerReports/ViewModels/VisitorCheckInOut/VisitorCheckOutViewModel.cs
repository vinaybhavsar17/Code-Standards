﻿using Java.Util;
using OfficerReports.Models.TruckCheckInOut;
using OfficerReports.Models.VisitorCheckInOut;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.VisitorCheckInOut;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.VisitorCheckInOut;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.VisitorCheckInOut
{
    public class VisitorCheckOutViewModel : ViewModelBase
    {
        #region Internal Variables/Constants
        private IVisitorCheckInOutService _visitorCheckInOutService;
        #endregion

        #region Bindable Properties

        private ObservableCollection<VisitorCheckOutRecord> _visitorCheckOutRecords;
        public ObservableCollection<VisitorCheckOutRecord> VisitorCheckOutRecords
        {
            get { return _visitorCheckOutRecords; }
            set
            {
                _visitorCheckOutRecords = value;
                RaisePropertyChanged(() => VisitorCheckOutRecords);
            }

        }
        #endregion


        #region Commands
        public ICommand SelectTruckCheckOutLogCommand => new Command<VisitorCheckOutRecord>((visitorCheckOutRecord) => SelectPassOnRead(visitorCheckOutRecord));
        #endregion


        #region Constructor        

        public VisitorCheckOutViewModel(IVisitorCheckInOutService visitorCheckInOutService)
        {
            _visitorCheckInOutService = visitorCheckInOutService;
            VisitorCheckOutRecords = new ObservableCollection<VisitorCheckOutRecord>();
        }

        #endregion


        #region Override Methods

        public override void OnAppearing()
        {
            base.OnAppearing();
            AddVisitorCheckOutLogs(VisitorCheckOutRecords);
        }


        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Visitor_Check_Out;
            FetchVisitorCheckOutLogRecords();
            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Method

        private void SelectPassOnRead(VisitorCheckOutRecord visitorCheckOutRecord)
        {
            NavigationService.PushAsync(new VisitorCheckOutDetailView(visitorCheckOutRecord));
        }

        private void FetchVisitorCheckOutLogRecords()
        {
            CallApi(

               apiMethod: async () => await _visitorCheckInOutService.GetVisitorCheckOutRecords(),
               onSuccess: (response) => {
                   var result = response.ProcessedData;
                   var list = (List<VisitorCheckOutRecord>)result;
                   if(list != null)
                   {
                       var visitorCheckOutRecords = new ObservableCollection<VisitorCheckOutRecord>(list);
                       AddVisitorCheckOutLogs(visitorCheckOutRecords);
                   }
               }
            );
        }

        private void AddVisitorCheckOutLogs(ObservableCollection<VisitorCheckOutRecord> visitorCheckOutRecords)
        {
            var list = visitorCheckOutRecords.Where((r) => r.IsOut == 0).ToList();
            VisitorCheckOutRecords = new ObservableCollection<VisitorCheckOutRecord>(list);
        }

        #endregion
    }
}
