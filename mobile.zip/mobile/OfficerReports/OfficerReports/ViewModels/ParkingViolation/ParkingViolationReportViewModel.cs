﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.ParkingViolation;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.ParkingViolation;
using OfficerReports.Services.Storage;
using OfficerReports.Services.User;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.ParkingViolation
{
    public class ParkingViolationReportViewModel : ViewModelBase
    {
        #region Internal Variables/Constants
        private IUserService _userService;
        private IAzureStorageService _azureStorageService;
        private IParkingViolationService _parkingViolationReportService;


        private int _clientSideID;
        private int _userID;
        #endregion

        #region Bindable Properties

        private string _officer;
        public string Officer
        {
            get { return _officer; }
            set
            {
                _officer = value;
                RaisePropertyChanged(() => Officer);
            }
        }

        private string _client;
        public string Client
        {
            get { return _client; }
            set
            {
                _client = value;
                RaisePropertyChanged(() => Client);
            }
        }

        private string _site;
        public string Site
        {
            get { return _site; }
            set
            {
                _site = value;
                RaisePropertyChanged(() => Site);
            }
        }

        private ObservableCollection<ParkingViolationTypeItem> _parkingViolationTypes;
        public ObservableCollection<ParkingViolationTypeItem> ParkingViolationTypes
        {
            get { return _parkingViolationTypes; }
            set
            {
                _parkingViolationTypes = value;
                OnPropertyChanged(nameof(ParkingViolationTypes));
            }
        }

        private int _selectedItemIndex;
        public int SelectedItemIndex
        {
            get { return _selectedItemIndex; }
            set
            {
                _selectedItemIndex = value;
                OnPropertyChanged(nameof(SelectedItemIndex));
            }
        }

        private ParkingViolationTypeItem _selectedParkingViolationType;
        public ParkingViolationTypeItem SelectedParkingViolationType
        {
            get { return _selectedParkingViolationType; }
            set
            {
                _selectedParkingViolationType = value;
                if (value != null) {
                    if (value.TypeDataName == "Other"){
                        ParkingViolationTypeFieldIsEnabled = true;
                    }
                    else {
                        IfViolationOtherType = string.Empty;
                        ParkingViolationTypeFieldIsEnabled = false;
                    }
                }
                OnPropertyChanged(nameof(SelectedParkingViolationType));
            }
        }

        private bool _parkingViolationTypeFieldIsEnabled;
        public bool ParkingViolationTypeFieldIsEnabled
        {
            get { return _parkingViolationTypeFieldIsEnabled; }
            set
            {
                _parkingViolationTypeFieldIsEnabled = value;
                OnPropertyChanged(nameof(ParkingViolationTypeFieldIsEnabled));
            }
        }

        private ObservableCollection<string> _wasVehicleTowed;
        public ObservableCollection<string> WasVehicleTowed
        {
            get { return _wasVehicleTowed; }
            set
            {
                _wasVehicleTowed = value;
                OnPropertyChanged(nameof(WasVehicleTowed));
            }
        }

        private int _selectedItemIndexWasVehicleTowed;
        public int SelectedItemIndexWasVehicleTowed
        {
            get { return _selectedItemIndexWasVehicleTowed; }
            set
            {
                _selectedItemIndexWasVehicleTowed = value;
                OnPropertyChanged(nameof(SelectedItemIndexWasVehicleTowed));
            }
        }

        private string _selectedItemWasVehicleTowed;
        public string SelectedItemWasVehicleTowed
        {
            get { return _selectedItemWasVehicleTowed; }
            set
            {
                _selectedItemWasVehicleTowed = value;
                OnPropertyChanged(nameof(SelectedItemWasVehicleTowed));
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }

        private string _details;
        public string Details
        {
            get { return _details; }
            set
            {
                _details = value;
                RaisePropertyChanged(() => Details);
            }
        }

        private string _violatorFirstName;
        public string ViolatorFirstName
        {
            get { return _violatorFirstName; }
            set
            {
                _violatorFirstName = value;
                RaisePropertyChanged(() => ViolatorFirstName);
            }
        }

        private string _violatorLastName;
        public string ViolatorLastName
        {
            get { return _violatorLastName; }
            set
            {
                _violatorLastName = value;
                RaisePropertyChanged(() => ViolatorLastName);
            }
        }

        private string _vehicleMake;
        public string VehicleMake
        {
            get { return _vehicleMake; }
            set
            {
                _vehicleMake = value;
                RaisePropertyChanged(() => VehicleMake);
            }
        }

        private string _vehiclemodel;
        public string VehicleModel
        {
            get { return _vehiclemodel; }
            set
            {
                _vehiclemodel = value;
                RaisePropertyChanged(() => VehicleModel);
            }
        }

        private string _licensePlateNo;
        public string LicensePlateNo
        {
            get { return _licensePlateNo; }
            set
            {
                _licensePlateNo = value;
                RaisePropertyChanged(() => LicensePlateNo);
            }
        }

        private string _vIN;
        public string VIN
        {
            get { return _vIN; }
            set
            {
                _vIN = value;
                RaisePropertyChanged(() => VIN);
            }
        }

        private string _vehicleColor;
        public string VehicleColor
        {
            get { return _vehicleColor; }
            set
            {
                _vehicleColor = value;
                RaisePropertyChanged(() => VehicleColor);
            }
        }

        private string _violationType;
        public string ViolationType
        {
            get { return _violationType; }
            set
            {
                _violationType = value;
                RaisePropertyChanged(() => ViolationType);
            }
        }

        private string _ifViolationOtherType;
        public string IfViolationOtherType
        {
            get { return _ifViolationOtherType; }
            set
            {
                _ifViolationOtherType = value;
                RaisePropertyChanged(() => IfViolationOtherType);
            }
        }

        private string _violationNumber;
        public string ViolationNumber
        {
            get { return _violationNumber; }
            set
            {
                _violationNumber = value;
                RaisePropertyChanged(() => ViolationNumber);
            }
        }

        private string _location;
        public string Location
        {
            get { return _location; }
            set
            {
                _location = value;
                RaisePropertyChanged(() => Location);
            }
        }

        private string _fine;
        public string Fine
        {
            get { return _fine; }
            set
            {
                _fine = value;
                RaisePropertyChanged(() => Fine);
            }
        }

        #endregion

        #region Commands

        public ICommand SubmitCommand => new Command(() => SubmitForm());
        public ICommand ClearCommand => new Command(() => ClearForm());

        #endregion

        #region Constructor

        public ParkingViolationReportViewModel(
            IUserService userService,
            IAzureStorageService azureStorageService,
            IParkingViolationService parkingViolationReportService
        )
        {
            _userService = userService;
            _azureStorageService = azureStorageService;
            _parkingViolationReportService = parkingViolationReportService;
        }

        #endregion


        #region  Override Methods
        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Parking_Violation;
            LoadData();
            GetParkingViolationTypes();
            return base.InitializeAsync(query);
        }

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(ParkingViolationTypes));
            Validator.AddField(nameof(VehicleMake));
            Validator.AddField(nameof(VehicleModel));
            Validator.AddField(nameof(LicensePlateNo));
            Validator.AddField(nameof(WasVehicleTowed));
            Validator.AddField(nameof(Location));
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            ViolatorFirstName = GetCachedProperty<string>(nameof(ViolatorFirstName), data, ref isCachedFromPreviousSession);
            ViolatorLastName = GetCachedProperty<string>(nameof(ViolatorLastName), data, ref isCachedFromPreviousSession);
            VehicleMake = GetCachedProperty<string>(nameof(VehicleMake), data, ref isCachedFromPreviousSession);
            VehicleModel = GetCachedProperty<string>(nameof(VehicleModel), data, ref isCachedFromPreviousSession);
            LicensePlateNo = GetCachedProperty<string>(nameof(LicensePlateNo), data, ref isCachedFromPreviousSession);
            VIN = GetCachedProperty<string>(nameof(VIN), data, ref isCachedFromPreviousSession);
            VehicleColor = GetCachedProperty<string>(nameof(VehicleColor), data, ref isCachedFromPreviousSession);

            var selectedParkingViolationType = GetCachedProperty<ParkingViolationTypeItem>(nameof(SelectedParkingViolationType), data, ref isCachedFromPreviousSession);
            if (selectedParkingViolationType != null && ParkingViolationTypes != null)
            {
                SelectedParkingViolationType = ParkingViolationTypes.Where(o => o.TypeDataId == selectedParkingViolationType.TypeDataId).FirstOrDefault();
            }

            IfViolationOtherType = GetCachedProperty<string>(nameof(IfViolationOtherType), data, ref isCachedFromPreviousSession);
            ViolationNumber = GetCachedProperty<string>(nameof(ViolationNumber), data, ref isCachedFromPreviousSession);
            Location = GetCachedProperty<string>(nameof(Location), data, ref isCachedFromPreviousSession);
            Fine = GetCachedProperty<string>(nameof(Fine), data, ref isCachedFromPreviousSession);
            SelectedItemWasVehicleTowed = GetCachedProperty<string>(nameof(SelectedItemWasVehicleTowed), data, ref isCachedFromPreviousSession);
            Details = GetCachedProperty<string>(nameof(Details), data, ref isCachedFromPreviousSession);

            Files = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(Files), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        #endregion


        #region Private Methods

        private void LoadData()
        {
            var user = _userService.GetLoggedInUserInfo();
            Officer = user.FullName;
            _userID = user.UserId;
            _clientSideID = SiteMenuViewModel.Site.ClientSiteId;
            Site = SiteMenuViewModel.Site.SiteName;
            Client = SiteMenuViewModel.Site.ClientName;

            var list = new List<string>
            {
              AppResource.No,
              AppResource.Yes
             };

            WasVehicleTowed = new ObservableCollection<string>(list);
        }

        private void GetParkingViolationTypes()
        {
            CallApi(

               apiMethod: async () => await _parkingViolationReportService.GetParkingViolationType(),

               onSuccess: (response) => {
                   var result = response.ProcessedData;
                   ParkingViolationType objectList = result as ParkingViolationType;
                   var data = objectList.Data;
                   var list = (List<ParkingViolationTypeItem>)data;
                   ParkingViolationTypes = new ObservableCollection<ParkingViolationTypeItem>(list);

               }
            );
        }

        private void SubmitForm()
        {

            if (!Validator.Validate())
                return;

            var createParkingViolationReportRequest = new CreateParkingViolationReportRequest
            {
                ClientSiteId = _clientSideID.ToString(),
                ParkingViolationTypeId = _selectedParkingViolationType.TypeDataId.ToString(),
                TypeIfOther = IfViolationOtherType,
                Detail = Details,
                ViolatorFirstName = ViolatorFirstName,
                ViolatorLastName = ViolatorLastName,
                VehicleMake = VehicleMake,
                VehicleModel = VehicleModel,
                LicensePlateNumber = LicensePlateNo,
                Location = Location,
                VehicleColor = VehicleColor,
                Fine = Fine,
                Vin = VIN,
                ViolationNumber = ViolationNumber,
                VehicleTowed = WasVehicleTowed[_selectedItemIndexWasVehicleTowed],
                IsAttachmentAdded = Files != null && Files.Count > 0
            };

            CallApi(
                apiMethod: async () => await _parkingViolationReportService.CreateParkingViolationReportRequest(createParkingViolationReportRequest),

                onSuccess: async (response) => {

                    if (Files != null && Files.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_parkingViolationReportService).CacheFiles(Files.ToList(), response.CachedDataId, EntityRequest.EntityTypeParkingViolation, AppConstants.PurposeReports);
                        }
                        else
                        {
                            var reportId = response.Data.reportId;

                            var request = new EntityRequest
                            {
                                EntityId = reportId,
                                EntityTypeId = EntityRequest.EntityTypeParkingViolation
                            };

                            var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, Files.ToList(), request);

                            if (!uploaded)
                            {
                                await NavigationService.PopAsync();
                                DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                return;
                            }
                        }
                    }
                    OnSubmitCompleted(response);
                }
            );

        }

        private async void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Parking_Violation_Report_Submitted);
        }

        private void ClearForm()
        {
            Validator.Reset();

            ViolatorFirstName = string.Empty;
            ViolatorLastName = string.Empty;
            ViolationType = string.Empty;
            VIN = string.Empty;
            Fine = string.Empty;
            VehicleColor = string.Empty;
            ViolationNumber = string.Empty;
            VehicleMake = string.Empty;
            VehicleModel = string.Empty;
            LicensePlateNo = string.Empty;
            Location = string.Empty;
            Details = string.Empty; 
            IfViolationOtherType = string.Empty;
            SelectedParkingViolationType = null;
            SelectedItemIndexWasVehicleTowed = -1;
            Files?.Clear();

            ClearCachedProperties();
        }

        #endregion

    }
}
