﻿using OfficerReports.Models.ParkingViolation;
using OfficerReports.Resources.Strings;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ViewModels.ParkingViolation
{
    public class ParkingViolationDetailsViewModel : ViewModelBase
    {
        #region Bindable Properties

        private ParkingViolationRecord _parkingViolationRecord;
        public ParkingViolationRecord ParkingViolationRecord
        {
            get { return _parkingViolationRecord; }
            set
            {
                _parkingViolationRecord = value;
                OnPropertyChanged(nameof(ParkingViolationRecord));
            }
        }

        #endregion

        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Parking_Violation_Details;

            return base.InitializeAsync(query);
        }

        #endregion
    }
}
