﻿using OfficerReports.Models.ParkingViolation;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.ParkingViolation;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.ParkingViolation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.ParkingViolation
{
    public class ParkingViolationSearchResultViewModel : ViewModelBase
    {

        #region Internal Variables/Constants

        public const int PageSize = 25;

        private IParkingViolationService _parkingViolationReportService;

        private ParkingViolationSearchRequest _searchRequest;
        public ParkingViolationSearchRequest SearchRequest
        {
            get
            {
                return _searchRequest;
            }
            set
            {
                _searchRequest = value;
            }
        }

        private ParkingViolationSearchResult _searchResponse;
        public ParkingViolationSearchResult SearchResponse { 
            get 
            {
                return _searchResponse;
            } 
            set 
            {
                _searchResponse = value;

                if (_searchResponse.Records == null)
                    _searchResponse.Records = new List<ParkingViolationRecord>();

                ParkingViolations = new ObservableCollection<ParkingViolationRecord>(_searchResponse.Records);
            } 
        }

        #endregion


        #region Bindable Properties

        private ObservableCollection<ParkingViolationRecord> _parkingViolations;
        public ObservableCollection<ParkingViolationRecord> ParkingViolations
        {
            get { return _parkingViolations; }
            set
            {
                _parkingViolations = value;
                RaisePropertyChanged(() => ParkingViolations);
            }

        }

        #endregion


        #region Commands

        public ICommand SelectParkingViolationCommand => new Command<ParkingViolationRecord>((parkingViolation) => SelectParkingViolation(parkingViolation));

        public ICommand LoadMoreRecordsCommand => new Command(() => LoadMoreRecords());

        #endregion


        #region Constructor        

        public ParkingViolationSearchResultViewModel(IParkingViolationService parkingViolationReportService)
        {
            _parkingViolationReportService = parkingViolationReportService;
        }

        #endregion


        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Parking_Violation_Search;

            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Method

        private void SelectParkingViolation(ParkingViolationRecord parkingViolationRecord)
        {
            NavigationService.PushAsync(new ParkingViolationDetailsView(parkingViolationRecord));
        }

        private void LoadMoreRecords()
        {
            if (IsBusy)
                return;

            if (ParkingViolations.Count >= SearchResponse.Count)
                return;

            SearchRequest.GridFilters.First = ParkingViolations.Count;

            IsBusy = true;
            CallApi(

               apiMethod: async () => await _parkingViolationReportService.SearchParkingViolations(SearchRequest),

               onSuccess: (response) => {
                   var searchResult = (ParkingViolationSearchResult)response.ProcessedData;

                   foreach (var record in searchResult.Records)
                   {
                       ParkingViolations.Add(record);
                   }

                   IsBusy = false;
               },

               isBackground: true,

               onFailure: () =>
               {
                   IsBusy = false;
               }
            );
        }

        #endregion

    }
}
