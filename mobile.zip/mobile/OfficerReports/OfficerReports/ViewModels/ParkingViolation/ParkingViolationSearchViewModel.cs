﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.ParkingViolation;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.ParkingViolation;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.ParkingViolation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ViewModels.ParkingViolation
{
    public class ParkingViolationSearchViewModel : FormPageBaseViewModel
    {
        #region Internal Variables/Constants

        private IParkingViolationService _parkingViolationReportService;

        #endregion


        #region Bindable Properties

        private ObservableCollection<ParkingViolationTypeItem> _parkingViolationTypes;
        public ObservableCollection<ParkingViolationTypeItem> ParkingViolationTypes
        {
            get { return _parkingViolationTypes; }
            set
            {
                _parkingViolationTypes = value;
                OnPropertyChanged(nameof(ParkingViolationTypes));
            }
        }

        private ParkingViolationTypeItem _selectedParkingViolationType;
        public ParkingViolationTypeItem SelectedParkingViolationType
        {
            get { return _selectedParkingViolationType; }
            set
            {
                _selectedParkingViolationType = value;
                OnPropertyChanged(nameof(SelectedParkingViolationType));
            }
        }

        private string _licensePlateNumber;
        public string LicensePlateNumber
        {
            get { return _licensePlateNumber; }
            set
            {
                _licensePlateNumber = value;
                OnPropertyChanged(nameof(LicensePlateNumber));
            }
        }

        #endregion


        #region Constructor

        public ParkingViolationSearchViewModel(
            IParkingViolationService parkingViolationReportService
        )
        {
            _parkingViolationReportService = parkingViolationReportService;
        }

        #endregion


        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            var task = base.InitializeAsync(query);

            HeaderTitle = AppResource.Parking_Violation_Search;

            GetParkingViolationTypes();

            return task;
        }

        protected override void SubmitForm()
        {
            var searchRequest = new ParkingViolationSearchRequest
            {
                ParkingViolationsTypeId = SelectedParkingViolationType != null ? SelectedParkingViolationType.TypeDataId : 0,
                LicensePlateNumber = LicensePlateNumber,
                From = DateTime.Today.Subtract(TimeSpan.FromDays(AppConstants.SearchDurationInDays)).ToString("O"),
                To = DateTime.Now.ToString("O"),
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                LicensePlateNumberBySearch = 3,
                GridFilters = new Paging
                {
                    First = 0,
                    Rows = ParkingViolationSearchResultViewModel.PageSize,
                    SortOrder = Paging.SortOrderDescending,
                    SortField = String.Empty
                }
            };

            CallApi(

               apiMethod: async () => await _parkingViolationReportService.SearchParkingViolations(searchRequest),

               onSuccess: (response) => {
                   var searchResult = (ParkingViolationSearchResult)response.ProcessedData;
                   NavigationService.PushAsync(new ParkingViolationSearchResultView(searchRequest, searchResult));
               }
            );
        }

        protected override void ClearForm()
        {
            SelectedParkingViolationType = null;
            LicensePlateNumber = String.Empty;
        }

        protected override void OnSubmitCompleted(ApiResponse response)
        {
        }

        #endregion


        #region Private Methods

        private void GetParkingViolationTypes()
        {
            CallApi(

               apiMethod: async () => await _parkingViolationReportService.GetParkingViolationType(),

               onSuccess: (response) => {
                   ParkingViolationType parkingViolationType = response.ProcessedData as ParkingViolationType;
                   ParkingViolationTypes = new ObservableCollection<ParkingViolationTypeItem>(parkingViolationType.Data);
               }
            );
        }

        #endregion
    }
}
