﻿using System;
using System.Collections.ObjectModel;
using OfficerReports.Models.Scheduler;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Scheduler;
using OfficerReports.ViewModels.Base;
using Syncfusion.Maui.Scheduler;

namespace OfficerReports.ViewModels.Scheduler
{
	public class SchedulerViewModel : ViewModelBase
	{
        #region Internal Variables/Constants

        private ISchedulerService _schedulerService;

        #endregion


        #region Bindable Properties

        private ObservableCollection<Schedule> _schedules;
        public ObservableCollection<Schedule> Schedules
        {
            get { return _schedules; }
            set
            {
                _schedules = value;
                RaisePropertyChanged(() => Schedules);
            }
        }

        #endregion


        #region Constructors

        public SchedulerViewModel(ISchedulerService schedulerService)
        {
            _schedulerService = schedulerService;
        }

        #endregion


        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.View_Schedule;

            if(MenuViewModel.LoggedInUser.RoleName == Models.Authentication.User.OfficerRole)
                GetScheduleByOfficer();
            else
                GetScheduleByCustomer();

            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Methods

        private void GetScheduleByOfficer()
        {
            CallApi(

                apiMethod: async () => await _schedulerService.GetScheduleByOfficer(),

                onSuccess: (response) =>
                {
                    var list = (List<Schedule>)response.ProcessedData;
                    Schedules = new ObservableCollection<Schedule>(list);
                }

            );
        }

        private void GetScheduleByCustomer()
        {
            CallApi(

                apiMethod: async () => await _schedulerService.GetScheduleByCustomer(),

                onSuccess: (response) =>
                {
                    var list = (List<Schedule>)response.ProcessedData;
                    Schedules = new ObservableCollection<Schedule>(list);
                }

            );
        }

        #endregion
    }
}

