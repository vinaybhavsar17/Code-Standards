﻿using OfficerReports.Services.PassOnLog;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views;
using OfficerReports.Services.Storage;
using OfficerReports.Services.TruckCheckInOut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Models.TruckCheckInOut;
using OfficerReports.Resources.Strings;
using System.Windows.Input;

namespace OfficerReports.ViewModels.TruckCheckInOut
{
    public class TruckCheckOutDetailViewModel : ViewModelBase
    {
        #region Internal Variables/Constants
        private ITruckCheckInOutService _truckCheckInOutService;
        #endregion

        #region Bindable Properties

        private TruckCheckOutRecord _truckCheckOutDetail;
        public TruckCheckOutRecord TruckCheckOutDetail
        {
            get { return _truckCheckOutDetail; }
            set
            {
                _truckCheckOutDetail = value;
                RaisePropertyChanged(() => TruckCheckOutDetail);
            }
        }

        private string _outboundDriver;
        public string OutboundDriver
        {
            get { return _outboundDriver; }
            set
            {
                _outboundDriver = value;
                RaisePropertyChanged(() => OutboundDriver);
            }
        }

        private string _noteExit;
        public string NoteExit
        {
            get { return _noteExit; }
            set
            {
                _noteExit = value;
                RaisePropertyChanged(() => NoteExit);
            }
        }

        private string _trailerNumberOut;
        public string TrailerNumberOut
        {
            get { return _trailerNumberOut; }
            set
            {
                _trailerNumberOut = value;
                RaisePropertyChanged(() => TrailerNumberOut);
            }
        }

        private string _sealNumberOut;
        public string SealNumberOut
        {
            get { return _sealNumberOut; }
            set
            {
                _sealNumberOut = value;
                RaisePropertyChanged(() => SealNumberOut);
            }
        }

        #endregion

        #region Overriden Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Truck_Check_Out_Details;
            return base.InitializeAsync(query);
        }
        #endregion

        #region Commands

        public ICommand TruckCheckOutCommand => new Command(() => CheckOutTruck());

        #endregion


        #region Constructors
        public TruckCheckOutDetailViewModel(ITruckCheckInOutService truckCheckInOutService)
        {
            _truckCheckInOutService = truckCheckInOutService;
        }

        #endregion

        #region Private Methods

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(OutboundDriver));
        }


        private void CheckOutTruck()
        {
            if (!Validator.Validate())
                return;

            var createTruckCheckOutReportRequest = new CreateTruckCheckOutReportRequest
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                TruckLogId = _truckCheckOutDetail.TruckLogId,
                Company = _truckCheckOutDetail.Company,
                DockBayNumber = _truckCheckOutDetail.DockBayNumber,
                InDriver = _truckCheckOutDetail.InDriver,
                InNotes = _truckCheckOutDetail.InNotes,
                InSealNumber = _truckCheckOutDetail.InSealNumber,
                InTrailerNumber = _truckCheckOutDetail.InTrailerNumber,
                Lpnumber = _truckCheckOutDetail.Lpnumber,
                TractorNumber = _truckCheckOutDetail.TractorNumber,
                Vin = _truckCheckOutDetail.Vin,
                OutDriver = OutboundDriver,
                OutSealNumber = SealNumberOut,
                OutTrailerNumber = TrailerNumberOut,
                OutNotes = NoteExit,
                IsOut = 1,
                OutDate = DateTime.Now.ToString("O"),
                UserId = _truckCheckOutDetail.InUserId,
                OutUserId = _truckCheckOutDetail.InUserId,
                InUserId = _truckCheckOutDetail.InUserId,
                InDate = _truckCheckOutDetail.InDate

            };

            CallApi(
                apiMethod: async () => await _truckCheckInOutService.CreateTruckCheckOutReportRequest(createTruckCheckOutReportRequest),
                onSuccess: (response) =>
                {
                    TruckCheckOutDetail.IsOut = 1;
                    OnSubmitCompleted();
                }
             );
        }

        private async void OnSubmitCompleted()
        {
            await NavigationService.PopAsync();
            DialogService.ShowMessage(AppResource.Success, AppResource.Truck_Check_Out_Success);
        }

        #endregion
    }
}
