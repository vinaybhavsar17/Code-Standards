﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.MaintenanceReport;
using OfficerReports.Models.TruckCheckInOut;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.PassOnLog;
using OfficerReports.Services.Storage;
using OfficerReports.Services.Base;
using OfficerReports.Services.TruckCheckInOut;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ViewModels.TruckCheckInOut
{
    public class TruckCheckInViewModel : FormPageBaseViewModel
    {
        #region Internal Variables/Constants
        private IAzureStorageService _azureStorageService;
        private ITruckCheckInOutService _truckCheckInOutService;
        #endregion

        #region Bindable Properties

        private string _companyName;
        public string CompanyName
        {
            get { return _companyName; }
            set
            {
                _companyName = value;
                RaisePropertyChanged(() => CompanyName);
            }
        }

        private string _dockBayNumber;
        public string DockBayNumber
        {
            get { return _dockBayNumber; }
            set
            {
                _dockBayNumber = value;
                RaisePropertyChanged(() => DockBayNumber);
            }
        }

        private string _driverName;
        public string DriverName
        {
            get { return _driverName; }
            set
            {
                _driverName = value;
                RaisePropertyChanged(() => DriverName);
            }
        }

        private string _note;
        public string Note
        {
            get { return _note; }
            set
            {
                _note = value;
                RaisePropertyChanged(() => Note);
            }
        }

        private string _sealNumber;
        public string SealNumber
        {
            get { return _sealNumber; }
            set
            {
                _sealNumber = value;
                RaisePropertyChanged(() => SealNumber);
            }
        }

        private string _trailerNumber;
        public string TrailerNumber
        {
            get { return _trailerNumber; }
            set
            {
                _trailerNumber = value;
                RaisePropertyChanged(() => TrailerNumber);
            }
        }

        private string _lPNumber;
        public string LPNumber
        {
            get { return _lPNumber; }
            set
            {
                _lPNumber = value;
                RaisePropertyChanged(() => LPNumber);
            }
        }

        private string _tractorNumber;
        public string TractorNumber
        {
            get { return _tractorNumber; }
            set
            {
                _tractorNumber = value;
                RaisePropertyChanged(() => TractorNumber);
            }
        }

        private string _vin;
        public string VIN
        {
            get { return _vin; }
            set
            {
                _vin = value;
                RaisePropertyChanged(() => VIN);
            }
        }

        private ObservableCollection<Models.FileInfo> _files;
        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }

        #endregion

        #region Constructor

        public TruckCheckInViewModel(IAzureStorageService azureStorageService, ITruckCheckInOutService truckCheckInOutService)
        {
            _azureStorageService = azureStorageService;
            _truckCheckInOutService = truckCheckInOutService;
        }

        #endregion


        #region Override Methods
        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            var task = base.InitializeAsync(query);
            HeaderTitle = AppResource.Truck_Check_In;
            return task;
        }

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(CompanyName));
            Validator.AddField(nameof(DriverName));
            Validator.AddField(nameof(TractorNumber));
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            CompanyName = GetCachedProperty<string>(nameof(CompanyName), data, ref isCachedFromPreviousSession);
            DriverName = GetCachedProperty<string>(nameof(DriverName), data, ref isCachedFromPreviousSession);
            TractorNumber = GetCachedProperty<string>(nameof(TractorNumber), data, ref isCachedFromPreviousSession);
            LPNumber = GetCachedProperty<string>(nameof(LPNumber), data, ref isCachedFromPreviousSession);
            VIN = GetCachedProperty<string>(nameof(VIN), data, ref isCachedFromPreviousSession);
            TrailerNumber = GetCachedProperty<string>(nameof(TrailerNumber), data, ref isCachedFromPreviousSession);
            SealNumber = GetCachedProperty<string>(nameof(SealNumber), data, ref isCachedFromPreviousSession);
            DockBayNumber = GetCachedProperty<string>(nameof(DockBayNumber), data, ref isCachedFromPreviousSession);
            Note = GetCachedProperty<string>(nameof(Note), data, ref isCachedFromPreviousSession);

            Files = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(Files), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        protected override void ClearForm()
        {
            CompanyName = string.Empty;
            DriverName = string.Empty;
            TractorNumber = string.Empty;
            LPNumber = string.Empty;
            VIN = string.Empty;
            TrailerNumber = string.Empty;
            SealNumber = string.Empty;
            DockBayNumber = string.Empty;
            Note = string.Empty;
            Files?.Clear();

            ClearCachedProperties();
        }

        protected async override void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Truck_Check_In_Report_Submitted);
        }

        protected override void SubmitForm()
        {
            var createTruckCheckInReportRequest = new CreateTruckCheckInReportRequest
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                Company = CompanyName,
                DockBayNumber = DockBayNumber,
                InDriver = DriverName,
                InNotes = Note,
                InSealNumber = SealNumber,
                InTrailerNumber = TrailerNumber,
                Lpnumber = LPNumber,
                TractorNumber = TractorNumber,
                Vin = VIN,
                IsAttachmentAdded = Files != null && Files.Count > 0
            };

            CallApi(
                apiMethod: async () => await _truckCheckInOutService.CreateTruckCheckInReportRequest(createTruckCheckInReportRequest),

                onSuccess: async (response) => {

                    if (Files != null && Files.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_truckCheckInOutService).CacheFiles(Files.ToList(), response.CachedDataId, EntityRequest.EntityTypeTruckLog, AppConstants.PurposeReports);
                        }
                        else
                        {
                            var reportId = response.Data.reportId;

                            var request = new EntityRequest
                            {
                                EntityId = reportId,
                                EntityTypeId = EntityRequest.EntityTypeTruckLog
                            };

                            var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, Files.ToList(), request);

                            if (!uploaded)
                            {
                                await NavigationService.PopAsync();
                                DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                return;
                            }
                        }
                    }
                    OnSubmitCompleted(response);
                }
            );

        }

        #endregion

       
        #region Private Methods

        #endregion

        
    }
}
