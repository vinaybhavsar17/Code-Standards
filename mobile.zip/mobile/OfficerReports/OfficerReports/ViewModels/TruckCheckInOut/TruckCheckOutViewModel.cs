﻿using OfficerReports.Models.TruckCheckInOut;
using OfficerReports.Models.VisitorCheckInOut;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.PassOnLog;
using OfficerReports.Services.TruckCheckInOut;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.TruckCheckInOut;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace OfficerReports.ViewModels.TruckCheckInOut
{
    public class TruckCheckOutViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private ITruckCheckInOutService _truckCheckInOutService;

        #endregion

        #region Bindable Properties

        private ObservableCollection<TruckCheckOutRecord> _truckCheckOutRecords;
        public ObservableCollection<TruckCheckOutRecord> TruckCheckOutRecords
        {
            get { return _truckCheckOutRecords; }
            set
            {
                _truckCheckOutRecords = value;
                RaisePropertyChanged(() => TruckCheckOutRecords);
            }

        }

        #endregion


        #region Commands
        public ICommand SelectTruckCheckOutLogCommand => new Command<TruckCheckOutRecord>((truckCheckOutRecord) => SelectTruckCheckOutRecord(truckCheckOutRecord));

        #endregion


        #region Constructor        

        public TruckCheckOutViewModel(ITruckCheckInOutService truckCheckInOutService)
        {
            _truckCheckInOutService = truckCheckInOutService;
            TruckCheckOutRecords = new ObservableCollection<TruckCheckOutRecord>();
        }

        #endregion


        #region Override Methods
        public override void OnAppearing()
        {
            base.OnAppearing();
            AddTruckCheckoutLogs(TruckCheckOutRecords);
        }

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Truck_Check_Out;
            FetchTruckCheckOutLogRecords();
            return base.InitializeAsync(query);
        }

        #endregion


        #region Private Method

        private void SelectTruckCheckOutRecord(TruckCheckOutRecord truckCheckOutRecord)
        {
            NavigationService.PushAsync(new TruckCheckOutDetailView(truckCheckOutRecord));
        }

        private void FetchTruckCheckOutLogRecords()
        {
            CallApi(

               apiMethod: async () => await _truckCheckInOutService.GetTruckCheckOutRecords(),
               onSuccess: (response) => {
                   var result = response.ProcessedData;
                   var list = (List<TruckCheckOutRecord>)result;
                   if (list != null)
                   {
                       var truckCheckOutRecords = new ObservableCollection<TruckCheckOutRecord>(list);
                       AddTruckCheckoutLogs(truckCheckOutRecords);
                   }
               }
            );
        }

        private void AddTruckCheckoutLogs(ObservableCollection<TruckCheckOutRecord> truckCheckOutRecords)
        {
            var list = truckCheckOutRecords.Where((r) => r.IsOut == 0).ToList();
            TruckCheckOutRecords = new ObservableCollection<TruckCheckOutRecord>(list);
        }
        #endregion
    }
}
