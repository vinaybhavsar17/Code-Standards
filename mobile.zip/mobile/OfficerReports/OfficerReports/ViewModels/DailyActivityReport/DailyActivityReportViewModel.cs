﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.DailyActivityReport;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Base;
using OfficerReports.Services.DailyActivityReport;
using OfficerReports.Services.Storage;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.DailyActivityReport;
using OfficerReports.Helpers;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace OfficerReports.ViewModels.DailyActivityReport
{
    public class DailyActivityReportViewModel : ViewModelBase
    {
        #region Internal Variables/Constants

        private IUserService _userService;
        private IDailyActivityReportService _dailyActivityReportService;
        private IAzureStorageService _azureStorageService;

        private int _clientSideID;
        private int _userID;
        private List<ObservationTypeItem> _observationTypes;

        #endregion Internal Variables/Constants

        #region Bindable Properties

        private string _officer;

        public string Officer
        {
            get { return _officer; }
            set
            {
                _officer = value;
                RaisePropertyChanged(() => Officer);
            }
        }

        private string _client;

        public string Client
        {
            get { return _client; }
            set
            {
                _client = value;
                RaisePropertyChanged(() => Client);
            }
        }

        private string _site;

        public string Site
        {
            get { return _site; }
            set
            {
                _site = value;
                RaisePropertyChanged(() => Site);
            }
        }

        private string _postShift;

        public string PostShift
        {
            get { return _postShift; }
            set
            {
                _postShift = value;
                RaisePropertyChanged(() => PostShift);
            }
        }

        private string _specialInstruction = string.Empty;

        public string SpecialInstruction
        {
            get { return _specialInstruction; }
            set
            {
                _specialInstruction = value;
                RaisePropertyChanged(() => SpecialInstruction);
            }
        }

        private string _postItemReceived;

        public string PostItemReceived
        {
            get { return _postItemReceived; }
            set
            {
                _postItemReceived = value;
                RaisePropertyChanged(() => PostItemReceived);
            }
        }

        private string _relievingOfficerFirstName;

        public string RelievingOfficerFirstName
        {
            get { return _relievingOfficerFirstName; }
            set
            {
                _relievingOfficerFirstName = value;
                RaisePropertyChanged(() => RelievingOfficerFirstName);
            }
        }

        private string _relievingOfficerLastName;

        public string RelievingOfficerLastName
        {
            get { return _relievingOfficerLastName; }
            set
            {
                _relievingOfficerLastName = value;
                RaisePropertyChanged(() => RelievingOfficerLastName);
            }
        }

        private ObservableCollection<Observation> _observations = new ObservableCollection<Observation>();

        public ObservableCollection<Observation> Observations
        {
            get { return _observations; }
            set
            {
                _observations = value;
                RaisePropertyChanged(() => Observations);
            }
        }

        private ObservableCollection<Models.FileInfo> _files;

        public ObservableCollection<Models.FileInfo> Files
        {
            get { return _files; }
            set
            {
                _files = value;
                RaisePropertyChanged(() => Files);
            }
        }

        #endregion Bindable Properties

        #region Commands

        public ICommand AddObservationCommand => new Command(() => OpenAddObservationPopup());
        public ICommand EditObservationCommand => new Command<Observation>((observation) => OpenEditObservationPopup(observation));
        public ICommand RemoveObservationCommand => new Command<Observation>((observation) => RemoveObservation(observation));
        public ICommand SubmitCommand => new Command(() => SubmitForm());
        public ICommand ClearCommand => new Command(() => ClearForm());

        #endregion Commands

        #region Constructor

        public DailyActivityReportViewModel(
            IUserService userService,
            IDailyActivityReportService dailyActivityReportService,
            IAzureStorageService azureStorageService
        )
        {
            _userService = userService;
            _dailyActivityReportService = dailyActivityReportService;
            _azureStorageService = azureStorageService;
        }

        #endregion Constructor

        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Daily_Activity_Report;
            LoadData();
            GetObservationTypes();
            return base.InitializeAsync(query);
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            PostShift = GetCachedProperty<string>(nameof(PostShift), data, ref isCachedFromPreviousSession);
            SpecialInstruction = GetCachedProperty<string>(nameof(SpecialInstruction), data, ref isCachedFromPreviousSession);
            PostItemReceived = GetCachedProperty<string>(nameof(PostItemReceived), data, ref isCachedFromPreviousSession);
            RelievingOfficerFirstName = GetCachedProperty<string>(nameof(RelievingOfficerFirstName), data, ref isCachedFromPreviousSession);
            RelievingOfficerLastName = GetCachedProperty<string>(nameof(RelievingOfficerLastName), data, ref isCachedFromPreviousSession);

            var observations = GetCachedProperty<ObservableCollection<Observation>>(nameof(Observations), data, ref isCachedFromPreviousSession);
            if (observations != null)
            {
                foreach (var observation in observations)
                {
                    observation.ObservationType = _observationTypes.Where(o => o.TypeDataId == observation.ObservationTypeId).FirstOrDefault();
                }
                Observations = observations;
            }

            Files = GetCachedProperty<ObservableCollection<Models.FileInfo>>(nameof(Files), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        #endregion Override Methods

        #region Private Methods

        protected override void SetValidationFields()
        {
            Validator.AddField(nameof(PostShift));
            Validator.AddField(nameof(PostItemReceived));
            Validator.AddField(nameof(RelievingOfficerFirstName));
            Validator.AddField(nameof(RelievingOfficerLastName));
        }

        private void LoadData()
        {
            var user = _userService.GetLoggedInUserInfo();
            Officer = user.FullName;
            _userID = user.UserId;
            _clientSideID = SiteMenuViewModel.Site.ClientSiteId;
            Site = SiteMenuViewModel.Site.SiteName;
            Client = SiteMenuViewModel.Site.ClientName;
        }

        private void GetObservationTypes()
        {
            CallApi
            (
                apiMethod: async () => await _dailyActivityReportService.GetObservationTypes(),

                onSuccess: (response) =>
                {
                    _observationTypes = (response.ProcessedData as ObservationType).Data;
                }
            );
        }

        private async void OpenAddObservationPopup()
        {
            var observation = (Observation)await NavigationService.ShowPopupAsync(new AddObservationPopup(_observationTypes));

            if (observation != null)
            {
                Observations.Add(observation);
                RaisePropertyChanged(() => Observations);
            }
        }

        private void RemoveObservation(Observation observation)
        {
            Observations.Remove(observation);
            RaisePropertyChanged(() => Observations);
        }

        private async void OpenEditObservationPopup(Observation observation)
        {
            var updatedObservation = (Observation)await NavigationService.ShowPopupAsync(new AddObservationPopup(_observationTypes, observation));

            if (updatedObservation != null)
            {
                var i = Observations.IndexOf(observation);
                Observations.Remove(observation);
                Observations.Insert(i, updatedObservation);

                RaisePropertyChanged(() => Observations);
            }
        }

        private async void SubmitForm()
        {

            if (!Validator.Validate())
                return;

            var confirmed = await DialogService.Confirm(AppResource.Dar_Submit_Confirm);
            if (!confirmed)
                return;

            var createDailyActivityReportRequest = new CreateDailyActivityReportRequest
            {
                ClientSiteId = _clientSideID.ToString(),
                CreatedById = _userID.ToString(),
                PostItemsReceived = PostItemReceived,
                ObservationArray = Observations.ToList(),
                PostShift = PostShift,
                RelievingOfficerFirstName = RelievingOfficerFirstName,
                RelievingOfficerLastName = RelievingOfficerLastName,
                SpecialInstructions = SpecialInstruction != null ? SpecialInstruction : string.Empty,
                UserId = _userID.ToString(),
                IsAttachmentAdded = Files != null && Files.Count > 0
            };

            CallApi(
                apiMethod: async () => await _dailyActivityReportService.CreateDailyActivityReportRequest(createDailyActivityReportRequest),

                onSuccess: async (response) =>
                {
                    if (Files != null && Files.Count > 0)
                    {
                        if (response.IsCached)
                        {
                            ((ApiBaseService)_dailyActivityReportService).CacheFiles(Files.ToList(), response.CachedDataId, EntityRequest.EntityTypeDailyActivityReport, AppConstants.PurposeReports);
                        }
                        else
                        {
                            var reportId = response.Data.reportId;

                            var request = new EntityRequest
                            {
                                EntityId = reportId,
                                EntityTypeId = EntityRequest.EntityTypeDailyActivityReport
                            };

                            var uploaded = await _azureStorageService.UploadFiles(AppConstants.PurposeReports, Files.ToList(), request);

                            if (!uploaded)
                            {
                                await NavigationService.PopAsync();
                                DialogService.ShowMessage(AppResource.Alert, AppResource.File_Upload_Failed_Message);
                                return;
                            }
                        }
                    }

                    OnSubmitCompleted(response);
                }
            );
        }

        private async void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if(response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Daily_Activity_Report_Submit_Success);
        }

        private void ClearForm()
        {
            Validator.Reset();

            PostShift = string.Empty;
            SpecialInstruction = string.Empty;
            PostItemReceived = string.Empty;
            RelievingOfficerFirstName = string.Empty;
            RelievingOfficerLastName = string.Empty;

            Observations?.Clear();
            Files?.Clear();

            ClearCachedProperties();
        }

        #endregion Private Methods
    }
}