﻿using OfficerReports.Constants;
using OfficerReports.Models.TemperatureLog;
using OfficerReports.Models.Base;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.TemperatureLog;
using OfficerReports.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ViewModels.TemperatureLog
{
    public class TemperatureLogViewModel : FormPageBaseViewModel
    {
        #region Internal Variables/Constants

        private ITemperatureLogService _temperatureLogService;

        #endregion


        #region Bindable Properties

        private ObservableCollection<EquipmentTypeItem> _equipmentTypes;
        public ObservableCollection<EquipmentTypeItem> EquipmentTypes
        {
            get { return _equipmentTypes; }
            set
            {
                _equipmentTypes = value;
                OnPropertyChanged(nameof(EquipmentTypes));
            }
        }

        private EquipmentTypeItem _selectedEquipmentType;
        public EquipmentTypeItem SelectedEquipmentType
        {
            get { return _selectedEquipmentType; }
            set
            {
                _selectedEquipmentType = value;
                OnPropertyChanged(nameof(SelectedEquipmentType));

                if (_selectedEquipmentType != null)
                {
                    if (_selectedEquipmentType.TypeDataName == AppConstants.TypeOther)
                    {
                        OtherEquipmentTypeEnabled = true;
                    }
                    else
                    {
                        OtherEquipmentType = string.Empty;
                        OtherEquipmentTypeEnabled = false;
                    }
                }
            }
        }

        private bool _otherEquipmentTypeEnabled;
        public bool OtherEquipmentTypeEnabled
        {
            get { return _otherEquipmentTypeEnabled; }
            set
            {
                _otherEquipmentTypeEnabled = value;
                OnPropertyChanged(nameof(OtherEquipmentTypeEnabled));
            }
        }

        private string _otherEquipmentType = string.Empty;
        public string OtherEquipmentType
        {
            get { return _otherEquipmentType; }
            set
            {
                _otherEquipmentType = value;
                OnPropertyChanged(nameof(OtherEquipmentType));
            }
        }

        private string _equipmentId;
        public string EquipmentId
        {
            get { return _equipmentId; }
            set
            {
                _equipmentId = value;
                OnPropertyChanged(nameof(EquipmentId));
            }
        }

        private string _temperature;
        public string Temperature
        {
            get { return _temperature; }
            set
            {
                _temperature = value;
                OnPropertyChanged(nameof(Temperature));
            }
        }

        private string _humidity = string.Empty;
        public string Humidity
        {
            get { return _humidity; }
            set
            {
                _humidity = value;
                OnPropertyChanged(nameof(Humidity));
            }
        }

        private string _fuelLevel = string.Empty;
        public string FuelLevel
        {
            get { return _fuelLevel; }
            set
            {
                _fuelLevel = value;
                OnPropertyChanged(nameof(FuelLevel));
            }
        }

        private string _co2Level = string.Empty;
        public string Co2Level
        {
            get { return _co2Level; }
            set
            {
                _co2Level = value;
                OnPropertyChanged(nameof(Co2Level));
            }
        }

        #endregion


        #region Constructor

        public TemperatureLogViewModel(ITemperatureLogService temperatureLogService)
        {
            _temperatureLogService = temperatureLogService;
        }

        #endregion


        #region Override Methods

        public override Task InitializeAsync(IDictionary<string, object> query)
        {
            HeaderTitle = AppResource.Temperature_Log;

            GetEquipmentTypes();

            return base.InitializeAsync(query);
        }

        protected override void SetValidationFields()
        {
            base.SetValidationFields();

            Validator.AddField(nameof(SelectedEquipmentType));
            Validator.AddField(nameof(EquipmentId));
            Validator.AddField(nameof(Temperature));
            Validator.AddField(nameof(Humidity), true);
        }

        public override void LoadCachedProperties(IDictionary<string, string> data)
        {
            base.LoadCachedProperties(data);

            var isCachedFromPreviousSession = false;

            var selectedEquipmentType = GetCachedProperty<EquipmentTypeItem>(nameof(SelectedEquipmentType), data, ref isCachedFromPreviousSession);
            if (selectedEquipmentType != null && EquipmentTypes != null)
            {
                SelectedEquipmentType = EquipmentTypes.Where(o => o.TypeDataId == selectedEquipmentType.TypeDataId).FirstOrDefault();
            }

            OtherEquipmentType = GetCachedProperty<string>(nameof(OtherEquipmentType), data, ref isCachedFromPreviousSession);
            EquipmentId = GetCachedProperty<string>(nameof(EquipmentId), data, ref isCachedFromPreviousSession);
            Temperature = GetCachedProperty<string>(nameof(Temperature), data, ref isCachedFromPreviousSession);
            Humidity = GetCachedProperty<string>(nameof(Humidity), data, ref isCachedFromPreviousSession);
            FuelLevel = GetCachedProperty<string>(nameof(FuelLevel), data, ref isCachedFromPreviousSession);
            Co2Level = GetCachedProperty<string>(nameof(Co2Level), data, ref isCachedFromPreviousSession);

            if (isCachedFromPreviousSession)
                DialogService.ShowMessage(AppResource.Data_Recovered, AppResource.Data_Recover_Message);
        }

        protected override void ClearForm()
        {
            SelectedEquipmentType = null;
            OtherEquipmentType = string.Empty;
            EquipmentId = string.Empty;
            Temperature = string.Empty;
            Humidity = string.Empty;
            FuelLevel = string.Empty;
            Co2Level = string.Empty;

            ClearCachedProperties();
        }

        protected async override void OnSubmitCompleted(ApiResponse response)
        {
            ClearCachedProperties();

            await NavigationService.PopAsync();

            if (response.IsCached)
                DialogService.ShowMessage(AppResource.Success, response.Message);
            else
                DialogService.ShowMessage(AppResource.Success, AppResource.Temperature_Log_Submit_Success);
        }

        protected override void SubmitForm()
        {
            var request = new CreateTemperatureLogRequest
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                Co2Level = Co2Level,
                EquipmentId = EquipmentId,
                EquipmentTypeId = SelectedEquipmentType.TypeDataId,
                FuelLevel = FuelLevel,
                Humidity = Humidity,
                Temperature = float.Parse(Temperature)
            };

            CallApi(
            
                apiMethod: async() => await _temperatureLogService.CreateTemperatureLog(request),

                onSuccess: (response) =>
                {
                    OnSubmitCompleted(response);
                }
            );
        }

        #endregion

        #region Private Methods

        private void GetEquipmentTypes()
        {
            CallApi(

               apiMethod: async () => await _temperatureLogService.GetEquipmentTypes(),

               onSuccess: (response) => {
                   EquipmentType equipmentType = response.ProcessedData as EquipmentType;
                   EquipmentTypes = new ObservableCollection<EquipmentTypeItem>(equipmentType.Data);
               }
            );
        }

        #endregion
    }
}
