using OfficerReports.Interfaces;

namespace OfficerReports;

public partial class DefaultTheme : ResourceDictionary
{
	public DefaultTheme()
	{
		InitializeComponent();
	}
}