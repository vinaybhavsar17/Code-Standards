namespace OfficerReports.Resources.Styles;

public partial class AppStyles : ResourceDictionary
{
	public AppStyles()
	{
		InitializeComponent();
	}
}