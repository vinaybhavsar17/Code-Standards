﻿namespace OfficerReports;

using CommunityToolkit.Maui;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using OfficerReports.Services;
using OfficerReports.Services.ApiSecrets;
using OfficerReports.ViewModels;
using Syncfusion.Maui.Core.Hosting;
using ZXing.Net.Maui;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();

        builder.ConfigureSyncfusionCore();
        builder
			.UseMauiApp<App>()
			.UseMauiCommunityToolkit()
            .UseBarcodeReader()
			.ConfigureServices()
			.ConfigureViewModels()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("Lato-Regular.ttf", "LatoRegular");
				fonts.AddFont("Lato-Semibold.ttf", "LatoSemiBold");
				fonts.AddFont("Lato-Bold.ttf", "LatoBold");
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
			});

		var sp = builder.Services.BuildServiceProvider();
		builder.Services.AddLogging(logging => 
		{
			var secret = sp.GetRequiredService<IApiSecrets>()
							.GetApiSecret(Api.AppCenter, DevicePlatform.Android);
			logging.AddAppCenter(options => options.AppCenterAndroidSecret = secret);

            //Uncomment this line when iOS secret key is available
            //logging.AddAppCenter(options => options.AppCenteriOSSecret = "");

#if DEBUG
            logging.AddConsole();
#endif
        });

		return builder.Build();
	}
}
