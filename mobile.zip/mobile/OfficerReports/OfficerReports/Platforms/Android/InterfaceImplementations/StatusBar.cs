﻿using AndroidColor = Android.Graphics.Color;
using Color = Microsoft.Maui.Graphics.Color;

namespace OfficerReports.Interfaces
{
    public partial class StatusBar
    {
        public static partial int GetStatusBarHeight()
        {
            var height = 0;
            var resourceId = Platform.CurrentActivity.Resources.GetIdentifier("status_bar_height", "dimen", "android");
            if(resourceId > 0)
            {
                var density = Platform.CurrentActivity.Resources.DisplayMetrics.Density;
                height = (int)(Platform.CurrentActivity.Resources.GetDimensionPixelSize(resourceId) / density);
            }

            return height;
        }
    }
}
