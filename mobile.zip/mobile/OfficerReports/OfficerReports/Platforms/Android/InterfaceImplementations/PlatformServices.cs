﻿using Android.App;
using Android.Graphics;
using Android.Views.InputMethods;
using Android.Widget;
using AndroidX.ExifInterface.Media;
using Java.Net;
using Java.Util;
using OfficerReports.Models;
using OfficerReports.ViewModels;
using Path = System.IO.Path;

namespace OfficerReports.Interfaces
{
    public partial class PlatformServices
    {
        public static partial void DownloadFile(EntityFile file)
        {
            var uri = Android.Net.Uri.Parse(file.UploadUrl);
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.SetDestinationInExternalPublicDir(Android.OS.Environment.DirectoryDownloads, file.FileName);
            request.SetNotificationVisibility(DownloadVisibility.VisibleNotifyCompleted);
            DownloadManager manager = (DownloadManager)Android.App.Application.Context.GetSystemService(Service.DownloadService);
            manager.Enqueue(request);
        }

        public static partial void OpenKeyboard(Entry entry)
        {
            var view = (Android.Views.View)entry.Handler.PlatformView;
            var b = (view as EditText).RequestFocus();
            var inputMethodManager = (InputMethodManager)Android.App.Application.Context.GetSystemService(Service.InputMethodService);
            var result = inputMethodManager.ShowSoftInput(view, ShowFlags.Implicit);
        }

        public static partial void HideKeyboard(Entry entry)
        {
            var view = (Android.Views.View)entry.Handler.PlatformView;
            var inputMethodManager = (InputMethodManager)Android.App.Application.Context.GetSystemService(Service.InputMethodService);
            inputMethodManager.HideSoftInputFromWindow(view.WindowToken, 0);
        }

        public static partial void ShowToast(string text)
        {
            Toast toast = Toast.MakeText(Android.App.Application.Context, text, ToastLength.Long);
            toast.Show();
        }

        public static partial Task<DateTime> ShowDatePicker(DateTime minDate, DateTime maxDate)
        {
            var tcs = new TaskCompletionSource<DateTime>();

            var currentDate = DateTime.Now;
            var dateListener = new EventHandler<DatePickerDialog.DateSetEventArgs>((s, e) =>
            {
                tcs.TrySetResult(e.Date);
            });
            var datePicker = new DatePickerDialog(MainActivity.Instance, dateListener, currentDate.Year, currentDate.Month - 1, currentDate.Day);
            
            if (minDate != default(DateTime))
                datePicker.DatePicker.MinDate = new Java.Util.Date(minDate.ToString()).Time;
            if (maxDate != default(DateTime))
                datePicker.DatePicker.MaxDate = new Java.Util.Date(maxDate.ToString()).Time;

            AsotLogViewModel.AddLog($"Current date = {currentDate.ToString()} \n\n Min Date = {new Java.Util.Date(minDate.ToString())} \n\n Max Date = {new Java.Util.Date(maxDate.ToString())}");

            datePicker.Show();

            return tcs.Task;
        }

        public static partial Task<TimeSpan> ShowTimePicker()
        {
            var tcs = new TaskCompletionSource<TimeSpan>();

            var currentDate = DateTime.Now;
            var timeListener = new EventHandler<TimePickerDialog.TimeSetEventArgs>((s, e) =>
            {
                tcs.TrySetResult(new TimeSpan(e.HourOfDay, e.Minute, 0));
            });
            var timePicker = new TimePickerDialog(MainActivity.Instance, timeListener, currentDate.Hour, currentDate.Minute, false);
            timePicker.Show();

            return tcs.Task;
        }

        public static partial async Task<Models.FileInfo> ResizeCompressImage(string imagePath, string fileName, float maxWidthOrHeight)
        {
            // Load the bitmap
            Bitmap originalImage = await BitmapFactory.DecodeFileAsync(imagePath);

            float width = 0;
            float height = 0;
            float ar = (float)originalImage.Width / (float)originalImage.Height;
            if(originalImage.Width >= originalImage.Height && originalImage.Width > maxWidthOrHeight)
            {
                width = maxWidthOrHeight;
                height = width / ar;
            }
            else if (originalImage.Height >= originalImage.Width && originalImage.Height > maxWidthOrHeight)
            {
                width = maxWidthOrHeight;
                height = width / ar;
            }

            Bitmap resizedImage = Bitmap.CreateScaledBitmap(originalImage, (int)width, (int)height, false);
            using (MemoryStream ms = new MemoryStream())
            {
                resizedImage.Compress(Bitmap.CompressFormat.Jpeg, 70, ms);
                var imageData = ms.ToArray();

                var fn = $"Compressed_{fileName}";
                var systemFolderPath = FileSystem.CacheDirectory;
                var filePath = Path.Combine(systemFolderPath, fileName);
                await File.WriteAllBytesAsync(filePath, imageData);

                ExifInterface originalExif = new ExifInterface(imagePath);
                var orientation = originalExif.GetAttribute(ExifInterface.TagOrientation);

                ExifInterface newExif = new ExifInterface(filePath);
                newExif.SetAttribute(ExifInterface.TagOrientation, orientation);
                newExif.SaveAttributes();

                var file = new Models.FileInfo
                {
                    FileSize = ms.Length,
                    CompressedImagePath = filePath,
                    CreatedDate = DateTime.UtcNow
                };
                return file;
            }
        }

        public static partial string GetIPAddress(bool useIPv4 = true)
        {
            try
            {
                var interfaces = Collections.List(NetworkInterface.NetworkInterfaces);
                foreach (NetworkInterface intf in interfaces)
                {
                    var addrs = Collections.List(intf.InetAddresses);
                    foreach (InetAddress addr in addrs)
                    {
                        if (!addr.IsLoopbackAddress)
                        {
                            String sAddr = addr.HostAddress;
                            //boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
                            bool isIPv4 = sAddr.IndexOf(':') < 0;

                            if (useIPv4)
                            {
                                if (isIPv4)
                                    return sAddr;
                            }
                            else
                            {
                                if (!isIPv4)
                                {
                                    int delim = sAddr.IndexOf('%'); // drop ip6 zone suffix
                                    return delim < 0 ? sAddr.ToUpper() : sAddr.Substring(0, delim).ToUpper();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ignored) { } // for now eat exceptions
            return "";
        }
    }
}
