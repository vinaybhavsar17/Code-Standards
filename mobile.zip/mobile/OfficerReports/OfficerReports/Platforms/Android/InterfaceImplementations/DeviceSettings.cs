﻿using AndroidColor = Android.Graphics.Color;
using Color = Microsoft.Maui.Graphics.Color;


namespace OfficerReports.Interfaces
{
    public partial class DeviceSettings
    {
        public static partial bool OpenLocationSetting()
        {

            var intent = new Android.Content.Intent(Android.Provider.Settings.ActionLocationSourceSettings);
            Platform.CurrentActivity.StartActivity(intent);

            return true;
        }
    }
}