﻿using Android.Content;
using Android.Telephony;
using OfficerReports.Resources.Strings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    public partial class NetworkUtility
    {
        private static partial string GetNetworkType()
        {
            var context = MainApplication.Context;

            TelephonyManager mTelephonyManager = (TelephonyManager)context.GetSystemService(Context.TelephonyService);
            NetworkType networkType = NetworkType.Unknown;
#if ANDROID24_0_OR_GREATER
            networkType = mTelephonyManager.DataNetworkType;
#else
            networkType = mTelephonyManager.NetworkType;
#endif
            switch (networkType)
            {
                case NetworkType.Gprs:
                case NetworkType.Edge:
                case NetworkType.Cdma:
                case NetworkType.OneXrtt:
                case NetworkType.Iden:
                    return AppResource._2G;
                case NetworkType.Umts:
                case NetworkType.Evdo0:
                case NetworkType.EvdoA:
                case NetworkType.Hsdpa:
                case NetworkType.Hsupa:
                case NetworkType.Hspa:
                case NetworkType.EvdoB:
                case NetworkType.Ehrpd:
                case NetworkType.Hspap:
                    return AppResource._3G;
                case NetworkType.Lte:
                    return AppResource._4G;
                case NetworkType.Unknown:
                default:
                    return AppResource.Mobile_Internet;
            }
        }
    }
}
