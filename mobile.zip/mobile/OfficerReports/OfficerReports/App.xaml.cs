﻿
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Microsoft.Extensions.Logging;
using OfficerReports.ApiClient;
using OfficerReports.Constants;
using OfficerReports.Helpers;
using OfficerReports.Interfaces;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.ApiSecrets;
using OfficerReports.Services.Asot;
using OfficerReports.Services.Dialog;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.Navigation;
using OfficerReports.Services.User;
using OfficerReports.Views;
using OfficerReports.Views.User;
using OfficerReports.Views.Authentication;
using OfficerReports.Views.Vacation;

namespace OfficerReports;

public partial class App : Application
{
    public static IServiceProvider ServiceProvider { get; set; }
    public static ILogger<App> Logger { get; set; }

    public static readonly string MESSAGE_LOGOUT = "logout";
    public static readonly string MESSAGE_PASSWORD_EXPIRED = "password_expired";
    public static readonly string MESSAGE_RESUME = "resume";

    public static bool IsAndroid => DeviceInfo.Current.Platform == DevicePlatform.Android;
    public static bool IsIos => DeviceInfo.Current.Platform == DevicePlatform.iOS;

    public App(IServiceProvider serviceProvider, ILogger<App> logger)
	{
		InitializeComponent();

        Console.WriteLine("Initializing Officer Reports App");

		ServiceProvider = serviceProvider;
        Logger = logger;

        SetupAppCenter();

        SetupNavigation();
	}

    //We should remove this in future when there is appcenter support available for MAUI. It should be added from MauiProgram.cs file
    private void SetupAppCenter()
    {
        var secret = App.ServiceProvider.GetRequiredService<IApiSecrets>()
                            .GetApiSecret(Api.AppCenter, DevicePlatform.Android);
        AppCenter.Start("android=" + secret + ";",
                  //"ios={Your iOS App secret here};",
                  typeof(Analytics), typeof(Crashes));
    }

    private void SetupNavigation()
    {
        if (AuthTokenManager.IsValidToken())
        {
            var userService = App.ServiceProvider.GetRequiredService<IUserService>();
            MainPage = new NavigationPage(new MenuView(userService.GetLoggedInUserInfo()));
        }
        else
            MainPage = new NavigationPage(new LoginView());

        MessagingCenter.Subscribe<object>(this, MESSAGE_LOGOUT, (sender) => 
        {
            Logout();
        });

        MessagingCenter.Subscribe<object>(this, MESSAGE_PASSWORD_EXPIRED, (sender) =>
        {
            Logout();

            var navigationService = ServiceProvider.GetRequiredService<INavigationService>();
            navigationService.PushAsync(new ResetPasswordView(), false);
        });
    }

    protected override void OnResume()
    {
        base.OnResume();

        MessagingCenter.Send<App>(this, MESSAGE_RESUME);
    }

    private void Logout()
    {
        AuthTokenManager.Token = null;
        AuthTokenManager.IsMimic = false;

        var userService = App.ServiceProvider.GetRequiredService<IUserService>();
        userService.RemoveLoggedInUserInfo();

        var locationService = App.ServiceProvider.GetRequiredService<ILocationService>();
        locationService.StopLocationTracking();

        var asotService = App.ServiceProvider.GetRequiredService<IAsotService>();
        asotService.Destroy();

        MessagingCenter.Send<App>(this, AppConstants.MessageMimicStop);

        var navigationService = ServiceProvider.GetRequiredService<INavigationService>();
        navigationService.PushToRoot(new LoginView());
    }

    public enum ResourceFile
    {
        AppStyles,
        DefaultTheme
    }
    public static object GetResource(string key, ResourceFile resourceFile)
    {
        ResourceDictionary resource = null;
        object result = null;

        switch (resourceFile)
        {
            case ResourceFile.AppStyles:
                resource = App.Current.Resources.MergedDictionaries.LastOrDefault();
                break;
            case ResourceFile.DefaultTheme:
                resource = App.Current.Resources.MergedDictionaries.FirstOrDefault();
                break;
            default:
                break;
        }

        if (resource != null && resource.TryGetValue(key, out object style))
        {
            result = style;
        }

        return result;
    }
}
