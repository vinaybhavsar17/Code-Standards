﻿using OfficerReports.Constants;
using OfficerReports.Resources.Strings;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Converters
{
    public class DateTimeToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var providedDateTime = (DateTime)value;

            if (providedDateTime == default(DateTime)){
                return AppResource.NA;
            }
            else
            {
                return providedDateTime.ToString(AppConstants.DateTimeFormat);
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
