﻿using OfficerReports.Models.Vacation;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Converters
{
    public class VaacationRequestStatusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var style = default(object);
            
            switch ((int)value)
            {
                case VacationRequest.STATUS_PENDING:
                    App.Current.Resources.TryGetValue("OrangeTag", out style);
                    break;
                case VacationRequest.STATUS_APPROVED:
                    App.Current.Resources.TryGetValue("GreenTag", out style);
                    break;
                case VacationRequest.STATUS_REJECTED:
                    App.Current.Resources.TryGetValue("RedTag", out style);
                    break;
                case VacationRequest.STATUS_WITHDRAWN:
                    App.Current.Resources.TryGetValue("GreyTag", out style);
                    break;
                default:
                    break;
            }

            return (Style)style;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
