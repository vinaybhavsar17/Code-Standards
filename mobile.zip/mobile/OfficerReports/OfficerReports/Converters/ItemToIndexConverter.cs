﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Converters
{
    public class ItemToIndexConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int itemIndex = 0;

            var cv = parameter as CollectionView;
            if (cv != null && value != null)
            {
                var items = cv.ItemsSource.Cast<object>().ToList();
                if (cv.IsGrouped)
                {
                    foreach (var itemsGroup in items)
                    {
                        var innerItems = (itemsGroup as IEnumerable).Cast<object>().ToList();

                        var i = innerItems.FindIndex(v => object.ReferenceEquals(v, value));
                        if (i != -1)
                        {
                            itemIndex = i;
                            break;
                        }
                    }
                }
                else
                {
                    itemIndex = items.FindIndex(v => object.ReferenceEquals(v, value));
                }
            }

            return itemIndex + 1;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
