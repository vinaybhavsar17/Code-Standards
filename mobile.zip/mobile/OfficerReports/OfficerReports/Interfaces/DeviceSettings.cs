﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Interfaces
{
    public partial class DeviceSettings
    {
        public static partial bool OpenLocationSetting();
    }
}
