﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Interfaces
{
    public interface IProgressBarHandler
    {
        public double Progress { get; }

        public void SetProgress(double progress);

        public void SetMessage(string message);
    }
}
