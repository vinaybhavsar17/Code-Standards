﻿using OfficerReports.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Interfaces
{
    public partial class PlatformServices
    {
        public static partial void DownloadFile(EntityFile file);

        public static partial void OpenKeyboard(Entry entry);

        public static partial void HideKeyboard(Entry entry);

        public static partial void ShowToast(string text);

        public static partial Task<DateTime> ShowDatePicker(DateTime minDate, DateTime maxDate);

        public static partial Task<TimeSpan> ShowTimePicker();

        public static partial Task<Models.FileInfo> ResizeCompressImage(string imagePath, string fileName, float maxWidthOrHeight);

        public static partial string GetIPAddress(bool useIPv4 = true);
    }
}
