using OfficerReports.Behaviors;
using OfficerReports.Constants;
using OfficerReports.Controls;
using OfficerReports.Interfaces;
using OfficerReports.Models;
using OfficerReports.Models.Site;
using OfficerReports.Resources.Strings;
using OfficerReports.Resources.Styles;
using OfficerReports.ViewModels;
using OfficerReports.Views.Base;
using System.Collections.ObjectModel;
using System.ComponentModel;
using static System.Collections.Specialized.BitVector32;
using Entry = OfficerReports.Controls.Entry;

namespace OfficerReports.Views;

public partial class CustomReportView : FormPageBase, ICustomReportRenderer
{
    private List<EntryValidationBehavior> _validationBehaviors = new List<EntryValidationBehavior>();

	public CustomReportView(SiteMenuItem siteMenuItem)
	{
		InitializeComponent();
		(BindingContext as CustomReportViewModel).SiteMenuItem = siteMenuItem;
    }

	protected override void OnAppearing()
	{
        (BindingContext as CustomReportViewModel).CustomReportRenderer = this;
        base.OnAppearing();
	}

    public override void Validate()
    {
        base.Validate();

        foreach (var validationBehavior in _validationBehaviors)
        {
            validationBehavior.ForceValidate();
        }
    }

    public override void ResetValidation()
    {
        base.ResetValidation();

        foreach (var validationBehavior in _validationBehaviors)
        {
            validationBehavior.Reset();
        }
    }

    public void RenderReport(CustomReportControls controls, bool showFileUpload)
    {
		try
		{
			foreach (var section in controls.Sections)
			{
				var sectionView = new CardView
				{
					Style = App.GetResource("CardViewSpacingStyle", App.ResourceFile.AppStyles) as Style
				};
				var sectionLayout = new StackLayout
				{
					Spacing = 20
				};
				var sectionTitle = new Label
				{
					Text = section.Title,
					@class = new List<string> { "LatoBold_18", "Accent" }
				};
				sectionLayout.Add(sectionTitle);
				sectionView.Content = sectionLayout;
				ContainerLayout.Add(sectionView);

				foreach (var field in section.Fields)
				{
                    View entry = null;
                    switch (field.FieldType)
                    {
                        case AppConstants.CustomReportText:
                            entry = CreateTextEntry(field, section.Title);
                            break;
                        case AppConstants.CustomReportDateTime:
                            entry = CreateDateTimeEntry(field, section.Title);
                            break;
                        case AppConstants.CustomReportDropdown:
                            entry = CreatePickerEntry(field, section.Title);
                            break;
                        case AppConstants.CustomReportPassword:
                            entry = CreateTextEntry(field, section.Title);
                            break;
                        case AppConstants.CustomReportTextarea:
                            entry = CreateEditorEntry(field, section.Title);
                            break;
                        case AppConstants.CustomReportCheckbox:
                            entry = CreateCheckboxEntry(field, section.Title);
                            break;
                        default:
                            break;
                    }

                    if(entry != null)
                        sectionLayout.Add(entry);
                }
			}

            if (showFileUpload)
                AddFileUploadEntry();
        }
		catch (Exception)
		{
		}
    }

    private Entry CreateTextEntry(Field field, string sectionTitle)
    {
        var entry = new Entry
        {
			EntryType = Entry.EntryTypeOptions.TextEntry,
			Title = field.DisplayName,
			IsMandatory = field.IsMandatory
        };
        entry.SetBinding(Entry.TextProperty, $"CustomReportFields[{sectionTitle}{field.DisplayName}]");

        if (field.FieldType.Equals(AppConstants.CustomReportPassword))
            entry.IsPassword = true;

        if (field.IsMandatory)
        {
            AddRequiredValidationBehavior(sectionTitle, field.DisplayName, entry);
        }

		return entry;
    }

    private Entry CreateEditorEntry(Field field, string sectionTitle)
    {
        var entry = new Entry
        {
            EntryType = Entry.EntryTypeOptions.TextEditor,
            Title = field.DisplayName,
            IsMandatory = field.IsMandatory
        };
        entry.SetBinding(Entry.TextProperty, $"CustomReportFields[{sectionTitle}{field.DisplayName}]");

        if (field.IsMandatory)
        {
            AddRequiredValidationBehavior(sectionTitle, field.DisplayName, entry);
        }

        return entry;
    }

    private Entry CreateDateTimeEntry(Field field, string sectionTitle)
    {
        var entry = new Entry
        {
            EntryType = Entry.EntryTypeOptions.DateTimePicker,
            Title = field.DisplayName,
            IsMandatory = field.IsMandatory,
            RightIcon = "calendar"
        };
        entry.SetBinding(Entry.TextProperty, $"CustomReportFields[{sectionTitle}{field.DisplayName}]");

        if (field.IsMandatory)
        {
            AddRequiredValidationBehavior(sectionTitle, field.DisplayName, entry);
        }

        return entry;
    }

    private Entry CreateDateEntry(Field field, string sectionTitle)
    {
        var entry = new Entry
        {
            EntryType = Entry.EntryTypeOptions.DatePicker,
            Title = field.DisplayName,
            IsMandatory = field.IsMandatory,
            RightIcon = "calendar"
        };
        entry.SetBinding(Entry.TextProperty, $"CustomReportFields[{sectionTitle}{field.DisplayName}]");

        if (field.IsMandatory)
        {
            AddRequiredValidationBehavior(sectionTitle, field.DisplayName, entry);
        }

        return entry;
    }

    private Entry CreateTimeEntry(Field field, string sectionTitle)
    {
        var entry = new Entry
        {
            EntryType = Entry.EntryTypeOptions.TimePicker,
            Title = field.DisplayName,
            IsMandatory = field.IsMandatory,
            RightIcon = "calendar"
        };
        entry.SetBinding(Entry.TextProperty, $"CustomReportFields[{sectionTitle}{field.DisplayName}]");

        if (field.IsMandatory)
        {
            AddRequiredValidationBehavior(sectionTitle, field.DisplayName, entry);
        }

        return entry;
    }

    private Entry CreatePickerEntry(Field field, string sectionTitle)
    {
        var options = field.DefaultValue?.ToString().Split(",").ToList();
        var entry = new Entry
        {
            EntryType = Entry.EntryTypeOptions.ListPicker,
            Title = field.DisplayName,
            IsMandatory = field.IsMandatory,
            ItemsSource = options
        };
        entry.SetBinding(Entry.SelectedItemProperty, $"CustomReportFields[{sectionTitle}{field.DisplayName}]");

        if (field.IsMandatory)
        {
            AddRequiredValidationBehavior(sectionTitle, field.DisplayName, entry);
        }

        return entry;
    }

    private CheckboxView CreateCheckboxEntry(Field field, string sectionTitle)
    {
        var checkboxView = new CheckboxView
        {
            Title = field.DisplayName,
            IsMandatory = field.IsMandatory
        };
        checkboxView.CheckedChanged += (s, e) =>
        {
            ((CustomReportViewModel)BindingContext).CustomReportFields["proxy"] = "Setting this to force property changed event to be fired";
        };
        checkboxView.SetBinding(CheckboxView.CheckboxesProperty, new Binding($"CustomReportFields[{sectionTitle}{field.DisplayName}]", source: BindingContext));

        return checkboxView;
    }

    private void AddFileUploadEntry()
    {
        var sectionView = new CardView
        {
            Style = App.GetResource("CardViewSpacingStyle", App.ResourceFile.AppStyles) as Style
        };
        var sectionLayout = new StackLayout
        {
            Spacing = 20
        };
        var sectionTitle = new Label
        {
            Text = AppResource.Photos_Videos_Audio,
            @class = new List<string> { "LatoBold_18", "Accent" }
        };
        sectionLayout.Add(sectionTitle);
        sectionView.Content = sectionLayout;
        ContainerLayout.Add(sectionView);

        var fileUpload = new FileUpload();
        fileUpload.SetBinding(FileUpload.FilesProperty, "Files");
        sectionLayout.Add(fileUpload);
    }

    private void AddRequiredValidationBehavior(string sectionTitle, string displayName, Entry entry)
    {
        var requiredValidationBehavior = new RequiredValidationBehavior();
        requiredValidationBehavior.ValidationMessage = AppResource.Required_Validation;
        requiredValidationBehavior.SetBinding(RequiredValidationBehavior.IsValidProperty, new Binding($"IsValid[{sectionTitle}{displayName}]", source: BindingContext));
        entry.Behaviors.Add(requiredValidationBehavior);

        _validationBehaviors.Add(requiredValidationBehavior);
    }
}