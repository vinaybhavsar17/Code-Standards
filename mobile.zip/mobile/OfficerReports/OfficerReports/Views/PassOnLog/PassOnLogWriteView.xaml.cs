using OfficerReports.Views.Base;

namespace OfficerReports.Views.PassOnLog;

public partial class PassOnLogWriteView : FormPageBase
{
    public PassOnLogWriteView()
    {
        InitializeComponent();
    }

    public override void Validate()
    {
        base.Validate();

        postShiftRequiredValidator.ForceValidate();
        noteRequiredValidator.ForceValidate();
     }

    public override void ResetValidation()
    {
        base.ResetValidation();

        postShiftRequiredValidator.Reset();
        noteRequiredValidator.Reset();
    }

    }
