using OfficerReports.Views.Base;

namespace OfficerReports.Views.PassOnLog;

public partial class PassOnLogReadView : ContentPageBase
{
	public PassOnLogReadView()
	{
		InitializeComponent();
	}
}