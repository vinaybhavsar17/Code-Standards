using OfficerReports.Models.PassOnLog;
using OfficerReports.ViewModels.PassOnLog;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.PassOnLog;

public partial class PassOnLogDetailView : ContentPageBase
{
	public PassOnLogDetailView(PassOnLogRecord passOnLog)
	{
		InitializeComponent();
		(BindingContext as PassOnLogDetailViewModel).PassOnLog = passOnLog;

	}
}