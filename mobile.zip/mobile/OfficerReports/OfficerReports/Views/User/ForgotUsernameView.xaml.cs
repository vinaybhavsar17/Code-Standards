using OfficerReports.Views.Base;
namespace OfficerReports.Views.User;


public partial class ForgotUsernameView : ContentPageBase
{
	public ForgotUsernameView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();

        emailRequiredValidator.ForceValidate();

    }

    public override void ResetValidation()
    {
        base.ResetValidation();

        emailRequiredValidator.Reset();
    }
}