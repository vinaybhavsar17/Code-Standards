﻿using OfficerReports.Views.Base;

namespace OfficerReports.Views.User;

public partial class ResetPasswordView : ContentPageBase
{
	public ResetPasswordView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();

        usernameRequiredValidator.ForceValidate();
        oldPasswordRequiredValidator.ForceValidate();

        var isPasswordEntered = newPasswordRequiredValidator.ForceValidate();
        if (isPasswordEntered)
            passwordFormatValidator.ForceValidate();

        var isConfirmPasswordEntered = confirmPasswordRequiredValidator.ForceValidate();
        if (isConfirmPasswordEntered)
            confirmPasswordCompareValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();

        usernameRequiredValidator.Reset();
        oldPasswordRequiredValidator.Reset();
        newPasswordRequiredValidator.Reset();
        passwordFormatValidator.Reset();
        confirmPasswordRequiredValidator.Reset();
    }
}
