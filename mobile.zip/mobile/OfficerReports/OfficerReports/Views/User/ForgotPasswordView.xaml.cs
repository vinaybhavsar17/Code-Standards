using OfficerReports.Views.Base;
namespace OfficerReports.Views.User;

public partial class ForgotPasswordView : ContentPageBase
{
	public ForgotPasswordView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();

        emailRequiredValidator.ForceValidate();
        
    }

    public override void ResetValidation()
    {
        base.ResetValidation();

        emailRequiredValidator.Reset();
    }
}