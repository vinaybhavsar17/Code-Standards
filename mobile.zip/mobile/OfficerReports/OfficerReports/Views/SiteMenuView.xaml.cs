using OfficerReports.Models.Site;
using OfficerReports.ViewModels;
using OfficerReports.Views.Base;

namespace OfficerReports.Views;

public partial class SiteMenuView : ContentPageBase
{
  
    public SiteMenuView(ClientSite site)
    {
        InitializeComponent();
        (BindingContext as SiteMenuViewModel).SetSite(site);
    }

   
}