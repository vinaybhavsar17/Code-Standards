using OfficerReports.Views.Base;

namespace OfficerReports.Views.PolicyManual;

public partial class PolicyManualView : ContentPageBase
{
	public PolicyManualView()
	{
		InitializeComponent();
	}
}