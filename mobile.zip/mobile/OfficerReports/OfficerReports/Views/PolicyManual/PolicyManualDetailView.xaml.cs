using OfficerReports.ViewModels.PolicyManual;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.PolicyManual;

public partial class PolicyManualDetailView : ContentPageBase
{
	public PolicyManualDetailView(Models.PolicyManual.PolicyManual policyManual)
	{
		InitializeComponent();

		(BindingContext as PolicyManualDetailViewModel).PolicyManual = policyManual;
	}
}