using OfficerReports.Services.Navigation;

namespace OfficerReports.Views;

public partial class ImageViewerView : ContentPage
{
	private ImageSource _imageSource;

    public ImageViewerView(ImageSource imageSource)
	{
		InitializeComponent();

		_imageSource = imageSource;

    }

	protected override void OnAppearing()
	{
		base.OnAppearing();

		imageView.Source = _imageSource;

    }

	private void CloseButton_Clicked(object sender, EventArgs e)
	{
		var navigationService = App.ServiceProvider.GetRequiredService<INavigationService>();
		navigationService.PopModalAsync();
    }
}