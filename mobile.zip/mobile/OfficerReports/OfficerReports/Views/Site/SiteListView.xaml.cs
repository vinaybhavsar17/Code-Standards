using OfficerReports.ViewModels.Site;
using OfficerReports.Views.Base;


namespace OfficerReports.Views.Site;

public partial class SiteListView : ContentPageBase
{
	public SiteListView()
	{
		InitializeComponent();
	}



}