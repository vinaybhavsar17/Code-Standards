using OfficerReports.ViewModels.DailyActivityReport;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.DailyActivityReport;

public partial class DailyActivityReportView : ContentPageBase
{
	
	public DailyActivityReportView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();
       
        postShiftRequiredValidator.ForceValidate();
        postItemReceivedRequiredValidator.ForceValidate();
        relievingOfficerFirstNameRequiredValidator.ForceValidate();
        relievingOfficerLastNameRequiredValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();
     
        postShiftRequiredValidator.Reset();
        postItemReceivedRequiredValidator.Reset();
        relievingOfficerFirstNameRequiredValidator.Reset();
        relievingOfficerLastNameRequiredValidator.Reset();
    }
}