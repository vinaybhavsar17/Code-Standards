using OfficerReports.Models.DailyActivityReport;
using OfficerReports.Views.Base;
using System.Collections.ObjectModel;

namespace OfficerReports.Views.DailyActivityReport;

public partial class AddObservationPopup : PopupPageBase
{

    private ObservableCollection<ObservationTypeItem> _observationTypes;
    public ObservableCollection<ObservationTypeItem> ObservationTypes
    {
        get { return _observationTypes; }
        set
        {
            _observationTypes = value;
            OnPropertyChanged(nameof(ObservationTypes));
        }
    }

    private int _selectedItemIndex;
    public int SelectedItemIndex
    {
        get { return _selectedItemIndex; }
        set
        {
            _selectedItemIndex = value;
            OnPropertyChanged(nameof(SelectedItemIndex));
        }
    }

    private ObservationTypeItem _selectedObservationType;
    public ObservationTypeItem SelectedObservationType
    {
        get { return _selectedObservationType; }
        set
        {
            _selectedObservationType = value;
            OnPropertyChanged(nameof(SelectedObservationType));
        }
    }

    private string _comments;
    public string Comments
    {
        get { return _comments; }
        set
        {
            _comments = value;
            OnPropertyChanged(nameof(Comments));
        }
    }

    public AddObservationPopup(List<ObservationTypeItem> observationTypes)
	{
        Init(observationTypes);
    }

    public AddObservationPopup(List<ObservationTypeItem> observationTypes, Observation observation)
    {
        Init(observationTypes);

        SelectedObservationType = observation.ObservationType;
        Comments = observation.Comments;
    }

    private void Init(List<ObservationTypeItem> observationTypes)
    {
        InitializeComponent();

        BindingContext = this;

        ObservationTypes = new ObservableCollection<ObservationTypeItem>(observationTypes);
    }

    private void SaveObservationClicked(object sender, EventArgs e)
    {
        observationTypeRequiredValidator.ForceValidate();
        commentsRequiredValidator.ForceValidate();

        if(observationTypeRequiredValidator.IsValid && commentsRequiredValidator.IsValid)
        {
            var observation = new Observation
            {
                ObservationTypeId = SelectedObservationType.TypeDataId,
                Comments = Comments,
                CreatedDate = DateTime.UtcNow,
                ObservationType = SelectedObservationType
            };
            Close(observation);
        }
    }
}