using ZXing.Net.Maui;

namespace OfficerReports.Views.BarcodeScanner;

public partial class BarcodeScannerView : ContentPage
{
    public event EventHandler<BarcodeScannedEventArgs> OnBarcodeScanned;
    private bool _scanned;

	public BarcodeScannerView()
	{
		InitializeComponent();

        barcodeView.Options = new BarcodeReaderOptions
        {
            Formats = BarcodeFormats.TwoDimensional,
            AutoRotate = true,
            Multiple = false,
        };
        barcodeView.IsTorchOn = false;
    }

    private void BarcodesDetected(object sender, BarcodeDetectionEventArgs e)
    {
        if (_scanned)
            return;

        _scanned = true;

        Device.InvokeOnMainThreadAsync(() =>
        {
            var scannedData = e.Results.FirstOrDefault()?.Value;
            barcodeView.IsTorchOn = false;
            OnBarcodeScanned?.Invoke(this, new BarcodeScannedEventArgs(scannedData));
        });
    }

    void SwitchCameraButton_Clicked(object sender, EventArgs e)
    {
        barcodeView.CameraLocation = barcodeView.CameraLocation == CameraLocation.Rear ? CameraLocation.Front : CameraLocation.Rear;

        barcodeView.IsTorchOn = false;
        flashBtn.Source = ImageSource.FromFile("flash_on");
    }

    void TorchButton_Clicked(object sender, EventArgs e)
    {
        barcodeView.IsTorchOn = !barcodeView.IsTorchOn;
        flashBtn.Source = barcodeView.IsTorchOn ? ImageSource.FromFile("flash_off") : ImageSource.FromFile("flash_on");
    }
}

public class BarcodeScannedEventArgs : EventArgs
{
    public string Value { get; set; }

    public BarcodeScannedEventArgs(string value)
    {
        Value = value;
    }
}