using OfficerReports.Views.Base;

namespace OfficerReports.Views.TruckCheckInOut;

public partial class TruckCheckOutView : ContentPageBase
{
	public TruckCheckOutView()
	{
		InitializeComponent();
	}
}