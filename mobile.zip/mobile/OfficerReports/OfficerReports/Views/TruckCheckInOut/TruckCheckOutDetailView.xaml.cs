using OfficerReports.Models.TruckCheckInOut;
using OfficerReports.ViewModels.TruckCheckInOut;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.TruckCheckInOut;

public partial class TruckCheckOutDetailView : ContentPageBase
{
	public TruckCheckOutDetailView(TruckCheckOutRecord truckCheckOutRecord)
	{
		InitializeComponent();
        (BindingContext as TruckCheckOutDetailViewModel).TruckCheckOutDetail = truckCheckOutRecord;
    }

	public override void OnContentUpdate()
	{
		base.OnContentUpdate();

        AdjustScrollSize();
    }

	public override void Validate()
	{
		base.Validate();
		outboundDriverRequiredValidator.ForceValidate();

        AdjustScrollSize();
    }

	public override void ResetValidation()
	{
		base.ResetValidation();
		outboundDriverRequiredValidator.Reset();

		AdjustScrollSize();

    }

	private void AdjustScrollSize()
    {
        var size = MainScrollView.CrossPlatformMeasure(0, 0);
        MainScrollView.Layout(new Rect(0, 0, size.Width, size.Height));
    }
}