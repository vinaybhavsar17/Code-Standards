using OfficerReports.Views.Base;

namespace OfficerReports.Views.TruckCheckInOut;

public partial class TruckCheckInView : FormPageBase
{
	public TruckCheckInView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();

        companyNameRequiredValidator.ForceValidate();
        driverRequiredValidator.ForceValidate();
        tractorRequiredValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();

        companyNameRequiredValidator.Reset();
        driverRequiredValidator.Reset();
        tractorRequiredValidator.Reset();
    }
}