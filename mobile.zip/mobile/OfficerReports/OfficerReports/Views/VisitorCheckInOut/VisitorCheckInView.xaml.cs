using OfficerReports.Views.Base;

namespace OfficerReports.Views.VisitorCheckInOut;

public partial class VisitorCheckInView : FormPageBase
{
	public VisitorCheckInView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();
        visitorNameRequiredValidator.ForceValidate();
        destinationRequiredValidator.ForceValidate();
        typeOfIdRequiredValidator.ForceValidate();
        entryNotesRequiredValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();
        visitorNameRequiredValidator.Reset();
        destinationRequiredValidator.Reset();
        typeOfIdRequiredValidator.Reset();
        entryNotesRequiredValidator.Reset();
    }
}