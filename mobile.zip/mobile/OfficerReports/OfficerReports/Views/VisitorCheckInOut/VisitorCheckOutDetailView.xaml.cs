using OfficerReports.Models.VisitorCheckInOut;
using OfficerReports.ViewModels.VisitorCheckInOut;
using OfficerReports.Views.Base;
namespace OfficerReports.Views.VisitorCheckInOut;

public partial class VisitorCheckOutDetailView : ContentPageBase
{
	public VisitorCheckOutDetailView(VisitorCheckOutRecord visitorCheckOutRecord)
	{
		InitializeComponent();
        (BindingContext as VisitorCheckOutDetailViewModel).VisitorCheckOutDetail = visitorCheckOutRecord;
    }

}