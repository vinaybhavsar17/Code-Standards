using OfficerReports.Views.Base;

namespace OfficerReports.Views.VisitorCheckInOut;

public partial class VisitorCheckOutView : ContentPageBase
{
	public VisitorCheckOutView()
	{
		InitializeComponent();
	}
}