using Microsoft.Maui.Platform;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.SiteCheckReport;

public partial class SiteCheckReportView : FormPageBase
{
    public SiteCheckReportView()
    {
        InitializeComponent();
    }

    public override void Validate()
    {
        detailsRequiredValidator.ForceValidate();

        base.Validate();
    }

    public override void ResetValidation()
    {
        detailsRequiredValidator.Reset();

        base.ResetValidation();
    }
}