using OfficerReports.ViewModels.Authentication;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.Authentication;

public partial class OtpView : ContentPageBase
{
	public OtpView(Models.Authentication.User user, dynamic adminCredentials)
	{
		InitializeComponent();

        (BindingContext as OtpViewModel).User = user;
        (BindingContext as OtpViewModel).AdminCredentials = adminCredentials;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        otpControl.SetFocus();
    }
}