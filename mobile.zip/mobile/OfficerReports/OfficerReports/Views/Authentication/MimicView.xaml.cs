using OfficerReports.ViewModels.Authentication;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.Authentication;

public partial class MimicView : FormPageBase
{
	public MimicView(dynamic adminCredentials)
	{
		InitializeComponent();

        (BindingContext as MimicViewModel).AdminCredentials = adminCredentials;
    }

    public override void Validate()
    {
        var isUrlEntered = urlRequiredValidator.ForceValidate();

        if (isUrlEntered)
            urlValueValidator.ForceValidate();

        usernameRequiredValidator.ForceValidate();

        base.Validate();
    }

    public override void ResetValidation()
    {
        urlRequiredValidator.Reset();
        usernameRequiredValidator.Reset();

        base.ResetValidation();
    }
}