using OfficerReports.Views.Base;

namespace OfficerReports.Views.Authentication;

public partial class LoginView : ContentPageBase
{
	public LoginView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();

        usernameRequiredValidator.ForceValidate();
        passwordRequiredValidator.ForceValidate();
    }
}