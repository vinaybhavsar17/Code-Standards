using OfficerReports.Views.Base;

namespace OfficerReports.Views.Incident;

public partial class IncidentReportView : ContentPageBase
{
	public IncidentReportView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();
        dateTimeOfIncidentRequiredValidator.ForceValidate();
        incidentTypeRequiredValidator.ForceValidate();
        incidentLocationRequiredValidator.ForceValidate();
        incidentSummaryRequiredValidator.ForceValidate();
        detailsRequiredValidator.ForceValidate();
        whoWhatWhenRequiredValidator.ForceValidate();
        policeCalledRequiredValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();
         dateTimeOfIncidentRequiredValidator.Reset();
         incidentTypeRequiredValidator.Reset();
         incidentLocationRequiredValidator.Reset();
         incidentSummaryRequiredValidator.Reset();
         detailsRequiredValidator.Reset();
         whoWhatWhenRequiredValidator.Reset();
         policeCalledRequiredValidator.Reset();
    }
}