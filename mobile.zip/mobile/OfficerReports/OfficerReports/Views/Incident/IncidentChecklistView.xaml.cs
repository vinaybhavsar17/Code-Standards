using OfficerReports.Views.Base;

namespace OfficerReports.Views.Incident;

public partial class IncidentChecklistView : ContentPageBase
{
	public IncidentChecklistView()
	{
		InitializeComponent();
	}
}