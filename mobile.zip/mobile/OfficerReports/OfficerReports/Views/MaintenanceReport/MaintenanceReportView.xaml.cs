using OfficerReports.Views.Base;

namespace OfficerReports.Views.MaintenanceReport;

public partial class MaintenanceReportView : ContentPageBase
{
	public MaintenanceReportView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();

        maintenanceTypeRequiredValidator.ForceValidate();
        detailsRequiredValidator.ForceValidate();
        emailClientRequiredValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();

        maintenanceTypeRequiredValidator.Reset();
        detailsRequiredValidator.Reset();
        emailClientRequiredValidator.Reset();
    }
}