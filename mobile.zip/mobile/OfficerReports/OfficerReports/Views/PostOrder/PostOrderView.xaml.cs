using OfficerReports.Views.Base;

namespace OfficerReports.Views.PostOrder;

public partial class PostOrderView : ContentPageBase
{
	public PostOrderView()
	{
		InitializeComponent();
		
	}

	public override void OnContentUpdate()
	{
		base.OnContentUpdate();
        var size = MainScrollView.CrossPlatformMeasure(0, 0);
        MainScrollView.Layout(new Rect(0, 0, size.Width, size.Height));
    }

}