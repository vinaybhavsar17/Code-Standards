﻿using OfficerReports.Views.Base;
using OfficerReports.Resources.Strings;
using OfficerReports.Models.Scheduler;
using OfficerReports.ViewModels.Scheduler;

namespace OfficerReports.Views.Scheduler;

public partial class SchedulerView : ContentPageBase
{
	public SchedulerView()
	{
		InitializeComponent();
	}

    void SfScheduler_Tapped(System.Object sender, Syncfusion.Maui.Scheduler.SchedulerTappedEventArgs e)
    {
		var appointment = e.Appointments?.FirstOrDefault();
		if (appointment == null)
			return;

		var scheduleId = (appointment as Schedule).ScheduleId;
		var scheduleViewModel = BindingContext as SchedulerViewModel;
		var schedule = scheduleViewModel.Schedules.Where(s => s.ScheduleId == scheduleId).FirstOrDefault();
        if (schedule == null)
            return;

        var title = schedule.Title;
		var message = $"{AppResource.Site}: {schedule.SiteName}";

		if(schedule.OfficerList != null && schedule.OfficerList.Count > 0)
		{
			message += $"\n\n{AppResource.Officers}:\n";

            foreach (var officer in schedule.OfficerList)
            {
                message += $"{officer.UserName} | ";
            }
            var commaIndex = message.LastIndexOf(" | ");
            if (commaIndex >= 0 && commaIndex == message.Length - 3)
                message = message.Remove(commaIndex);
        }

		if(!string.IsNullOrEmpty(schedule.Description))
			message += $"\n\n{AppResource.Description}:\n{schedule.Description}";

		DisplayAlert(title, message, AppResource.Ok.ToUpper());
    }
}
