using OfficerReports.ViewModels.Base;

namespace OfficerReports.Views.Base;

[ContentProperty("InternalContent")]
public partial class TabPageBase : ContentPage
{
    public static readonly BindableProperty InternalContentProperty = BindableProperty.Create(nameof(InternalContent), typeof(View), typeof(TabPageBase), propertyChanged: InternalContentPropertyChanged);

    protected static void InternalContentPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (((TabPageBase)bindable).PageContentLayout == null || newValue == ((TabPageBase)bindable).PageContentLayout)
            ((TabPageBase)bindable).Content = ((TabPageBase)bindable).InternalContent;
        else
            ((TabPageBase)bindable).InternalContentView.Content = ((TabPageBase)bindable).InternalContent;
    }

    public View InternalContent
    {
        get => (View)GetValue(InternalContentProperty);
        set => SetValue(InternalContentProperty, value);
    }

    protected View PageContent
    {
        get
        {
            return PageContentLayout;
        }
    }

    public TabPageBase()
	{
		InitializeComponent();
	}

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        if (BindingContext is ViewModelBase vmb)
        {
            vmb.OnAppearing();

            if (!vmb.IsInitialized || vmb.MultipleInitialization)
            {
                await vmb.InitializeAsync(null);
            }

            MessagingCenter.Subscribe<App>(this, App.MESSAGE_RESUME, (sender) =>
            {
                vmb.OnResume();
            });
        }
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();

        if (BindingContext is ViewModelBase vmb)
        {
            vmb.OnDisappearing();

            MessagingCenter.Unsubscribe<App>(this, App.MESSAGE_RESUME);
        }
    }
}