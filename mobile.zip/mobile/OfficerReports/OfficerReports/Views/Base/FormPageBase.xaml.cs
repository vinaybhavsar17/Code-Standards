namespace OfficerReports.Views.Base;

[ContentProperty("FormContent")]
public partial class FormPageBase : ContentPageBase
{
    public static readonly BindableProperty FormContentProperty = BindableProperty.Create(nameof(FormContent), typeof(View), typeof(FormPageBase), propertyChanged: FormContentPropertyChanged);

    private static void FormContentPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var formPageBase = (FormPageBase)bindable;

        if (formPageBase.MainScrollView == null || newValue == formPageBase.MainScrollView)
            formPageBase.InternalContent = formPageBase.FormContent;
        else
            formPageBase.FormContentView.Content = formPageBase.FormContent;
    }

    public View FormContent
    {
        get => (View)GetValue(FormContentProperty);
        set => SetValue(FormContentProperty, value);
    }

    private bool _showClientInfo = true;
    public bool ShowClientInfo
    {
        get
        {
            return _showClientInfo;
        }
        set
        {
            _showClientInfo = value;
            OnPropertyChanged(nameof(ShowClientInfo));
        }
    }

    public FormPageBase()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        base.Validate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();
    }
}