

using OfficerReports.Controls;
using OfficerReports.Interfaces;
using OfficerReports.ViewModels.Base;

namespace OfficerReports.Views.Base
{
    [ContentProperty("InternalContent")]
    public partial class ContentPageBase : ContentPage, IUiFieldValidator, IContentUpdater
	{

        public static readonly BindableProperty InternalContentProperty = BindableProperty.Create(nameof(InternalContent), typeof(View), typeof(ContentPageBase), propertyChanged: InternalContentPropertyChanged);

        protected static void InternalContentPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if (((ContentPageBase)bindable).PageContentLayout == null || newValue == ((ContentPageBase)bindable).PageContentLayout)
                ((ContentPageBase)bindable).Content = ((ContentPageBase)bindable).InternalContent;
            else
                ((ContentPageBase)bindable).InternalContentView.Content = ((ContentPageBase)bindable).InternalContent;
        }

        public View InternalContent
        {
            get => (View)GetValue(InternalContentProperty);
            set => SetValue(InternalContentProperty, value);
        }

        protected View PageContent { 
            get 
            {
                return PageContentLayout;
            } 
        }

        public ContentPageBase()
		{
			InitializeComponent();
		}

        private bool _hasNavigationBar = true;
        public bool HasNavigationBar { 
            get 
            {
                return _hasNavigationBar;
            } 
            set 
            {
                _hasNavigationBar = value;
                OnPropertyChanged(nameof(HasNavigationBar));
            } 
        }

        private bool _hasBackButton = true;
        public bool HasBackButton
        {
            get
            {
                return _hasBackButton;
            }
            set
            {
                _hasBackButton = value;
                OnPropertyChanged(nameof(HasBackButton));
            }
        }

        private bool _hasNavigationBarShadow = true;
        public bool HasNavigationBarShadow
        {
            get
            {
                return _hasNavigationBarShadow;
            }
            set
            {
                _hasNavigationBarShadow = value;
                OnPropertyChanged(nameof(HasNavigationBarShadow));
            }
        }

        private bool _showLogoOnHeader;
        public bool ShowLogoOnHeader
        {
            get
            {
                return _showLogoOnHeader;
            }
            set
            {
                _showLogoOnHeader = value;
                OnPropertyChanged(nameof(ShowLogoOnHeader));
            }
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            if (BindingContext is ViewModelBase vmb)
            {
                vmb.Validator.UiFieldValidator = this;
                vmb.ContentUpdater = this;
                vmb.OnAppearing();

                if (!vmb.IsInitialized || vmb.MultipleInitialization)
                {
                    await vmb.InitializeAsync(null);
                }

                MessagingCenter.Subscribe<App>(this, App.MESSAGE_RESUME, (sender) =>
                {
                    vmb.OnResume();
                });
            }
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();

            if (BindingContext is ViewModelBase vmb)
            {
                vmb.OnDisappearing();

                MessagingCenter.Unsubscribe<App>(this, App.MESSAGE_RESUME);
            }
        }

        protected override bool OnBackButtonPressed()
        {
            var r = base.OnBackButtonPressed();

            if (BindingContext is ViewModelBase vmb)
            {
                vmb.OnBackButtonPressed();
            }

            return r;
        }

        public virtual void Validate()
        {
        }

        public virtual void ResetValidation()
        {
        }

        public virtual void OnContentUpdate()
        {
        }
    }
}