using CommunityToolkit.Maui.Views;
using System.Windows.Input;

namespace OfficerReports.Views.Base;

[ContentProperty("InternalContent")]
public partial class PopupPageBase : Popup
{
	public static double PopupWidth = 0.9 * (DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density);

	public static readonly BindableProperty InternalContentProperty = BindableProperty.Create(nameof(InternalContent), typeof(View), typeof(PopupPageBase), propertyChanged: InternalContentPropertyChanged);

	private static void InternalContentPropertyChanged(BindableObject bindable, object oldValue, object newValue)
	{
		if (((PopupPageBase)bindable).PopupContentLayout == null || newValue == ((PopupPageBase)bindable).PopupContentLayout)
			((PopupPageBase)bindable).Content = ((PopupPageBase)bindable).InternalContent;
		else
			((PopupPageBase)bindable).InternalContentView.Content = ((PopupPageBase)bindable).InternalContent;
	}

	public View InternalContent
	{
		get => (View)GetValue(InternalContentProperty);
		set => SetValue(InternalContentProperty, value);
	}

	private string _title;
    public string Title {
		get { return _title; }
		set
		{
			_title = value;
			OnPropertyChanged(nameof(Title));
		}
	}

    private int _height;
    public int Height
    {
        get { return _height; }
        set
        {
            _height = value;
            OnPropertyChanged(nameof(Height));
			Size = new Size
			{
				Width = Size.Width,
				Height = Height
			};
        }
    }

    public enum TitleAlignment
    {
		Left,
		Center
    }

	private TitleAlignment _titleHorizontalAlignment;
	public TitleAlignment TitleHorizontalAlignment
	{
		get { return _titleHorizontalAlignment; }
		set
		{
			_titleHorizontalAlignment = value;
			OnPropertyChanged(nameof(TitleHorizontalAlignment));

            switch (_titleHorizontalAlignment)
            {
                case TitleAlignment.Left:
					TitleLabel.HorizontalOptions = LayoutOptions.StartAndExpand;
					break;
                case TitleAlignment.Center:
					TitleLabel.HorizontalOptions = LayoutOptions.CenterAndExpand;
					break;
                default:
					TitleLabel.HorizontalOptions = LayoutOptions.StartAndExpand;
					break;
            }
        }
	}

	public ICommand CloseCommand => new Command(() => ClosePopup());

	public PopupPageBase()
	{
		InitializeComponent();

		BindingContext = this;

		Size = new Size 
		{ 
			Width = PopupWidth,
			Height = Height
		};
	}

	private void ClosePopup()
    {
		Close();
	}
}