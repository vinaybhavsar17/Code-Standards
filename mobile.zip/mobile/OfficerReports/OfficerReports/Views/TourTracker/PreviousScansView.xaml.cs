using OfficerReports.Models.TourTracker;
using OfficerReports.ViewModels.TourTracker;
using OfficerReports.Views.Base;
using System.Collections.ObjectModel;

namespace OfficerReports.Views.TourTracker;

public partial class PreviousScansView : ContentPageBase
{
	public PreviousScansView(List<PreviousScan> previousScans)
	{
		InitializeComponent();

		if (previousScans == null)
			previousScans = new List<PreviousScan>();

		(BindingContext as PreviousScansViewModel).PreviousScans = new ObservableCollection<PreviousScan>(previousScans);
	}
}