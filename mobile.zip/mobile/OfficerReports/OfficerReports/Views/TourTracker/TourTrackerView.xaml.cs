using OfficerReports.Views.Base;

namespace OfficerReports.Views.TourTracker;

public partial class TourTrackerView : ContentPageBase
{
	public TourTrackerView()
	{
		InitializeComponent();
	}
}