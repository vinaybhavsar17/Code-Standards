using OfficerReports.Views.Base;

namespace OfficerReports.Views.Vacation;

public partial class VacationReviewView : ContentPageBase
{
	public VacationReviewView()
	{
		InitializeComponent();
	}
}