using OfficerReports.Views.Base;

namespace OfficerReports.Views.Vacation;

public partial class VacationRequestView : ContentPageBase
{
	public VacationRequestView()
	{
		InitializeComponent(); 
	}

    public override void Validate()
    {
        base.Validate();

        emailFormatValidator.ForceValidate();
        startDateRequiredValidator.ForceValidate();

        var isEndDateEntered = endDateRequiredValidator.ForceValidate();
        if(isEndDateEntered)
            startEndDateCompareValidator.ForceValidate();

        reasonRequiredValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();

        emailFormatValidator.Reset();
        startDateRequiredValidator.Reset();
        endDateRequiredValidator.Reset();
        reasonRequiredValidator.Reset();
    }
}