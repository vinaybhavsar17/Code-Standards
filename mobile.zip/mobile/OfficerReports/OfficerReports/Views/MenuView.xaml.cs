using OfficerReports.ViewModels;
using OfficerReports.Views.Base;

namespace OfficerReports.Views;

public partial class MenuView : ContentPageBase
{
	public MenuView(Models.Authentication.User user)
	{
		InitializeComponent();

		(BindingContext as MenuViewModel).SetLoggedInUser(user);
    }
}