using OfficerReports.Services.FieldInspection;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.Storage;
using OfficerReports.Services.User;
using OfficerReports.ViewModels.FieldInspection;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.FieldInspection;

public partial class FieldInspectionView : ContentPageBase
{
    public FieldInspectionView(Location location)
	{
		InitializeComponent();
        (BindingContext as FieldInspectionViewModel).SetFieldInspectionOpenLocation(location);
    }


    public override void Validate()
    {
        base.Validate();
        incidentTypeRequiredValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();
        incidentTypeRequiredValidator.Reset();
    }
}