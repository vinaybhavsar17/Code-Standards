using OfficerReports.Views.Base;

namespace OfficerReports.Views.ClockInOut;

public partial class ClockInOutView : ContentPageBase
{
	public ClockInOutView()
	{
		InitializeComponent();
	}
}