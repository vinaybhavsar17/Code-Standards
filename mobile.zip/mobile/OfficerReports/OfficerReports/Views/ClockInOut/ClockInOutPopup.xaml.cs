
using OfficerReports.Views.Base;

namespace OfficerReports.Views.ClockInOut;

public partial class ClockInOutPopup : PopupPageBase
{
	private string _inComment;
	public string InComment
	{
		get { return _inComment; }
		set
		{
			_inComment = value;
			OnPropertyChanged(nameof(InComment));
		}
	}

	private string _outComment;
	public string OutComment
	{
		get { return _outComment; }
		set
		{
			_outComment = value;
			OnPropertyChanged(nameof(OutComment));
		}
	}

	public ClockInOutPopup(string inComment, string outComment)
	{
		InitializeComponent();

		InComment = inComment;
		OutComment = outComment;
	}
}