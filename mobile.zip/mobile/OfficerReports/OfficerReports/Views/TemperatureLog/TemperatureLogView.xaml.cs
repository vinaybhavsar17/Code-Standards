using OfficerReports.ViewModels.TemperatureLog;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.TemperatureLog;

public partial class TemperatureLogView : FormPageBase
{
	public TemperatureLogView()
	{
		InitializeComponent();
	}

    public override void Validate()
    {
        equipmentTypeRequiredValidator.ForceValidate();
        equipmentIdRequiredValidator.ForceValidate();

        var isTempEntered = temperatureRequiredValidator.ForceValidate();
        if(isTempEntered)
            temperatureValueValidator.ForceValidate();

        humidityValueValidator.ForceValidate();

        base.Validate();
    }

    public override void ResetValidation()
    {
        equipmentTypeRequiredValidator.Reset();
        equipmentIdRequiredValidator.Reset();
        temperatureRequiredValidator.Reset();
        temperatureValueValidator.Reset();
        humidityValueValidator.Reset();

        base.ResetValidation();
    }
}