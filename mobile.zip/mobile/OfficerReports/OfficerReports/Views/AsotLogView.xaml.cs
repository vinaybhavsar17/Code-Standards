using OfficerReports.Views.Base;

namespace OfficerReports.Views;

public partial class AsotLogView : ContentPageBase
{
	public AsotLogView()
	{
		InitializeComponent();
	}
}