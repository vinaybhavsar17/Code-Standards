using OfficerReports.ApiClient;
using OfficerReports.Resources.Strings;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.Base;
using System.Net;

namespace OfficerReports.Views;

public partial class PdfViewerView : ContentPageBase
{
    private string _url;

	public PdfViewerView(string url)
	{
		InitializeComponent();

        _url = url;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        LoadPdf(_url);
    }

    private async void LoadPdf(string url)
    {
        var filePath = await GetPdfFilePath(url);
        if (filePath != null)
        {
            pdfViewer.Url = filePath;
        }
    }

    private async Task<string> GetPdfFilePath(string url)
    {
        string downloadedFilePath = null;

        var uri = new Uri(url);

        var fileExtension = Path.GetExtension(uri.LocalPath);

        if (fileExtension != null && fileExtension.ToLower().Contains("pdf"))
        {
            var fileName = Path.GetFileName(uri.LocalPath);
            var systemFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            var filePath = Path.Combine(systemFolderPath, fileName);

            if (!File.Exists(filePath))
            {
                var isSuccess = await DownloadPdf(url, filePath);

                if (isSuccess)
                    downloadedFilePath = filePath;
                else
                    (BindingContext as ViewModelBase).DialogService.ShowMessage(AppResource.Error, AppResource.Pdf_Download_Failed);
            }
            else
            {
                downloadedFilePath = filePath;
            }
        }
        else
        {
            (BindingContext as ViewModelBase).DialogService.ShowMessage(AppResource.Error, AppResource.Pdf_Invalid);
        }

        return downloadedFilePath;
    }

    private async Task<bool> DownloadPdf(string url, string pathToSave)
    {
        var isFileDownloaded = false;

        var httpClient = App.ServiceProvider.GetRequiredService<IRestApiClient>();

        var data = await httpClient.DownloadData(url);

        if(data != null)
        {
            try
            {
                await File.WriteAllBytesAsync(pathToSave, data);
                isFileDownloaded = true;
            }
            catch (Exception ex)
            {

            }
        }

        return isFileDownloaded;
    }
}