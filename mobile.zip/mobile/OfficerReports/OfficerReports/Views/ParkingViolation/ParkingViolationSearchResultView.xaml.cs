using OfficerReports.Models.ParkingViolation;
using OfficerReports.ViewModels.ParkingViolation;
using OfficerReports.Views.Base;
using System.Collections.ObjectModel;

namespace OfficerReports.Views.ParkingViolation;

public partial class ParkingViolationSearchResultView : ContentPageBase
{
	public ParkingViolationSearchResultView(ParkingViolationSearchRequest searchRequest, ParkingViolationSearchResult searchResponse)
	{
		InitializeComponent();

		(BindingContext as ParkingViolationSearchResultViewModel).SearchRequest = searchRequest;
        (BindingContext as ParkingViolationSearchResultViewModel).SearchResponse = searchResponse;
    }
}