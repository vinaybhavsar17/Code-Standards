using OfficerReports.Views.Base;


namespace OfficerReports.Views.ParkingViolation;

public partial class ParkingViolationReportView : ContentPageBase
{
	public ParkingViolationReportView()
	{
		InitializeComponent();
    }


    public override void Validate()
    {
        base.Validate();

        violationTypeRequiredValidator.ForceValidate();
        vehiclemodelRequiredValidator.ForceValidate();
        vehicleMakeRequiredValidator.ForceValidate();
        licensePlateNoRequiredValidator.ForceValidate();
        violationTypeRequiredValidator.ForceValidate();
        locationRequiredValidator.ForceValidate();
        wasVehicleTowedRequiredValidator.ForceValidate();
    }

    public override void ResetValidation()
    {
        base.ResetValidation();

        violationTypeRequiredValidator.Reset();
        vehiclemodelRequiredValidator.Reset();
        licensePlateNoRequiredValidator.Reset();
        violationTypeRequiredValidator.Reset();
        locationRequiredValidator.Reset();
        wasVehicleTowedRequiredValidator.Reset();
    }
}