using OfficerReports.Models.ParkingViolation;
using OfficerReports.ViewModels.ParkingViolation;
using OfficerReports.Views.Base;

namespace OfficerReports.Views.ParkingViolation;

public partial class ParkingViolationDetailsView : ContentPageBase
{
	public ParkingViolationDetailsView(ParkingViolationRecord parkingViolationRecord)
	{
		InitializeComponent();

		(BindingContext as ParkingViolationDetailsViewModel).ParkingViolationRecord = parkingViolationRecord;
	}
}