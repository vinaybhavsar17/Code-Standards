using OfficerReports.Views.Base;

namespace OfficerReports.Views.ParkingViolation;

public partial class ParkingViolationSearchView : FormPageBase
{
	public ParkingViolationSearchView()
	{
		InitializeComponent();
	}
}