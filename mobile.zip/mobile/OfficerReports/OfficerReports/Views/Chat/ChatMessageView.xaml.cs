using OfficerReports.Models.Chat;
using OfficerReports.ViewModels.Base;
using OfficerReports.ViewModels.Chat;
using OfficerReports.Views.Base;
using System.Collections.ObjectModel;
using OfficerReports.Resources.Strings;

namespace OfficerReports.Views.Chat;

public partial class ChatMessageView : ContentPageBase
{
    public ChatMessageView(ChatGroup chatGroup)
	{
		InitializeComponent();
        (BindingContext as ChatMessageViewModel).SelectedChatGroup = chatGroup;
    }

    private void MessagesView_Scrolled(object sender, ItemsViewScrolledEventArgs e)
    {
        //Write logic to find out message object displaying on top of screen.
        //Then display the date of that message on date header label. It's UI part is written in xaml but commented.
        //The idea here is to implement the same functionality as in Whatsapp, where a date header sticks to the top of screen.
        //And it changes as user scrolls, to represent the date of messages displaying below.
    }

    void ErrorIconClicked(System.Object sender, System.EventArgs e)
    {
        Interfaces.PlatformServices.ShowToast(AppResource.Offline_Chat_Message);
    }
}