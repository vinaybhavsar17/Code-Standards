using OfficerReports.Models.Chat;
using OfficerReports.ViewModels.Base;
using OfficerReports.ViewModels.Chat;
using OfficerReports.Views.Base;
using static OfficerReports.Controls.TabView;

namespace OfficerReports.Views.Chat;

public partial class ChatGroupsView : ContentPageBase
{
	public ChatGroupsView(UnreadMessageCount unreadMessageCount)
	{
		InitializeComponent();

		((ChatGroupsViewModel)BindingContext).UnreadMessageCount = unreadMessageCount;
	}

	private void TabView_TabChanged(object sender, TabChangeEventArgs e)
	{
		((ChatGroupsViewModel)BindingContext).ChatGroupSwitched(e.NewTabIndex);
    }
}