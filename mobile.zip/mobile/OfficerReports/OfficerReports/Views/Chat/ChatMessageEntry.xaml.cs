using AndroidX.ExifInterface.Media;
using ExifLib;
using Microsoft.Maui.Graphics;
using Microsoft.Maui.Graphics.Platform;
using OfficerReports.Interfaces;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Dialog;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace OfficerReports.Views.Chat;

public partial class ChatMessageEntry : ContentView
{
    private IDialogService _dialogService;
    private FilePickerFileType _supportedFileTypes = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
    {
        { DevicePlatform.Android, new[]{ "image/*" } }
    });

    public static readonly BindableProperty MessageTextProperty = BindableProperty.Create(nameof(MessageText), typeof(string), typeof(ChatMessageEntry), defaultBindingMode: BindingMode.TwoWay);
    public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(ICommand), typeof(ChatMessageEntry));
    public static readonly BindableProperty CommandParameterProperty = BindableProperty.Create(nameof(CommandParameter), typeof(object), typeof(ChatMessageEntry));
    public static readonly BindableProperty SendFileCommandProperty = BindableProperty.Create(nameof(SendFileCommand), typeof(ICommand), typeof(ChatMessageEntry));

    public static readonly BindableProperty FilesProperty = BindableProperty.Create(nameof(Files), typeof(ObservableCollection<Models.FileInfo>), typeof(ChatMessageEntry), defaultBindingMode: BindingMode.TwoWay);

    public ObservableCollection<Models.FileInfo> Files
    {
        get => (ObservableCollection<Models.FileInfo>)GetValue(FilesProperty);
        set => SetValue(FilesProperty, value);
    }

    private int _maxFileCount;
    public int MaxFileCount
    {
        get { return _maxFileCount; }
        set
        {
            _maxFileCount = value;
            OnPropertyChanged(nameof(MaxFileCount));
        }
    }

    public string MessageText
    {
        get => (string)GetValue(MessageTextProperty);
        set => SetValue(MessageTextProperty, value);
    }

    public ICommand Command
    {
        get => (ICommand)GetValue(CommandProperty);
        set => SetValue(CommandProperty, value);
    }

    public object CommandParameter
    {
        get => (object)GetValue(CommandParameterProperty);
        set => SetValue(CommandParameterProperty, value);
    }

    public ICommand SendFileCommand
    {
        get => (ICommand)GetValue(SendFileCommandProperty);
        set => SetValue(SendFileCommandProperty, value);
    }

    public ChatMessageEntry()
	{
		InitializeComponent();

        _dialogService = App.ServiceProvider.GetRequiredService<IDialogService>();

    }

    private void SendButton_Clicked(object sender, EventArgs e)
	{
        if (Command != null && Command.CanExecute(CommandParameter))
            Command.Execute(CommandParameter);
    }

    private void AttachButton_Tapped(object sender, EventArgs e)
    {
        PickFile();
    }

    private async void PickFile()
    {
        if (MediaPicker.Default.IsCaptureSupported)
        {
            var buttons = new List<string>();
            buttons.Add(AppResource.Take_Photo);
            buttons.Add(AppResource.Gallery);

            var selectionOption = await _dialogService.ShowOptions(AppResource.Select_Option, AppResource.Cancel, null, buttons.ToArray());

            if (selectionOption == AppResource.Gallery)
                PickFileFromGallery();
            else if (selectionOption == AppResource.Take_Photo)
                PickPhotoFromCamera();
        }
        else
        {
            PickFileFromGallery();
        }
    }

    private async void PickFileFromGallery()
    {
        var result = await FilePicker.PickMultipleAsync(new PickOptions
        {
            FileTypes = _supportedFileTypes,
            PickerTitle = "Select a file",
        });

        ProcessFileResult(result);
    }

    private async void PickPhotoFromCamera()
    {
        if (MediaPicker.Default.IsCaptureSupported)
        {
            FileResult photo = await MediaPicker.Default.CapturePhotoAsync();

            await ProcessFileResult(photo);
        }
    }

    private async void ProcessFileResult(IEnumerable<FileResult> results)
    {
        foreach (var result in results)
        {
            await ProcessFileResult(result, false);
        }

        if (SendFileCommand != null && SendFileCommand.CanExecute(null))
            SendFileCommand.Execute(null);
    }

    private async Task ProcessFileResult(FileResult result, bool raiseEvent = true)
    {
        if (result == null) return;

        if (Files == null)
            Files = new ObservableCollection<Models.FileInfo>();

        var compressedImage = await PlatformServices.ResizeCompressImage(result.FullPath, result.FileName, 512);
        compressedImage.Image = ImageSource.FromFile(compressedImage.CompressedImagePath);
        compressedImage.IsImage = true;
        compressedImage.ContentType = result.ContentType;
        compressedImage.FileName = result.FileName;
        compressedImage.FullPath = result.FullPath;

        Files.Add(compressedImage);

        if (raiseEvent && SendFileCommand != null && SendFileCommand.CanExecute(null))
            SendFileCommand.Execute(null);
    }

    private void BoldClicked(object sender, EventArgs e)
    {
        if (MessageText != null && messageEditor.SelectionLength > 0)
        {
            MessageText = MessageText.Insert(messageEditor.CursorPosition, "*")
                                 .Insert(messageEditor.CursorPosition + messageEditor.SelectionLength + 1, "*");
        }
    }

    private void ItalicClicked(object sender, EventArgs e)
    {
        if (MessageText != null && messageEditor.SelectionLength > 0)
        {
            MessageText = MessageText.Insert(messageEditor.CursorPosition, "/")
                                 .Insert(messageEditor.CursorPosition + messageEditor.SelectionLength + 1, "/");
        }
    }

    private void UnderlineClicked(object sender, EventArgs e)
    {
        if (MessageText != null && messageEditor.SelectionLength > 0)
        {
            MessageText = MessageText.Insert(messageEditor.CursorPosition, "_")
                                 .Insert(messageEditor.CursorPosition + messageEditor.SelectionLength + 1, "_");
        }
    }

    private void CloseFormatMenu(object sender, EventArgs e)
    {
        formatMenu.IsVisible = false;
    }

    private void ToggleFormatMenu(object sender, EventArgs e)
    {
        formatMenu.IsVisible = !formatMenu.IsVisible;
    }
}