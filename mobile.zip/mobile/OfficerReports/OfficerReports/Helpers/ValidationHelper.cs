﻿using OfficerReports.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    public class ValidationHelper
    {
        private ObservableDictionary<string, bool> _isValid;
        
        public IUiFieldValidator UiFieldValidator { private get; set; }

        public ValidationHelper(ObservableDictionary<string, bool> isValid)
        {
            _isValid = isValid;
        }

        public void AddField(string fieldName)
        {
            _isValid[fieldName] = false;
        }

        public void AddField(string fieldName, bool isValid)
        {
            _isValid[fieldName] = isValid;
        }

        public bool Validate()
        {
            UiFieldValidator?.Validate();

            var result = true;

            foreach (var item in _isValid)
            {
                result = result && item.Value;
            }

            return result;
        }

        public void Reset()
        {
            UiFieldValidator?.ResetValidation();
        }
    }

}
