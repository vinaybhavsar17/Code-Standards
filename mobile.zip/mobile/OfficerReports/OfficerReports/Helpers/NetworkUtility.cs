﻿using OfficerReports.Resources.Strings;
using OfficerReports.Services.Dialog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    public partial class NetworkUtility
    {
        public static bool IsInternetConnected { 
            get 
            {
                var current = Connectivity.NetworkAccess;

                return current == NetworkAccess.Internet;
            } 
        }

        public async static Task<string> GetConnectionType()
        {
            var current = Connectivity.NetworkAccess;

            if (current != NetworkAccess.Internet)
                return AppResource.No_Internet;

            var profiles = Connectivity.ConnectionProfiles;
            if (profiles.Contains(ConnectionProfile.WiFi))
                return AppResource.Wifi;
            else if (profiles.Contains(ConnectionProfile.Cellular))
            {
                var status = await GetPhonePermission();
                if (status == PermissionStatus.Granted)
                    return GetNetworkType();
                else
                    return AppResource.Mobile_Internet;
            }
            else
                return AppResource.No_Internet;
        }

        private async static Task<PermissionStatus> GetPhonePermission()
        {
            var status = await Permissions.CheckStatusAsync<Permissions.Phone>();
            if (status == PermissionStatus.Granted)
                return status;

            status = await Permissions.RequestAsync<Permissions.Phone>();

            return status;
        }

        private static partial string GetNetworkType();
    }
}
