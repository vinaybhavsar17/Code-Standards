﻿using OfficerReports.Models.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    public class MimicDataManager
    {
        private static MimicData _mimicData;
        public static MimicData MimicData
        {
            get
            {
                return _mimicData;
            }
            set
            {
                _mimicData = value;
                _mimicLocation = null;
            }
        }

        private static Location _mimicLocation;
        public static Location MimicLocation 
        { 
            get 
            {
                if (MimicData == null)
                    return null;

                if (_mimicLocation != null)
                    return _mimicLocation;

                try
                {
                    _mimicLocation = new Location
                    {
                        Latitude = double.Parse(MimicData.MimicLatitude),
                        Longitude = double.Parse(MimicData.MimicLongitude),
                        Accuracy = 1
                    };
                }
                catch (Exception)
                {
                }

                return _mimicLocation;
            } 
        }
    }
}
