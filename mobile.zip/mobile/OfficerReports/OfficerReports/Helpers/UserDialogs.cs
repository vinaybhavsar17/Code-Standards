﻿using CommunityToolkit.Maui.Views;
using OfficerReports.Controls;
using OfficerReports.Interfaces;
using OfficerReports.Resources.Strings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    class UserDialogs
    {
        private LoadingIndicator _loadingIndicator;
        private UploadProgressIndicator _progressIndicator;

        private static UserDialogs _instance;
        public static UserDialogs Instance
        {
            get
            {
                if(_instance == null)
                    _instance = new UserDialogs();

                return _instance;
            }
        }

        private UserDialogs()
        {

        }

        public void ShowLoading(string message)
        {
            if (_loadingIndicator != null)
                return;

            var currentPage = Application.Current.MainPage;
            _loadingIndicator = new LoadingIndicator();
            _loadingIndicator.Message = message;

            if (currentPage is NavigationPage)
            {
                ((NavigationPage)currentPage).ShowPopup(_loadingIndicator);
            }
        }

        public void HideLoading()
        {
            _loadingIndicator?.Close();
            _loadingIndicator = null;
        }

        public IProgressBarHandler ShowProgress(string message)
        {
            var progressBarHandler = default(IProgressBarHandler);

            if (_progressIndicator != null)
                return progressBarHandler;

            var currentPage = Application.Current.MainPage;
            _progressIndicator = new UploadProgressIndicator();
            _progressIndicator.Message = message;

            if (currentPage is NavigationPage)
            {
                ((NavigationPage)currentPage).ShowPopup(_progressIndicator);
                progressBarHandler = _progressIndicator.ProgressBarHandler;
            }

            return progressBarHandler;
        }

        public void HideProgress()
        {
            _progressIndicator?.Close();
            _progressIndicator = null;
        }

        public void Alert(string message, string title)
        {
            Application.Current.MainPage.DisplayAlert(title, message, AppResource.Ok.ToUpper());
        }

        public async Task<bool> ConfirmAsync(string message, string title, string okText, string cancelText)
        {
            return await Application.Current.MainPage.DisplayAlert(title, message, okText.ToUpper(), cancelText.ToUpper());
        }

        public async Task<string> ActionSheet(string title, string cancel, string destruction, params string[] buttons)
        {
            return await Application.Current.MainPage.DisplayActionSheet(title, cancel, destruction, buttons);
        }
    }
}
