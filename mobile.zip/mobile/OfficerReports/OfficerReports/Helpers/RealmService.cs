﻿using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    public static class RealmService
    {
        private static RealmConfiguration _config = new RealmConfiguration
        {
            ShouldDeleteIfMigrationNeeded = true
        };

        public static Realm GetRealm() => Realm.GetInstance(_config);
    }
}
