﻿using OfficerReports.Models.Chat;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    public class ChatMessageTemplateSelector : DataTemplateSelector
    {
        public DataTemplate SenderMessageTemplate { get; set; }
        public DataTemplate ReceiverMessageTemplate { get; set; }
        public DataTemplate SenderImageTemplate { get; set; }
        public DataTemplate ReceiverImageTemplate { get; set; }
        public DataTemplate EventMessageTemplate { get; set; }

        protected override DataTemplate OnSelectTemplate(object item, BindableObject container)
        {
            var message = (Message)item;

            if (message.MessageContent.Type == MessageContent.MessageType.Event)
                return EventMessageTemplate;

            if (message.MessageContent.UserId == MenuViewModel.LoggedInUser.UserId)
                return GetReceiverTemplate(message.MessageContent);

            return GetSenderTemplate(message.MessageContent);
        }

        private DataTemplate GetSenderTemplate(MessageContent messageContent)
        {
            if (messageContent.Images != null && messageContent.Images.Count > 0)
                return SenderImageTemplate;
            else
                return SenderMessageTemplate;
        }

        private DataTemplate GetReceiverTemplate(MessageContent messageContent)
        {
            if (messageContent.Images != null && messageContent.Images.Count > 0)
                return ReceiverImageTemplate;
            else
                return ReceiverMessageTemplate;
        }
    }
}
