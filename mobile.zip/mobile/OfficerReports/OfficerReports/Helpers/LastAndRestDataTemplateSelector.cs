﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    public class LastAndRestDataTemplateSelector : DataTemplateSelector
    {
        public DataTemplate LastItemTemplate { get; set; }
        public DataTemplate OtherItemTemplate { get; set; }

        protected override DataTemplate OnSelectTemplate(object item, BindableObject container)
        {
            var template = OtherItemTemplate;

            var cv = container as CollectionView;
            if (cv != null)
            {
                var items = cv.ItemsSource.Cast<object>();
                if (cv.IsGrouped)
                {
                    foreach (var itemsGroup in items)
                    {
                        var innerItems = (itemsGroup as IEnumerable).Cast<object>();

                        var isLast = innerItems.LastOrDefault() == item;
                        if (isLast)
                        {
                            template = LastItemTemplate;
                            break;
                        }
                    }
                }
                else
                {
                    var isLast = items.LastOrDefault() == item;
                    template = isLast ? LastItemTemplate : OtherItemTemplate;
                }
            }

            return template;
        }
    }
}
