﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Helpers
{
    public class AuthTokenManager
    {
        private static readonly string TokenKey = "app.auth.token";
        private static readonly string IsMimicKey = "app.auth.ismimic";

        public static string Token { 
            get {
                return Preferences.Get(TokenKey, string.Empty);
            } 
            set {
                Preferences.Set(TokenKey, value);
            } 
        }

        public static bool IsMimic
        {
            get
            {
                return Preferences.Get(IsMimicKey, false);
            }
            set
            {
                Preferences.Set(IsMimicKey, value);
            }
        }

        public static bool IsValidToken()
        {
            var isValid = !IsMimic && !string.IsNullOrEmpty(Token);

            //Check the expiry of token here

            return isValid;
        }
    }
}
