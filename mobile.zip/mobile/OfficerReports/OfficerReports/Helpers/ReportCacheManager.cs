﻿using System;
using System.Dynamic;
using Newtonsoft.Json;

namespace OfficerReports.Helpers
{
	public class ReportCacheManager
	{

        private static List<string> Keys = new List<string>();

		public static void SetValue(string key, string field, object value)
		{
            try
            {
                var jsonString = Preferences.Get(key, string.Empty);
                var obj = GetObject(jsonString);
                obj[field] = JsonConvert.SerializeObject(value);

                var updatedJsonString = JsonConvert.SerializeObject(obj);
                Preferences.Set(key, updatedJsonString);

                SaveKey(key);
            }
            catch (Exception ex)
            {

            }
        }

        private static void SaveKey(string key)
        {
            if (!Keys.Contains(key))
                Keys.Add(key);
        }

        private static void RemoveKey(string key)
        {
            if (Keys.Contains(key))
                Keys.Remove(key);
        }

        public static string GetValue(string key, string field)
		{
            var jsonString = Preferences.Get(key, string.Empty);
            var obj = GetObject(jsonString);

            if (obj.ContainsKey(field))
            {
                return obj[field]?.ToString();
            }

            return string.Empty;
        }

        public static void DeleteValue(string key, string field)
        {
            var jsonString = Preferences.Get(key, string.Empty);
            var obj = GetObject(jsonString);

            obj.Remove(field);

            var updatedJsonString = JsonConvert.SerializeObject(obj);
            Preferences.Set(key, updatedJsonString);
        }

        public static IDictionary<string, string> GetData(string key)
        {
            var jsonString = Preferences.Get(key, string.Empty);
            var obj = GetObject(jsonString);

            return obj;
        }

        public static void ClearData(string key)
        {
            Preferences.Remove(key);
            Keys.Remove(key);
        }

        public static void ClearAllData()
        {
            foreach (var key in Keys)
            {
                Preferences.Remove(key);
            }

            if(Keys.Count > 0)
                Keys.RemoveRange(0, Keys.Count);
        }

        private static IDictionary<string, string> GetObject(string jsonString)
		{
            IDictionary<string, string> obj = null;
            try
            {
                obj = JsonConvert.DeserializeObject<IDictionary<string, string>>(jsonString);
            }
            catch (Exception ex)
            {

            }

            if (obj == null)
                obj = new Dictionary<string, string>();

            return obj;
        }
	}
}

