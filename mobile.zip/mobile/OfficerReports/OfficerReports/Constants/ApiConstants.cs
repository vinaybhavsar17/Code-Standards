﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Constants
{
    public class ApiConstants
    {
        //public static readonly string BASE_URL = "https://dev.officerreports.net/api/";
        public static readonly string BASE_URL = "https://officerapps.net/api/";

        //Authentication
        public static readonly string LOGIN_API = "Account/Login";
        public static readonly string LOGOUT_API = "Account/LogOut";
        public static readonly string FORGOT_PASSWORD_API = "Account/ForgotPassword";
        public static readonly string FORGOT_USERNAME_API = "Account/ForgotUserName";
        public static readonly string GENERATE_SAS_TOKEN_API = "Account/GenrateSasToken";
        public static readonly string CHECK_OTP_API = "Account/CheckOTP";
        public static readonly string RESEND_OTP_API = "Account/ReSendOTP";
        public static readonly string MIMIC_LOGIN_API = "admin/Accounts/MimicUserLoginForMobile";
        public static readonly string SIGNIN_LOG_API = "TimeAndAttendence/InsertLocationLog";
        public static readonly string RESET_PASSWORD_API = "admin/Accounts/ResetExpiredPassword";

        //Vacation
        public static readonly string CREATE_VACATION_API = "Vacation/InsertVacationRequest";
        public static readonly string GET_VACATION_REQUESTS_API = "Vacation/GetVacationRequest";
        public static readonly string WITHDRAW_VACATION_API = "Vacation/WithdrawnVacationRequest";

        //Select Work Site
        public static readonly string GET_SITES_IN_RANGE_API = "TimeAndAttendence/GetAllSiteWithinTheRange";
        public static readonly string GET_All_SITES_API = "Client/GetClientSiteByCustomer";
        public static readonly string GET_All_MASTER_DATA_API = "Report/GetTypeListAndOfficerMasterData";

        //Daily Activity Report
        public static readonly string CREATE_DAILY_ACTIVITY_REPORT_API = "Report/InsertDARandObservation";
        public static readonly string GET_OBSERVATION_TYPES_API = "Report/GetObservationType";

        //Policy Manual
        public static readonly string GET_POLICY_MANUAL_API = "Home/GetAllPolicyManuals";

        //Clock In-Out
        public static readonly string GET_CLOCK_TYPES_API = "TimeAndAttendence/GetClockTypes";
        public static readonly string GET_CLOCK_IN_OUT_DETAILS_API = "TimeAndAttendence/GetAllClockInOutDetailsByOfficer";
        public static readonly string CHECK_USER_TO_SITE_DISTANCE_API = "TimeAndAttendence/CheckUserToSiteDistance";
        public static readonly string CLOCK_IN_API = "TimeAndAttendence/InsertClockInDetails";
        public static readonly string CLOCK_OUT_API = "TimeAndAttendence/InsertClockOutDetails";

        //Incident
        public static readonly string GET_INCIDENT_TYPE_API = "Report/GetIncidentType";
        public static readonly string CREATE_INCIDENT_REPORT_API = "Report/InsertIncidentReports";
        public static readonly string GET_INCIDENT_CHECKLIST_API = "TypeList/GetIncidentChecklist";

        //Field Inspection
        public static readonly string CREATE_FIELD_INSPECTION_REPORT_API = "Report/InsertInspectionReports";
        public static readonly string GET_FIELD_INSPECTION_OFFICER_LIST_API = "User/GetOfficers";
        //Entity
        public static readonly string ADD_ENTITY_API = "Entity/AddEntity";

        //Maintenance Report
        public static readonly string GET_MAINTENANCE_TYPE_API = "Report/GetMaintenanceType";
        public static readonly string CREATE_MAINTENANCE_REPORT_API = "Report/InsertMaintenanceReport";

        //Parking Violation
        public static readonly string GET_PARKING_VIOLATION_TYPE_API = "Report/GetParkingViolationsType";
        public static readonly string CREATE_PARKING_VIOLATION_REPORT_API = "Report/InsertParkingViolations";
        public static readonly string SEARCH_PARKING_VIOLATIONS_API = "Report/GetParkingViolationByOfficers";

        //Tour Tracker
        public static readonly string SUBMIT_TOUR_STOP_SCAN_API = "TourTracking/InsertSiteTourStopScans";
        public static readonly string GET_TOUR_STOP_SCAN_API = "TourTracking/GetSiteTourStopScanForMobile";        

        //Pass On Log
        public static readonly string CREATE_PASS_ON_LOG_REPORT_API = "Report/InsertPassOnLog";
        public static readonly string GET_PASS_ON_LOG_ENTRY_API = "Report/GetPassOnLogEntryBySite";
        public static readonly string GET_PASS_ON_LOG_ENTRY_DETAIL_API = "Report/ViewPassOnLog";
        public static readonly string CHANGE_READ_STATUS_PASS_ON_LOG_VIEW = "Report/InsertPassOnLogView";

        //PostOrder
        public static readonly string GET_POST_ORDER_API = "Client/GetSitePostOrder";
        
        //Temperature Log
        public static readonly string GET_EQUIPMENT_TYPES_API = "Report/GetEquipmentType";
        public static readonly string CREATE_TEMPERATURE_LOG_API = "Report/InsertTemperatureLog";

        //Visitor Check In Out
        public static readonly string GET_VISITOR_CHECK_OUT_API = "Tracking/GetVisitorLogs";
        public static readonly string UPDATE_VISITOR_CHECK_OUT_LOG_API = "Tracking/UpdateVisitorLog";
        public static readonly string GET_VISITOR_ID_TYPE_API = "Tracking/GetVisitorIdType";
        public static readonly string CREATE_VISITOR_CHECKIN_API = "Tracking/InsertVisitorLog"; 

        //Truck Check In/Out
        public static readonly string CREATE_TRUCK_CHECK_IN_API = "Tracking/InsertTruckLog";
        public static readonly string GET_TRUCK_CHECK_OUT_LOG_API = "Tracking/GetTruckLogBySite";
        public static readonly string CREATE_TRUCK_CHECK_OUT_API = "Tracking/UpdateTruckLog";

        //Chat
        public static readonly string GET_CHAT_GROUPS_API = "Messaging/GetOfficerMessageGroup";
        public static readonly string GET_CHAT_MESSAGES_API = "Messaging/GetMessagingHistoryByOfficer";
        public static readonly string GET_NEW_MESSAGES_COUNT_API = "Messaging/GetNewMessageCount";

        //SOS
        public static readonly string CREATE_SOS_ALERT_API = "SOSAlertAndCheckSite/InsertSOSAlert";

        //Site Check Report
        public static readonly string CREATE_SITE_CHECK_REPORT_API = "SOSAlertAndCheckSite/InsertCheckSite";

        //SignalR
        public static readonly string SignalRNotify = "notify";
        public static readonly string SignalRMethod_AsotRequest = "AddASOTRequest";
        public static readonly string SignalRMethod_JoinGroup = "JoinGroup";
        public static readonly string SignalRMethod_SendMessage = "SendMessageToGroup";
        public static readonly string SignalRMethod_ReceiveMessage = "ReceiveMessage";
        public static readonly string SignalRMethod_ReceiveNew = "ReceiveNewNotification";

        //Custom Report
        public static readonly string GET_OFFICER_PORTAL_MENU_LIST = "Account/OfficerPortalMenu";
        public static readonly string GET_CUSTOM_REPORT_JSON = "CustomReportData/GetCustomReportJsonForm";
        public static readonly string CREATE_CUSTOM_REPORT_API = "CustomReportData/InsertCustomReportData";
        public static readonly string ADD_CUSTOM_REPORT_ENTITY_API = "CustomReportData/InsertReportAttachments";

        //Scheduler
        public static readonly string GET_SCHEDULE_BY_CUSTOMER = "Schedule/GetSchedulesByCustomer";
        public static readonly string GET_SCHEDULE_BY_OFFICER = "Schedule/GetSchedulesByOfficers";
    }
}
