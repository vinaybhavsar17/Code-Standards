﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Constants
{
    public class AppConstants
    {
        public static readonly string DateFormat = "MM/dd/yyyy";
        public static readonly string DateTimeFormat = "MM/dd/yyyy hh:mm tt";
        public static readonly string TimeFormat = "hh:mm tt";

        public static readonly string PurposeReports = "Reports";
        public static readonly string PurposeCustomReports = "CustomReports";
        public static readonly string PurposeChatMessaging = "ChatMessaging";

        public static readonly string RelatedSectionOfficer = "Officer";
        public static readonly string RelatedSectionVehicle = "Vehicle";
        public static readonly string TypeOther = "Other";
        public static readonly string TypeNA = "N/A";
        public static readonly string MaintenanceTypeOther = "Other Issue";

        public static readonly string PassOnLogStatusRead = "Read";
        public static readonly string PassOnLogStatusUnRead = "Unread";

        public static readonly int SearchDurationInDays = 15;

        public static readonly string QrCodeIdentifier = "OR";

        //Messaging Center messages
        public static readonly string MessageLocationUpdate = "com.sipl.MessageLocationUpdate";
        public static readonly string MessageMimicStart = "com.sipl.MessageMimicStart";
        public static readonly string MessageMimicStop = "com.sipl.MessageMimicStop";
        public static readonly string MessageReceiveChat = "com.sipl.MessageReceiveChat";
        public static readonly string MessageNewChat = "com.sipl.MessageNewChat";
        public static readonly string MessageCountUpdate = "com.sipl.MessageCountUpdate";
        public static readonly string MessageOfflineUpdate = "com.sipl.MessageOfflineUpdate";

        //Custom Report constants
        public static readonly string SiteMenuCustomReport = "Custom Reports";
        public const string CustomReportText = "text";
        public const string CustomReportDropdown = "dropdown";
        public const string CustomReportTextarea = "textarea";
        public const string CustomReportDateTime = "date-time";
        public const string CustomReportPassword = "password";
        public const string CustomReportCheckbox = "checkbox";
    }
}
