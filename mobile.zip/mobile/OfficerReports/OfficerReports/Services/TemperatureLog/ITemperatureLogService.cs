﻿using OfficerReports.Models.Base;
using OfficerReports.Models.TemperatureLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.TemperatureLog
{
    public interface ITemperatureLogService
    {

        public Task<ApiResponse> GetEquipmentTypes();
        public Task<ApiResponse> CreateTemperatureLog(CreateTemperatureLogRequest request);

    }
}
