﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.Site;
using OfficerReports.Models.TemperatureLog;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.TemperatureLog
{
    public class TemperatureLogService : ApiBaseService, ITemperatureLogService
    {
        public async Task<ApiResponse> GetEquipmentTypes()
        {
            var apiData = (MasterData)GetCachedApiData<MasterDataDto>();
            var response = new ApiResponse
            {
                IsCached = true,
                Status = true,
                StatusCode = 200
            };

            if (apiData != null && apiData.EquipmentType != null)
            {
                response.ProcessedData = apiData.EquipmentType;
            }
            else
            {
                response.ProcessedData = new EquipmentType
                {
                    Data = new List<EquipmentTypeItem>()
                };
            }

            return response;
        }

        public async Task<ApiResponse> CreateTemperatureLog(CreateTemperatureLogRequest request)
        {
            if (CanCallApi())
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_TEMPERATURE_LOG_API, request);
            else
                return await CacheData<CreateTemperatureLogRequest>(request);
        }
    }
}
