﻿using OfficerReports.Models.Base;
using OfficerReports.Models.Chat;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Chat
{
    public interface IMessagingService
    {
        public Task<ApiResponse> GetChatGroups(ChatGroupsRequest request);

        public Task<ApiResponse> GetChatMessages(ChatMessagesRequest request);
    }
}
