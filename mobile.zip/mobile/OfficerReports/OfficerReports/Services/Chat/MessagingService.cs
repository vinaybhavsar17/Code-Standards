﻿using Azure;
using OfficerReports.Constants;
using OfficerReports.Models.Base;
using OfficerReports.Models.Chat;
using OfficerReports.Services.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Chat
{
    public class MessagingService : ApiBaseService, IMessagingService
    {
        public async Task<ApiResponse> GetChatGroups(ChatGroupsRequest request)
        {
            var cachedData = FetchChatGroups(request);

            ApiResponse response = null;
            if (cachedData == null || Helpers.NetworkUtility.IsInternetConnected)
            {
                response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.GET_CHAT_GROUPS_API, request);

                response.ProcessedData = response.GetApiData<ChatGroupsResult>();
                var chatGroupsResult = (ChatGroupsResult)response.ProcessedData;
                if(chatGroupsResult != null && chatGroupsResult.Records != null)
                    CacheChatGroups(request, (ChatGroupsResult)response.ProcessedData);
            }
            else
            {
                response = new ApiResponse
                {
                    Status = true,
                    StatusCode = 200,
                    ProcessedData = cachedData
                };
            }

            return response;
        }

        public async Task<ApiResponse> GetChatMessages(ChatMessagesRequest request)
        {
            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.GET_CHAT_MESSAGES_API, request);

            response.ProcessedData = response.GetApiData<ChatMessagesResult>();
            return response;
        }

        private void CacheChatGroups(ChatGroupsRequest request, ChatGroupsResult data)
        {
            var realm = Helpers.RealmService.GetRealm();
            realm.Write(() =>
            {
                var realmData = (ChatGroupsResultDto)data.ToRealmObject();
                IQueryable<ChatGroupsResultDto> removableItem = null;

                if (request.UserId > 0) //If this request is for getting officer chat groups
                {
                    removableItem = realm.All<ChatGroupsResultDto>().Where(c => c.ChatGroupTypeId == (int)ChatGroupsResultDto.ChatGroupType.OfficerGroup);
                    realmData.GroupType = ChatGroupsResultDto.ChatGroupType.OfficerGroup;
                }
                else if (request.ClientSiteId > 0) //If this request is for getting site chat groups
                {
                    removableItem = realm.All<ChatGroupsResultDto>().Where(c => c.ChatGroupTypeId == (int)ChatGroupsResultDto.ChatGroupType.SiteGroup);
                    realmData.GroupType = ChatGroupsResultDto.ChatGroupType.SiteGroup;
                }

                realm.RemoveRange<ChatGroupsResultDto>(removableItem);
                realmData.UserId = ViewModels.MenuViewModel.LoggedInUser.UserId;
                realm.Add(realmData);
            });
        }

        private ChatGroupsResult FetchChatGroups(ChatGroupsRequest request)
        {
            var realm = Helpers.RealmService.GetRealm();
            ChatGroupsResult result = null;

            if (request.UserId > 0) //If this request is for getting officer chat groups
            {
                result = (ChatGroupsResult)realm.All<ChatGroupsResultDto>()
                    .Where(c =>
                        c.ChatGroupTypeId == (int)ChatGroupsResultDto.ChatGroupType.OfficerGroup &&
                        c.UserId == ViewModels.MenuViewModel.LoggedInUser.UserId
                    )
                    .FirstOrDefault()?.ToApiObject();
            }
            else if (request.ClientSiteId > 0) //If this request is for getting site chat groups
            {
                result = (ChatGroupsResult)(realm.All<ChatGroupsResultDto>()
                    .Where(c =>
                        c.ChatGroupTypeId == (int)ChatGroupsResultDto.ChatGroupType.SiteGroup &&
                        c.UserId == ViewModels.MenuViewModel.LoggedInUser.UserId
                    )
                    .FirstOrDefault()?.ToApiObject());
            }

            return result;
        }
    }
}
