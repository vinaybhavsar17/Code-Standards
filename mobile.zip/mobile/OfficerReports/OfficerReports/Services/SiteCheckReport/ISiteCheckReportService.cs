﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.SiteCheckReport;

namespace OfficerReports.Services.SiteCheckReport
{
    public interface ISiteCheckReportService 
    {
        public Task<ApiResponse> CreateSiteCheckReport(CreateSiteCheckReport request);
    }
}
