﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.SiteCheckReport;
using OfficerReports.Services.Base;

namespace OfficerReports.Services.SiteCheckReport
{
    public class SiteCheckReportService : ApiBaseService, ISiteCheckReportService
    {
        public async Task<ApiResponse> CreateSiteCheckReport(CreateSiteCheckReport request)
        {
            if (CanCallApi())
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_SITE_CHECK_REPORT_API, request);
            else
                return await CacheData<CreateSiteCheckReport>(request);
        }
    }
}
