﻿using OfficerReports.ApiClient;
using OfficerReports.Helpers;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.DailyActivityReport;
using OfficerReports.Resources.Strings;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Base
{
    public class ApiBaseService : BaseService
    {
        protected IRestApiClient ApiClient;

        protected ApiResponse CachedApiResponse
        {
            get
            {
                return new ApiResponse
                {
                    IsCached = true,
                    Status = true,
                    StatusCode = 200,
                    Message = AppResource.Report_Cached
                };
            }
        }

        protected ApiResponse CacheFailedApiResponse
        {
            get
            {
                return new ApiResponse
                {
                    IsCached = false,
                    Status = false,
                    StatusCode = 0,
                    Message = AppResource.Cache_Failed
                };
            }
        }

        public ApiBaseService()
        {
            ApiClient = App.ServiceProvider.GetRequiredService<IRestApiClient>();
        }

        protected string AddParametersToUrl(string url, params QueryString[] parameters)
        {
            for (int i = 0; i < parameters.Length; i++)
            {
                var param = parameters[i];

                if(i == 0)
                    url += "?" + param.Key + "=" + param.Value;
                else
                    url += "&" + param.Key + "=" + param.Value;

            }

            return url;
        }

        protected bool CanCallApi()
        {
            return NetworkUtility.IsInternetConnected;
        }

        protected Task<ApiResponse> CacheData<TData>(TData data) where TData : ApiRequest
        {
            var tcs = new TaskCompletionSource<ApiResponse>();

            try
            {
                using var realm = RealmService.GetRealm();

                var dataObj = data.ToRealmObject();
                if (dataObj != null)
                {
                    realm.Write(() =>
                    {
                        var realmObj = realm.Add(dataObj, update: true);
                        var dtoObj = (dynamic)realmObj;

                        ApiResponse response = CachedApiResponse;
                        response.CachedDataId = dtoObj.Id;
                        tcs.SetResult(response);
                    });
                }
                else
                {
                    tcs.SetResult(CacheFailedApiResponse);
                }
            }
            catch (Exception ex)
            {
                tcs.SetResult(CacheFailedApiResponse);
            }

            return tcs.Task;
        }

        protected Task<bool> CacheApiData<TData>(TData data) where TData : ApiData
        {
            var tcs = new TaskCompletionSource<bool>();

            try
            {
                using var realm = RealmService.GetRealm();

                var dataObj = data.ToRealmObject();
                if (dataObj != null)
                {
                    realm.Write(() =>
                    {
                        realm.Add(dataObj, update: true);
                        tcs.SetResult(true);
                    });
                }
                else
                {
                    tcs.SetResult(false);
                }
            }
            catch (Exception ex)
            {
                tcs.SetResult(false);
            }

            return tcs.Task;
        }

        public bool IsDataCached<TData>() where TData : RealmObject
        {
            var isCached = false;

            try
            {
                using var realm = RealmService.GetRealm();
                var records = realm.All<TData>();

                if (records != null && records.Count() > 0)
                {
                    isCached = true;
                }
            }
            catch (Exception ex)
            {
            }

            return isCached;
        }

        public ApiData GetCachedApiData<TData>() where TData : RealmObject
        {
            var apiData = default(ApiData);

            try
            {
                using var realm = RealmService.GetRealm();
                var records = realm.All<TData>();

                if (records != null && records.Count() > 0)
                {
                    var data = records.FirstOrDefault();
                    if(data is IApiData dtoObj)
                    {
                        apiData = dtoObj.ToApiObject();
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return apiData;
        }

        public void CacheFiles(List<Models.FileInfo> files, Guid reportId, int entityType, string purpose, string section = "")
        {
            try
            {
                using var realm = RealmService.GetRealm();

                realm.Write(() =>
                {
                    foreach (var file in files)
                    {
                        var fileInfoDto = (FileInfoDto)file.ToRealmObject();
                        fileInfoDto.ReportId = reportId;
                        fileInfoDto.Section = section;
                        fileInfoDto.Purpose = purpose;
                        fileInfoDto.EntityType = entityType;
                        realm.Add(fileInfoDto, true);
                    }
                });
            }
            catch (Exception ex)
            {
            }
        }
    }
}
