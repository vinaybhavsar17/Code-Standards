﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Base
{
    public class BaseService
    {
        protected ILogger<BaseService> Logger;

        public BaseService()
        {
            Logger = App.ServiceProvider.GetRequiredService<ILogger<BaseService>>();
        }
    }
}
