﻿using Newtonsoft.Json;
using OfficerReports.Constants;
using OfficerReports.Helpers;
using OfficerReports.Interfaces;
using OfficerReports.Models;
using OfficerReports.Models.Authentication;
using OfficerReports.Models.Base;
using OfficerReports.Services.Base;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.User;
using System.Net;

namespace OfficerReports.Services.Authentication
{
    public class AuthenticationService : ApiBaseService, IAuthenticationService
    {
        public async Task<ApiResponse> Login(string username, string password)
        {
            var ipAddressString = PlatformServices.GetIPAddress();

            LoginRequest request = new LoginRequest
            {
                Username = username,
                Password = password,
                DeviceInfo = DeviceInfo.Platform.ToString(),
                DeviceType = "mobile",
                AppVersion = $"{AppInfo.VersionString}({AppInfo.BuildString})",
                BrowserInfo = "string",
                SignInApp = true,
                IpAddress = ipAddressString,
                Latitude = 0,
                Longitude = 0
            };

            var response = await ApiClient.Post<LoginRequest, ApiResponse>(ApiConstants.LOGIN_API, request);

            var user = (Models.Authentication.User)response?.GetApiData<Models.Authentication.User>();

            if (user.RoleName != null && !user.RoleName.Equals(Models.Authentication.User.AdminRole))
            {
                AuthTokenManager.Token = user?.AccessToken;
                AuthTokenManager.IsMimic = false;

                var userService = App.ServiceProvider.GetRequiredService<IUserService>();
                userService.SaveLoggedInUserInfo(user);
            }

            response.ProcessedData = user;
            return response;
        }

        public async Task<ApiResponse> Logout()
        {
            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.LOGOUT_API, null);

            return response;
        }

        public async Task<ApiResponse> ResetPassword(ResetPasswordRequest request)
        {
            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.RESET_PASSWORD_API, request);

            return response;
        }

        public async Task<ApiResponse> CheckOtp(string otp, string token)
        {
            var otpParam = new QueryString
            {
                Key = "otp",
                Value = otp
            };
            var apiUrl = AddParametersToUrl(ApiConstants.CHECK_OTP_API, otpParam);

            var response = await ApiClient.Get<ApiResponse>(apiUrl, token);

            return response;
        }

        public async Task<ApiResponse> ResendOtp(string username)
        {
            var response = await ApiClient.Get<ApiResponse>(ApiConstants.RESEND_OTP_API);

            return response;
        }

        private async Task<string> MimicPreLogin(string username, string password, string baseUrl)
        {
            LoginRequest request = new LoginRequest
            {
                Username = username,
                Password = password,
                DeviceInfo = "string",
                DeviceType = "mobile",
                AppVersion = $"{AppInfo.VersionString}({AppInfo.BuildString})",
                BrowserInfo = "string",
                SignInApp = true,
                Latitude = 0,
                Longitude = 0
            };

            var response = await ApiClient.PostWithNewClient<LoginRequest, ApiResponse>(baseUrl, ApiConstants.LOGIN_API, request);

            var user = (Models.Authentication.User)response?.GetApiData<Models.Authentication.User>();

            return user?.AccessToken;
        }

        public async Task<ApiResponse> MimicLogin(string mimicUsername, dynamic adminCredentials, string baseUrl)
        {
            var token = await MimicPreLogin(adminCredentials.Username, adminCredentials.Password, baseUrl);
            dynamic request = new
            {
                MimicUserName = mimicUsername
            };

            var response = await ApiClient.PostWithNewClient<dynamic, ApiResponse>(baseUrl, ApiConstants.MIMIC_LOGIN_API, request, token);

            var user = (Models.Authentication.User)response?.GetApiData<Models.Authentication.User>();

            if (user.RoleName != null && 
                !user.RoleName.Equals(Models.Authentication.User.SiteUserRole) &&
                !user.RoleName.Equals(Models.Authentication.User.ClientUserRole) &&
                !user.RoleName.Equals(Models.Authentication.User.CcrRole))
            {
                AuthTokenManager.Token = user?.AccessToken;
                AuthTokenManager.IsMimic = true;

                var userService = App.ServiceProvider.GetRequiredService<IUserService>();
                userService.SaveLoggedInUserInfo(user);
            }

            response.ProcessedData = user;
            return response;
        }

        public async Task<ApiResponse> SubmitSigninLog(SigninLog signinLogRequest)
        {
            var response = await ApiClient.Post<SigninLog, ApiResponse>(ApiConstants.SIGNIN_LOG_API, signinLogRequest);

            return response;
        }
    }
}