﻿using OfficerReports.Models.Authentication;
using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Authentication
{
    public interface IAuthenticationService
    {
        public Task<ApiResponse> Login(string username, string password);

        public Task<ApiResponse> Logout();

        public Task<ApiResponse> ResetPassword(ResetPasswordRequest request);

        public Task<ApiResponse> CheckOtp(string otp, string token);

        public Task<ApiResponse> ResendOtp(string username);

        public Task<ApiResponse> MimicLogin(string mimicUsername, dynamic adminCredentials, string baseUrl);

        public Task<ApiResponse> SubmitSigninLog(SigninLog signinLogRequest);
    }
}
