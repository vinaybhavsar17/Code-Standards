﻿using OfficerReports.Constants;
using OfficerReports.Models.Base;
using OfficerReports.Models.FieldInspection;
using OfficerReports.Models.Site;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Base;
using OfficerReports.Services.LocationService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.FieldInspection
{
    public class FieldInspectionService : ApiBaseService, IFieldInspectionService
    {

        public async Task<ApiResponse> CreateFieldInspectionRequest(CreateFieldInspectionRequest request)
        {
            var locationService = App.ServiceProvider.GetRequiredService<ILocationService>();
            var userLocation = await locationService.GetCurrentLocation();

            if (userLocation == null)
                return new ApiResponse { IgnoreResponse = true };

            request.CreatedLatitude = userLocation.Latitude.ToString();
            request.CreatedLongitude = userLocation.Longitude.ToString();

            if (CanCallApi())
            {
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_FIELD_INSPECTION_REPORT_API, request);
            }
            else
            {
                return await CacheData<CreateFieldInspectionRequest>(request);
            }
        }

        public async Task<ApiResponse> GetFieldInspectionOfficerList()
        {
            var apiData = (MasterData)GetCachedApiData<MasterDataDto>();
            var response = new ApiResponse
            {
                IsCached = true,
                Status = true,
                StatusCode = 200
            };

            if (apiData != null)
            {
                response.Data = apiData.Officers;
            }

            return response;
        }
    }
}
