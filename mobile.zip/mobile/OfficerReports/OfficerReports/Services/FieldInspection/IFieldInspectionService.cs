﻿using OfficerReports.Models.Base;
using OfficerReports.Models.FieldInspection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.FieldInspection
{
    public interface IFieldInspectionService
    {
        public Task<ApiResponse> CreateFieldInspectionRequest(CreateFieldInspectionRequest request);

        public Task<ApiResponse> GetFieldInspectionOfficerList();
    }
}
