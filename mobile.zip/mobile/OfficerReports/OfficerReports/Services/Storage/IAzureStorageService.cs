﻿using OfficerReports.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Storage
{
    public interface IAzureStorageService
    {
        public Task<bool> UploadFiles(string purpose, List<Models.FileInfo> files, EntityRequest entityRequest, string section = null, bool isBackground = false);

        public Task<bool> UploadFiles(string purpose, List<FilesUploadData> fileSetToUpload, EntityRequest entityRequest, bool isBackground = false);
        
        public Task<List<Models.FileInfo>> UploadFiles(string purpose, List<Models.FileInfo> files);
    }
}
