﻿
 using OfficerReports.ApiClient;
using OfficerReports.Interfaces;
using OfficerReports.Models;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Dialog;
using OfficerReports.ViewModels.Base;
using OfficerReports.Views.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Storage
{
    public class FileStorageService : IFileStorageService
    {

    }
}
