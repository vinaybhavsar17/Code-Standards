﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Logging;
using OfficerReports.Constants;
using OfficerReports.Controls;
using OfficerReports.Interfaces;
using OfficerReports.Models;
using OfficerReports.Models.Authentication;
using OfficerReports.Models.Base;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Base;
using OfficerReports.Services.Dialog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace OfficerReports.Services.Storage
{
    public class AzureStorageService : ApiBaseService, IAzureStorageService
    {
        private readonly string _connectionString = "DefaultEndpointsProtocol=https;AccountName=orv3qastorage;AccountKey=UTqxK4/Y3A1bRLBX8SKpv7wNnucxCuvojUecB9Zl4r2c3mHIS1/kr9oH/i4fWkil9llE8ZjvX465paPbFL2dyw==;EndpointSuffix=core.windows.net";
        private IDialogService _dialogService;
        private IProgressBarHandler _progressBarHandler;
        private long _totalFileSize;
        private int _totalFilesCount;
        private long _totalBytesUploaded;
        private long _bytesUploadedForFile;
        private long _lastUploadedByte;

        public AzureStorageService(IDialogService dialogService)
        {
            _dialogService = dialogService;
        }

        public async Task<bool> UploadFiles(string purpose, List<Models.FileInfo> files, EntityRequest entityRequest, string section = null, bool isBackground = false)
        {
            if (files == null) return false;

            bool isSuccess = false;
            _totalBytesUploaded = 0;
            try
            {
                if(!isBackground)
                    _progressBarHandler = _dialogService.ShowProgress(AppResource.Initiating_Upload);

                var sasToken = await GenerateSasToken(purpose);

                _totalFilesCount = files.Count;
                _totalFileSize = files.Sum(f => f.FileSize);

                var container = new BlobContainerClient(_connectionString, sasToken.Container);
                container.CreateIfNotExists();

                for (int i = 0; i < files.Count; i++)
                {
                    var fileInfo = files[i];
                    var blobName = string.Empty;

                    if (fileInfo.ContentType.Contains("image"))
                    {
                        blobName = "EntityPhoto/" + Guid.NewGuid().ToString() + fileInfo.FileName;
                    }
                    else
                    {
                        blobName = "EntityMedia/" + Guid.NewGuid().ToString() + fileInfo.FileName;
                    }

                    fileInfo.AzureFileName = blobName;
                    var blob = container.GetBlobClient(blobName);

                    if (!isBackground)
                    {
                        var progressHandler = new Progress<long>();
                        progressHandler.ProgressChanged += UploadProgressChanged;
                        _progressBarHandler.SetMessage($"{AppResource.Uploading} {i + 1}/{_totalFilesCount} {AppResource.Files}");

                        var result = await blob.UploadAsync(fileInfo.FullPath, new BlobUploadOptions
                        {
                            ProgressHandler = progressHandler
                        });
                        isSuccess = !result.GetRawResponse().IsError;
                    }
                    else
                    {
                        var result = await blob.UploadAsync(fileInfo.FullPath);
                        isSuccess = !result.GetRawResponse().IsError;
                    }
                    
                    if (!isSuccess) break;
                }

                if (isSuccess)
                {
                    if (!isBackground)
                        _progressBarHandler.SetMessage(AppResource.Finalizing_Upload);

                    if (entityRequest is CustomReportEntityRequest customReportEntityRequest)
                        isSuccess = await AddCustomReportEntity(sasToken, files, customReportEntityRequest, section);
                    else
                        isSuccess = await AddEntity(sasToken, files, entityRequest, section);

                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
            }
            finally
            {
                if (!isBackground)
                    _dialogService.HideProgress();
            }

            return isSuccess;
        }

        public async Task<bool> UploadFiles(string purpose, List<FilesUploadData> fileSetToUpload, EntityRequest entityRequest, bool isBackground = false)
        {
            if (fileSetToUpload == null || fileSetToUpload.Count == 0) return false;

            bool isSuccess = false;
            _totalBytesUploaded = 0;

            try
            {
                if (!isBackground)
                    _progressBarHandler = _dialogService.ShowProgress(AppResource.Initiating_Upload);

                var sasToken = await GenerateSasToken(purpose);

                _totalFilesCount = fileSetToUpload.Sum(f => f.Files.Count);
                _totalFileSize = fileSetToUpload.Sum(f => f.Files.Sum(g => g.FileSize));

                var container = new BlobContainerClient(_connectionString, sasToken.Container);
                container.CreateIfNotExists();

                var i = 0;
                foreach (var fileSet in fileSetToUpload)
                {
                    foreach (var fileInfo in fileSet.Files)
                    {
                        var blobName = string.Empty;

                        if (fileInfo.ContentType.Contains("image"))
                        {
                            blobName = "EntityPhoto/" + Guid.NewGuid().ToString() + fileInfo.FileName;
                        }
                        else
                        {
                            blobName = "EntityMedia/" + Guid.NewGuid().ToString() + fileInfo.FileName;
                        }

                        fileInfo.AzureFileName = blobName;
                        var blob = container.GetBlobClient(blobName);

                        if (!isBackground)
                        {
                            var progressHandler = new Progress<long>();
                            progressHandler.ProgressChanged += UploadProgressChanged;
                            _progressBarHandler.SetMessage($"{AppResource.Uploading} {i + 1}/{_totalFilesCount} {AppResource.Files}");
                            i++;

                            var result = await blob.UploadAsync(fileInfo.FullPath, new BlobUploadOptions
                            {
                                ProgressHandler = progressHandler
                            });
                            isSuccess = !result.GetRawResponse().IsError;
                        }
                        else
                        {
                            var result = await blob.UploadAsync(fileInfo.FullPath);
                            isSuccess = !result.GetRawResponse().IsError;
                        }

                        if (!isSuccess) break;
                    }
                }

                if (isSuccess)
                {
                    isSuccess = await AddEntity(sasToken, fileSetToUpload, entityRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
            }
            finally
            {
                if (!isBackground)
                    _dialogService.HideProgress();
            }

            return isSuccess;
        }

        public async Task<List<Models.FileInfo>> UploadFiles(string purpose, List<Models.FileInfo> files)
        {
            if (files == null) return null;

            if (!Helpers.NetworkUtility.IsInternetConnected) return null;

            bool isSuccess = false;
            try
            {
                var sasToken = await GenerateSasToken(purpose);

                var container = new BlobContainerClient(_connectionString, sasToken.Container);
                container.CreateIfNotExists();

                for (int i = 0; i < files.Count; i++)
                {
                    var fileInfo = files[i];
                    var blobName = string.Empty;

                    if (fileInfo.ContentType.Contains("image"))
                    {
                        blobName = "EntityPhoto/" + Guid.NewGuid().ToString() + fileInfo.FileName;
                    }
                    else
                    {
                        blobName = "EntityMedia/" + Guid.NewGuid().ToString() + fileInfo.FileName;
                    }

                    fileInfo.AzureFileName = blobName;
                    fileInfo.AzureFileUrl = sasToken.StorageUri + sasToken.Container + "/" + blobName;
                    var blob = container.GetBlobClient(blobName);

                    var result = await blob.UploadAsync(fileInfo.CompressedImagePath);
                    isSuccess = !result.GetRawResponse().IsError;
                    if (!isSuccess) break;
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
            }

            if (isSuccess)
                return files;
            else
                return null;
        }

        private async Task<SasToken> GenerateSasToken(string purpose)
        {
            var purposeParam = new QueryString
            {
                Key = "purpose",
                Value = purpose
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GENERATE_SAS_TOKEN_API, purposeParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            return (SasToken)response.GetApiData<SasToken>();
        }

        private async Task<bool> AddEntity(SasToken sasToken, List<Models.FileInfo> files, EntityRequest entityRequest, string section)
        {
            entityRequest.EntityMedia = new List<EntityMedia>();
            entityRequest.EntityPhoto = new List<EntityPhoto>();
            entityRequest.EntityAttachment = new List<string>();
            entityRequest.EntityComment = new List<string>();

            foreach (var file in files)
            {
                if (file.ContentType.Contains("image"))
                {
                    var entityPhoto = new EntityPhoto
                    {
                        FileName = file.AzureFileName,
                        FileType = file.ContentType,
                        FileUrl = sasToken.StorageUri + sasToken.Container + "/" + file.AzureFileName,
                        PhotoDescription = file.Notes,
                        PhotoOriginal = file.FileName,
                        CreatedDate = file.CreatedDate
                    };
                    if (!string.IsNullOrEmpty(section))
                    {
                        entityPhoto.RelatedSection = section;
                    }
                    entityRequest.EntityPhoto.Add(entityPhoto);
                }
                else
                {
                    var entityMedia = new EntityMedia
                    {
                        FileName = file.FileName,
                        FileType = file.ContentType,
                        FileUrl = sasToken.StorageUri + sasToken.Container + "/" + file.AzureFileName,
                        AttachmentDescription = file.Notes,
                        OriginalFileName = file.FileName,
                        CreatedDate = file.CreatedDate
                    };
                    if (!string.IsNullOrEmpty(section))
                    {
                        entityMedia.RelatedSection = section;
                    }
                    entityRequest.EntityMedia.Add(entityMedia);
                }
            }
            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.ADD_ENTITY_API, entityRequest);

            return response.IsSuccess;
        }

        private async Task<bool> AddEntity(SasToken sasToken, List<FilesUploadData> fileSetToUpload, EntityRequest entityRequest)
        {
            entityRequest.EntityMedia = new List<EntityMedia>();
            entityRequest.EntityPhoto = new List<EntityPhoto>();
            entityRequest.EntityAttachment = new List<string>();
            entityRequest.EntityComment = new List<string>();

            foreach (var fileSet in fileSetToUpload)
            {
                foreach (var file in fileSet.Files)
                {
                    if (file.ContentType.Contains("image"))
                    {
                        var entityPhoto = new EntityPhoto
                        {
                            FileName = file.AzureFileName,
                            FileType = file.ContentType,
                            FileUrl = sasToken.StorageUri + sasToken.Container + "/" + file.AzureFileName,
                            PhotoDescription = file.Notes,
                            PhotoOriginal = file.FileName,
                            CreatedDate = file.CreatedDate
                        };
                        if (!string.IsNullOrEmpty(fileSet.Section))
                        {
                            entityPhoto.RelatedSection = fileSet.Section;
                        }
                        entityRequest.EntityPhoto.Add(entityPhoto);
                    }
                    else
                    {
                        var entityMedia = new EntityMedia
                        {
                            FileName = file.FileName,
                            FileType = file.ContentType,
                            FileUrl = sasToken.StorageUri + sasToken.Container + "/" + file.AzureFileName,
                            AttachmentDescription = file.Notes,
                            OriginalFileName = file.FileName,
                            CreatedDate = file.CreatedDate
                        };
                        if (!string.IsNullOrEmpty(fileSet.Section))
                        {
                            entityMedia.RelatedSection = fileSet.Section;
                        }
                        entityRequest.EntityMedia.Add(entityMedia);
                    }
                }
            }
            
            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.ADD_ENTITY_API, entityRequest);

            return response.IsSuccess;
        }

        private async Task<bool> AddCustomReportEntity(SasToken sasToken, List<Models.FileInfo> files, CustomReportEntityRequest entityRequest, string section)
        {
            entityRequest.CustomReportAttachmentDataModel = new List<CustomReportEntityMedia>();

            foreach (var file in files)
            {
                var entityMedia = new CustomReportEntityMedia
                {
                    FileName = file.FileName,
                    FileType = file.ContentType,
                    UploadUrl = sasToken.StorageUri + sasToken.Container + "/" + file.AzureFileName,
                    Description = file.Notes,
                    OriginalName = file.FileName,
                    CreatedDate = file.CreatedDate
                };
                if (!string.IsNullOrEmpty(section))
                {
                    entityMedia.RelatedSection = section;
                }
                entityRequest.CustomReportAttachmentDataModel.Add(entityMedia);
            }
            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.ADD_CUSTOM_REPORT_ENTITY_API, entityRequest);

            return response.IsSuccess;
        }

        private void UploadProgressChanged(object sender, long bytesUploaded)
        {
            try
            {
                if (bytesUploaded == 0)
                {
                    _lastUploadedByte = 0;
                }
                _bytesUploadedForFile = bytesUploaded - _lastUploadedByte;
                _totalBytesUploaded = _totalBytesUploaded + _bytesUploadedForFile;
                double percentage = (_totalBytesUploaded * 100) / _totalFileSize;
                double progress = percentage / 100;

                _lastUploadedByte = bytesUploaded;

                if (_progressBarHandler.Progress != progress)
                {
                    _progressBarHandler.SetProgress(progress);
                }
            }
            catch (Exception ex)
            {
            }
        }
    }

    public class FilesUploadData
    {
        public string Section { get; set; }
        public List<Models.FileInfo> Files { get; set; }
    }
}
