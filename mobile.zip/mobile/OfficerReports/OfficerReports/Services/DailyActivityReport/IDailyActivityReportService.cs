﻿using OfficerReports.Models.Base;
using OfficerReports.Models.DailyActivityReport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.DailyActivityReport
{
    public interface IDailyActivityReportService
    {
        public Task<ApiResponse> GetObservationTypes();

        public Task<ApiResponse> CreateDailyActivityReportRequest(CreateDailyActivityReportRequest request);

    }
}
