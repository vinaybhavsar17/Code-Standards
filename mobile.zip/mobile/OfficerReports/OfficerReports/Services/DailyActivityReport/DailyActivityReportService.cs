﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.DailyActivityReport;
using OfficerReports.Models.Site;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.DailyActivityReport
{
    public class DailyActivityReportService : ApiBaseService, IDailyActivityReportService
    {
        public async Task<ApiResponse> GetObservationTypes()
        {
            var apiData = (MasterData)GetCachedApiData<MasterDataDto>();
            var response = new ApiResponse
            {
                IsCached = true,
                Status = true,
                StatusCode = 200
            };

            if (apiData != null && apiData.ObservationData != null)
            {
                response.ProcessedData = apiData.ObservationData;
            }
            else
            {
                response.ProcessedData = new ObservationType
                {
                    Data = new List<ObservationTypeItem>()
                };
            }

            return response;
        }

        public async Task<ApiResponse> CreateDailyActivityReportRequest(CreateDailyActivityReportRequest request)
        {
            if(CanCallApi())
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_DAILY_ACTIVITY_REPORT_API, request);
            else
                return await CacheData<CreateDailyActivityReportRequest>(request);
        }

    }
}
