﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.TourTracker;
using OfficerReports.Services.Base;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.User;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.TourTracker
{
    public class TourTrackerService : ApiBaseService, ITourTrackerService
    {
        private IUserService _userService;

        public TourTrackerService(IUserService userService)
        {
            _userService = userService;
        }

        public async Task<ApiResponse> SubmitTourStopScan(TourStopScan request)
        {
            var locationService = App.ServiceProvider.GetRequiredService<ILocationService>();
            var userLocation = await locationService.GetCurrentLocation();
            if (userLocation == null)
                return new ApiResponse { IgnoreResponse = true };

            request.Latitude = userLocation.Latitude;
            request.Longitude = userLocation.Longitude;

            if (CanCallApi())
            {
                var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.SUBMIT_TOUR_STOP_SCAN_API, request);

                response.ProcessedData = response.GetApiData<TourStop>();
                return response;
            }
            else
            {
                return await CacheData<TourStopScan>(request);
            }
        }

        public async Task<ApiResponse> GetPreviousScans()
        {
            var siteIdParam = new QueryString
            {
                Key = "ClientSiteID",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };

            var user = _userService.GetLoggedInUserInfo();
            var userIdParam = new QueryString
            {
                Key = "UserID",
                Value = user.UserId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_TOUR_STOP_SCAN_API, siteIdParam, userIdParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = response.GetApiDataList<PreviousScan>();
            return response;
        }
    }
}
