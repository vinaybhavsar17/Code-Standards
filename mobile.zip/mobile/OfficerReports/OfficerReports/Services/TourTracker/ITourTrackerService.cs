﻿using OfficerReports.Models.Base;
using OfficerReports.Models.TourTracker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.TourTracker
{
    public interface ITourTrackerService
    {
        public Task<ApiResponse> SubmitTourStopScan(TourStopScan request);

        public Task<ApiResponse> GetPreviousScans();
    }
}
