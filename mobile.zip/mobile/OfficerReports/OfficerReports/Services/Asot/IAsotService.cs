﻿using OfficerReports.ApiClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Asot
{
    public interface IAsotService
    {
        public void Init(ISignalRClient signalRClient);

        public void Destroy();
    }
}
