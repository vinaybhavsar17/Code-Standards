﻿using Microsoft.Maui.Dispatching;
using OfficerReports.ApiClient;
using OfficerReports.Constants;
using OfficerReports.Helpers;
using OfficerReports.Interfaces;
using OfficerReports.ViewModels;
using OfficerReports.Models.Asot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Asot
{
    public class AsotService : IAsotService
    {
        private bool _isSubscribed;
        private IDispatcherTimer _locationUpdateTimer;
        private ISignalRClient _signalRClient;

        private readonly TimeSpan LocationUpdateInterval = TimeSpan.FromMinutes(5);

        public void Init(ISignalRClient signalRClient)
        {
            if (_isSubscribed)
                return;

            _signalRClient = signalRClient;

            MessagingCenter.Subscribe<Application, Location>(this, AppConstants.MessageLocationUpdate, (sender, location) =>
            {
                if (location == null)
                    return;

                AsotLogViewModel.AddLog("Sending location message via location change event");
                SendLocationMessage(location);

                ResetLocationUpdateTimer();
            });

            StartLocationUpdateTimer();

            _isSubscribed = true;
        }

        private void SendLocationMessage(Location location)
        {
            var mimicLocation = MimicDataManager.MimicLocation;
            if (mimicLocation != null)
                location = mimicLocation;

            if (location == null)
                return;

            var accurateWithin = GetAccurateWithin(SiteMenuViewModel.Site.SiteLatitude, SiteMenuViewModel.Site.SiteLongitude, location.Latitude, location.Longitude);
            var accuracy = GetAccuracy(accurateWithin);
            var asotRequest = new AsotRequest
            {
                ClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                Latitude = location.Latitude,
                Longitude = location.Longitude,
                AccuracyFeet = (int)(location.Accuracy * 3.281),
                BatteryPercentage = Battery.ChargeLevel * 100,
                IsBatteryCharging = Battery.State == BatteryState.Charging,
                LiveDateTime = DateTime.UtcNow,
                FirstName = MenuViewModel.LoggedInUser.FullName,
                LastName = MenuViewModel.LoggedInUser.FullName,
                UserName = MenuViewModel.LoggedInUser.UserName,
                UserId = MenuViewModel.LoggedInUser.UserId,
                Accuracy = accuracy,
                AccurateWithin = accurateWithin,
                IsSync = false,
                DeviceId = "string",
                Colour = "string"
            };

            if(NetworkUtility.IsInternetConnected)
                _signalRClient?.SendMessage(ApiConstants.SignalRMethod_AsotRequest, MenuViewModel.LoggedInUser.UserId, asotRequest);
            else
            {
                asotRequest.IsSync = true;

                var realm = RealmService.GetRealm();
                realm.Write(() =>
                {
                    realm.Add(asotRequest.ToRealmObject());
                });
            }
        }

        public void Destroy()
        {
            if(_signalRClient != null)
            {
                _signalRClient.Disconnect();
            }
            StopLocationUpdateTimer();
        }

        private async void LocationUpdateTimerLapsed(object sender, EventArgs e)
        {
            var location = await Geolocation.GetLastKnownLocationAsync();
            AsotLogViewModel.AddLog("Sending location message via timer");
            SendLocationMessage(location);
        }

        private void StartLocationUpdateTimer()
        {
            if (_locationUpdateTimer != null && _locationUpdateTimer.IsRunning)
                return;

            _locationUpdateTimer = Dispatcher.GetForCurrentThread().CreateTimer();
            _locationUpdateTimer.Interval = LocationUpdateInterval;
            _locationUpdateTimer.IsRepeating = true;
            _locationUpdateTimer.Tick += LocationUpdateTimerLapsed;
            _locationUpdateTimer.Start();
        }

        private void StopLocationUpdateTimer()
        {
            if (_locationUpdateTimer == null || !_locationUpdateTimer.IsRunning)
                return;

            _locationUpdateTimer.Stop();
            _locationUpdateTimer = null;
        }

        private void ResetLocationUpdateTimer()
        {
            StopLocationUpdateTimer();
            StartLocationUpdateTimer();
        }

        private string GetAccuracy(double accurateWithin)
        {
            var accuracy = "VeryLow";

            if (accurateWithin >= 0 && accurateWithin <= 300)
                accuracy = GeolocationAccuracy.High.ToString();
            else if (accurateWithin >= 301 && accurateWithin <= 1200)
                accuracy = GeolocationAccuracy.Medium.ToString();
            else if (accurateWithin >= 1201 && accurateWithin <= 5280)
                accuracy = GeolocationAccuracy.Low.ToString();

            return accuracy;
        }

        private double GetAccurateWithin(string siteLatitude, string siteLongitude, double latitude, double longitude)
        {
            double accurateWithin = 6000;

            try
            {
                var startLatitude = double.Parse(siteLatitude);
                var startLongitude = double.Parse(siteLongitude);

                var distance = Location.CalculateDistance(startLatitude, startLongitude, latitude, longitude, DistanceUnits.Kilometers);

                accurateWithin = distance * 3280.84;
            }
            catch (Exception)
            {
            }

            return accurateWithin;
        }
    }
}
