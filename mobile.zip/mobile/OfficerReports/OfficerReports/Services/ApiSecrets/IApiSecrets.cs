﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.ApiSecrets
{
    public enum Api
    {
        AppCenter,
        Firebase
    }

    public interface IApiSecrets
    {
        public string GetApiSecret(Api apiName, DevicePlatform platform);
    }
}
