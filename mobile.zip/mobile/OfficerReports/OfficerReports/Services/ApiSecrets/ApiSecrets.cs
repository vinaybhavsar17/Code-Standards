﻿using OfficerReports.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.ApiSecrets
{
    /**
     * The purpose of this class is to provide flexibility of returning API secret keys
     * Currently it returns hardcoded strings, but later on it can be used to implement Key vault to secure all
     * API keys and fetch them from one place.
     */
    public class ApiSecrets : IApiSecrets
    {
        private const string AppCenterAndroidApiKey = "c33cab83-7953-4b5b-b4ce-a3a86c048c5e";

        public string GetApiSecret(Api apiName, DevicePlatform platform)
        {
            string apiSecret = null;

            switch (apiName)
            {
                case Api.AppCenter:
                    apiSecret = platform == DevicePlatform.Android ?
                        AppCenterAndroidApiKey : throw new NotImplementedException("Add api key for iOS");
                    break;
                case Api.Firebase:
                    break;
                default:
                    break;
            }

            return apiSecret;
        }
    }
}
