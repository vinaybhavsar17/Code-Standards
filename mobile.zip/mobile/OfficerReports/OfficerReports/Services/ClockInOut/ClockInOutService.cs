﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.ClockInOut;
using OfficerReports.Services.Base;
using OfficerReports.Services.User;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.ClockInOut
{
    public class ClockInOutService : ApiBaseService, IClockInOutService
    {
        public async Task<ApiResponse> GetClockInOutDetails()
        {
            var siteIdParam = new QueryString
            {
                Key = "ClientSiteId",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };
            var timezoneParam = new QueryString
            {
                Key = "currentTimeZone",
                Value = TimeZoneInfo.Local.Id
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_CLOCK_IN_OUT_DETAILS_API, siteIdParam, timezoneParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = (List<ClockEntry>)response.GetApiDataList<ClockEntry>();
            return response;
        }

        public async Task<ApiResponse> GetClockTypes()
        {
            return await ApiClient.Get<ApiResponse>(ApiConstants.GET_CLOCK_TYPES_API);
        }

        public async Task<ApiResponse> IsUserWithinSiteArea(Location location)
        {
            var userLatitudeParam = new QueryString
            {
                Key = "userLatitude",
                Value = location.Latitude.ToString()
            };
            var userLongitudeParam = new QueryString
            {
                Key = "userLongitude",
                Value = location.Longitude.ToString()
            };
            var siteIdParam = new QueryString
            {
                Key = "siteId",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.CHECK_USER_TO_SITE_DISTANCE_API, userLatitudeParam, userLongitudeParam, siteIdParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            return response;
        }

        public async Task<ApiResponse> ClockIn(int clockTypeId, string comment, Location location)
        {
            var clockInRequest = new ClockInRequest
            {
                InClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                InHasLocationInfo = true,
                InLatitude = location.Latitude,
                InLongitude = location.Longitude,
                InAccuracyFeet = 0,
                InDistanceFromSiteFeet = 0,
                InDeviceType = App.IsAndroid ? "Android" : "iOS",
                InDeviceInfo = "0.0",
                InComment = comment,
                InClockTypeId = clockTypeId,
                CurrentTimeZone = TimeZoneInfo.Local.Id,
            };

            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CLOCK_IN_API, clockInRequest);

            return response;
        }

        public async Task<ApiResponse> ClockOut(int clockTypeId, int clockInOutId, string comment, Location location)
        {
            var clockOutRequest = new ClockOutRequest
            {
                ClockInOutId = clockInOutId,
                OutClientSiteId = SiteMenuViewModel.Site.ClientSiteId,
                OutHasLocationInfo = true,
                OutLatitude = location.Latitude,
                OutLongitude = location.Longitude,
                OutAccuracyFeet = 0,
                OutDistanceFromSiteFeet= 0,
                OutDeviceType = App.IsAndroid ? "Android" : "iOS",
                OutDeviceInfo = "0.0",
                OutComment = comment,
                OutClockTypeId = clockTypeId,
                CurrentTimeZone= TimeZoneInfo.Local.Id,
            };

            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CLOCK_OUT_API, clockOutRequest);

            return response;
        }
    }
}
