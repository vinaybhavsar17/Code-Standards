﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.ClockInOut
{
    public interface IClockInOutService
    {
        public Task<ApiResponse> GetClockTypes();

        public Task<ApiResponse> GetClockInOutDetails();

        public Task<ApiResponse> IsUserWithinSiteArea(Location location);

        public Task<ApiResponse> ClockIn(int clockTypeId, string comment, Location location);

        public Task<ApiResponse> ClockOut(int clockTypeId, int clockInOutId, string comment, Location location);
    }
}
