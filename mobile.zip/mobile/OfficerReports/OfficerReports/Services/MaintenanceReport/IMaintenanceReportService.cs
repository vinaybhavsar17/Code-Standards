﻿using OfficerReports.Models.Base;
using OfficerReports.Models.MaintenanceReport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.MaintenanceReport
{
    public interface IMaintenanceReportService
    {
        public Task<ApiResponse> GetMaintenanceTypes();
        public Task<ApiResponse> CreateMaintenanceReportRequest(CreateMaintenanceReportRequest request);
    }
}
