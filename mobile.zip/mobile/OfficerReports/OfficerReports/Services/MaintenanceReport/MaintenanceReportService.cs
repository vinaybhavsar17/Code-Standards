﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.MaintenanceReport;
using OfficerReports.Models.Site;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.MaintenanceReport
{
    public class MaintenanceReportService : ApiBaseService, IMaintenanceReportService
    {

        public async Task<ApiResponse> GetMaintenanceTypes()
        {
            var apiData = (MasterData)GetCachedApiData<MasterDataDto>();
            var response = new ApiResponse
            {
                IsCached = true,
                Status = true,
                StatusCode = 200
            };

            if (apiData != null && apiData.MaintenanceType != null)
            {
                response.ProcessedData = apiData.MaintenanceType;
            }
            else
            {
                response.ProcessedData = new MaintenanceType
                {
                    Data = new List<MaintenanceTypeItem>()
                };
            }

            return response;
        }

        public async Task<ApiResponse> CreateMaintenanceReportRequest(CreateMaintenanceReportRequest request)
        {
            if (CanCallApi())
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_MAINTENANCE_REPORT_API, request);
            else
                return await CacheData<CreateMaintenanceReportRequest>(request);
        }

    }
}
