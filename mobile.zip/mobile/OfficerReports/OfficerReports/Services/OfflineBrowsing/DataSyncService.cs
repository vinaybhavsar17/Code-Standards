﻿using System;
using Azure;
using Nito.AsyncEx;
using OfficerReports.ApiClient;
using OfficerReports.Constants;
using OfficerReports.Helpers;
using OfficerReports.ViewModels;
using OfficerReports.Models;
using OfficerReports.Models.Asot;
using OfficerReports.Models.Base;
using OfficerReports.Models.DailyActivityReport;
using OfficerReports.Models.FieldInspection;
using OfficerReports.Models.Incident;
using OfficerReports.Models.MaintenanceReport;
using OfficerReports.Models.ParkingViolation;
using OfficerReports.Models.PassOnLog;
using OfficerReports.Models.SiteCheckReport;
using OfficerReports.Models.TemperatureLog;
using OfficerReports.Models.TourTracker;
using OfficerReports.Models.TruckCheckInOut;
using OfficerReports.Models.Vacation;
using OfficerReports.Models.VisitorCheckInOut;
using OfficerReports.Services.Storage;
using Realms;
using FileInfo = OfficerReports.Models.FileInfo;
using OfficerReports.Models.Chat;
using Newtonsoft.Json;
using System.Text;

namespace OfficerReports.Services.OfflineBrowsing
{
    public class DataSyncService : IDataSyncService
    {
        private IRestApiClient _restApiClient;
        private IAzureStorageService _azureStorageService;
        private bool _isBusy;

        public DataSyncService(IRestApiClient restApiClient, IAzureStorageService azureStorageService)
        {
            _restApiClient = restApiClient;
            _azureStorageService = azureStorageService;

            Connectivity.ConnectivityChanged += InternetConnectivityChanged;
        }

        public void Init()
        {
            StartSyncThread();
        }

        private void InternetConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            StartSyncThread();
        }

        private async void StartSyncThread()
        {
            if (NetworkUtility.IsInternetConnected)
            {
                var realmThread = new AsyncContextThread();
                await realmThread.Factory.Run(() =>
                {
                    SyncAllData();
                });
            }
        }

        private async void SyncAllData()
        {
            if (_isBusy)
                return;

            _isBusy = true;

            var realm = RealmService.GetRealm();

            var schema = realm.Schema;
            foreach (var item in schema)
            {
                try
                {
                    switch (item.Name)
                    {
                        case nameof(CreateDailyActivityReportRequestDto):
                            await SyncDailyActivityReports(realm);
                            break;
                        case nameof(VisitorCheckInRequestDto):
                            await SyncVisitorCheckInReports(realm);
                            break;
                        case nameof(CreateVacationRequestDto):
                            await SyncVacationReports(realm);
                            break;
                        case nameof(CreateTruckCheckInReportRequestDto):
                            await SyncTruckCheckInReports(realm);
                            break;
                        case nameof(TourStopScanDto):
                            await SyncTourScanReports(realm);
                            break;
                        case nameof(CreateTemperatureLogRequestDto):
                            await SyncTemperatureLogReports(realm);
                            break;
                        case nameof(CreateSiteCheckReportDto):
                            await SyncSiteCheckReports(realm);
                            break;
                        case nameof(CreatePassOnLogReportRequestDto):
                            await SyncPassOnLogReports(realm);
                            break;
                        case nameof(CreateParkingViolationReportRequestDto):
                            await SyncParkingViolationReports(realm);
                            break;
                        case nameof(CreateMaintenanceReportRequestDto):
                            await SyncMaintenaqnceReports(realm);
                            break;
                        case nameof(CreateIncidentReportRequestDto):
                            await SyncIncidentReports(realm);
                            break;
                        case nameof(CreateFieldInspectionRequestDto):
                            await SyncFieldInspectionReports(realm);
                            break;
                        case nameof(AsotRequestDto):
                            await SyncAsotRecords(realm);
                            break;
                        case nameof(MessageDto):
                            await SyncChatMessageRecords(realm);
                            break;
                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {

                }
            }

            _isBusy = false;
            realm.Dispose();
        }

        private Task SyncDailyActivityReports(Realm realm)
        {
            return Sync<CreateDailyActivityReportRequestDto>(realm, ApiConstants.CREATE_DAILY_ACTIVITY_REPORT_API);
        }

        private Task SyncVisitorCheckInReports(Realm realm)
        {
            return Sync<VisitorCheckInRequestDto>(realm, ApiConstants.CREATE_VISITOR_CHECKIN_API);
        }

        private Task SyncVacationReports(Realm realm)
        {
            return Sync<CreateVacationRequestDto>(realm, ApiConstants.CREATE_VACATION_API);
        }

        private Task SyncTruckCheckInReports(Realm realm)
        {
            return Sync<CreateTruckCheckInReportRequestDto>(realm, ApiConstants.CREATE_TRUCK_CHECK_IN_API);
        }

        private Task SyncTourScanReports(Realm realm)
        {
            return Sync<TourStopScanDto>(realm, ApiConstants.SUBMIT_TOUR_STOP_SCAN_API);
        }

        private Task SyncTemperatureLogReports(Realm realm)
        {
            return Sync<CreateTemperatureLogRequestDto>(realm, ApiConstants.CREATE_TEMPERATURE_LOG_API);
        }

        private Task SyncSiteCheckReports(Realm realm)
        {
            return Sync<CreateSiteCheckReportDto>(realm, ApiConstants.CREATE_SITE_CHECK_REPORT_API);
        }

        private Task SyncPassOnLogReports(Realm realm)
        {
            return Sync<CreatePassOnLogReportRequestDto>(realm, ApiConstants.CREATE_PASS_ON_LOG_REPORT_API);
        }

        private Task SyncParkingViolationReports(Realm realm)
        {
            return Sync<CreateParkingViolationReportRequestDto>(realm, ApiConstants.CREATE_PARKING_VIOLATION_REPORT_API);
        }

        private Task SyncMaintenaqnceReports(Realm realm)
        {
            return Sync<CreateMaintenanceReportRequestDto>(realm, ApiConstants.CREATE_MAINTENANCE_REPORT_API);
        }

        private Task SyncIncidentReports(Realm realm)
        {
            return Sync<CreateIncidentReportRequestDto>(realm, ApiConstants.CREATE_INCIDENT_REPORT_API);
        }

        private Task SyncFieldInspectionReports(Realm realm)
        {
            return Sync<CreateFieldInspectionRequestDto>(realm, ApiConstants.CREATE_FIELD_INSPECTION_REPORT_API);
        }

        private async Task Sync<TData>(Realm realm, string url) where TData : RealmObject, IApiRequest
        {
            var records = realm.All<TData>();

            foreach (var record in records)
            {
                await CallApi(url, record.ToApiRequest(), async (response) =>
                {
                    var recordId = (Guid)(((dynamic)record).Id);

                    realm.Write(() =>
                    {
                        realm.Remove(record);
                    });

                    if (response.Data != null)
                    {
                        var reportId = (int)response.Data.reportId;
                        await UploadReportFiles(recordId, reportId, realm);
                    }
                });
            }
        }

        public async Task CallApi(string url, ApiRequest request, Func<ApiResponse, Task> onSuccess)
        {
            try
            {
                var result = await _restApiClient.Post<ApiRequest, ApiResponse>(url, request);

                if (result != null && (result.IsSuccess || result.StatusCode == 412) && !result.IgnoreResponse)
                {
                    await onSuccess(result);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private async Task UploadReportFiles(Guid recordId, int reportId, Realm realm)
        {
            var fileRecords = realm.All<FileInfoDto>().Where((r) => r.ReportId == recordId).ToList();

            if (fileRecords == null || fileRecords.Count == 0)
                return;

            var isSectioned = fileRecords.Where((fr) => fr.Section != string.Empty).Count() > 0;

            if (isSectioned)
            {
                var fileSets = fileRecords.GroupBy((r) => r.Section);
                await UploadSectionedFiles(fileSets, reportId);
            }
            else
            {
                await UploadFiles(fileRecords, reportId);
            }

            foreach (var record in fileRecords)
            {
                realm.Write(() =>
                {
                    realm.Remove(record);
                });
            }
        }

        private async Task UploadSectionedFiles(IEnumerable<IGrouping<string, FileInfoDto>> fileSets, int reportId)
        {
            var fileSetToUpload = new List<FilesUploadData>();
            FileInfoDto fileRecord = null;

            foreach (var fileSet in fileSets)
            {
                var files = new List<OfficerReports.Models.FileInfo>();

                foreach (var item in fileSet)
                {
                    fileRecord = item;
                    files.Add((FileInfo)item.ToApiRequest());
                }

                if (fileSet.Count() > 0)
                {
                    fileSetToUpload.Add(new FilesUploadData
                    {
                        Section = fileSet.Key,
                        Files = files
                    });
                }
            }

            if (fileSetToUpload.Count > 0)
            {
                var request = new EntityRequest
                {
                    EntityId = reportId,
                    EntityTypeId = fileRecord.EntityType
                };

                var uploaded = await _azureStorageService.UploadFiles(fileRecord.Purpose, fileSetToUpload, request, isBackground: true);
            }
        }

        private async Task UploadFiles(IEnumerable<FileInfoDto> fileRecords, int reportId)
        {
            var files = new List<OfficerReports.Models.FileInfo>();
            var fileRecord = fileRecords.FirstOrDefault();

            foreach (var item in fileRecords)
            {
                files.Add((FileInfo)item.ToApiRequest());
            }

            var request = new EntityRequest
            {
                EntityId = reportId,
                EntityTypeId = fileRecord.EntityType
            };

            var uploaded = await _azureStorageService.UploadFiles(fileRecord.Purpose, files, request, isBackground: true);
        }

        private async Task<List<FileInfo>> UploadChatFiles(Guid chatId, Realm realm)
        {
            var fileRecords = realm.All<FileInfoDto>().Where((r) => r.ReportId == chatId).ToList();

            if (fileRecords == null || fileRecords.Count == 0)
                return null;

            var files = new List<OfficerReports.Models.FileInfo>();
            var fileRecord = fileRecords.FirstOrDefault();
            foreach (var item in fileRecords)
            {
                files.Add((FileInfo)item.ToApiRequest());
            }

            var uploadedFiles = await _azureStorageService.UploadFiles(fileRecord.Purpose, files);

            if(uploadedFiles != null)
            {
                foreach (var record in fileRecords)
                {
                    realm.Write(() =>
                    {
                        realm.Remove(record);
                    });
                }
            }

            return uploadedFiles;
        }

        private async Task SyncAsotRecords(Realm realm)
        {
            var signalRClient = App.ServiceProvider.GetRequiredService<ISignalRClient>();

            int numOfRetry = 10;
            while (signalRClient.IsConnecting)
            {
                if (numOfRetry == 0)
                    break;

                await Task.Delay(3000);
                numOfRetry--;
            }

            if (!signalRClient.IsConnected)
                return;

            var records = realm.All<AsotRequestDto>();

            foreach (var record in records)
            {
                await signalRClient.SendMessage(ApiConstants.SignalRMethod_AsotRequest, MenuViewModel.LoggedInUser.UserId, record.ToApiRequest(), () =>
                {
                    realm.Write(() =>
                    {
                        realm.Remove(record);
                    });
                });
            }
        }

        private async Task SyncChatMessageRecords(Realm realm)
        {
            var signalRClient = App.ServiceProvider.GetRequiredService<ISignalRClient>();

            int numOfRetry = 10;
            while (signalRClient.IsConnecting)
            {
                if (numOfRetry == 0)
                    break;

                await Task.Delay(3000);
                numOfRetry--;
            }

            if (!signalRClient.IsConnected)
                return;

            var records = realm.All<MessageDto>();
            var recordsCount = records.Count();
            var i = 0;

            foreach (var record in records)
            {
                var copiedRecord = record.Copy();
                var uploadedFiles = await UploadChatFiles(record.Id, realm);
                if (uploadedFiles != null)
                {
                    StringBuilder messageBuilder = new StringBuilder();

                    foreach (var file in uploadedFiles)
                    {
                        var imgTagStr = $"<img src=\"{file.AzureFileUrl}\" />";
                        messageBuilder.Append(imgTagStr);
                    }

                    var messageContent = JsonConvert.DeserializeObject<MessageContent>(copiedRecord.MsgText);
                    messageContent.Message = messageBuilder.ToString();
                    copiedRecord.MsgText = JsonConvert.SerializeObject(messageContent);
                }

                await signalRClient.SendMessage(ApiConstants.SignalRMethod_SendMessage, copiedRecord.ToDynamic(), () =>
                {
                    realm.Write(() =>
                    {
                        realm.Remove(record);
                    });

                    if (i == recordsCount - 1)
                        MessagingCenter.Send<DataSyncService>(this, AppConstants.MessageOfflineUpdate);
                });

                i++;
            }
        }
    }
}

