﻿using System;
namespace OfficerReports.Services.OfflineBrowsing
{
	public interface IDataSyncService
	{
        public void Init();
    }
}

