﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.LocationService
{
    public interface ILocationService
    {
        public Task<Location> GetCurrentLocation(bool isBackground = true);

        public void StartLocationTracking();

        public void StopLocationTracking();
    }
}
