﻿using OfficerReports.ApiClient;
using OfficerReports.Services.ApiSecrets;
using OfficerReports.Services.Authentication;
using OfficerReports.Services.ClockInOut;
using OfficerReports.Services.DailyActivityReport;
using OfficerReports.Services.Dialog;
using OfficerReports.Services.FieldInspection;
using OfficerReports.Services.Incident;
using OfficerReports.Services.LocationService;
using OfficerReports.Services.MaintenanceReport;
using OfficerReports.Services.Navigation;
using OfficerReports.Services.ParkingViolation;
using OfficerReports.Services.PassOnLog;
using OfficerReports.Services.PolicyManual;
using OfficerReports.Services.PostOrder;
using OfficerReports.Services.Site;
using OfficerReports.Services.Storage;
using OfficerReports.Services.TourTracker;
using OfficerReports.Services.TruckCheckInOut;
using OfficerReports.Services.User;
using OfficerReports.Services.Vacation;
using OfficerReports.Services.TemperatureLog;
using OfficerReports.Services.Scheduler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Services.VisitorCheckInOut;
using OfficerReports.Services.SOS;
using OfficerReports.Services.Chat;
using OfficerReports.Services.SiteCheckReport;
using OfficerReports.Services.Asot;
using OfficerReports.Services.OfflineBrowsing;

namespace OfficerReports.Services
{
    public static class ServicesExtentions
    {
        public static MauiAppBuilder ConfigureServices(this MauiAppBuilder builder)
        {
            builder.Services.AddSingleton<IAuthenticationService, AuthenticationService>();
            builder.Services.AddSingleton<IForgotService, ForgotService>();
            builder.Services.AddSingleton<IRestApiClient, RestApiClient>();
            builder.Services.AddSingleton<IApiSecrets, ApiSecrets.ApiSecrets>();
            builder.Services.AddSingleton<INavigationService, NavigationService>();
            builder.Services.AddSingleton<IDialogService, DialogService>();
            builder.Services.AddSingleton<IVacationService, VacationService>();
            builder.Services.AddSingleton<IUserService, UserService>();
            builder.Services.AddSingleton<IPolicyManualService, PolicyManualService>();
            builder.Services.AddSingleton<IFileStorageService, FileStorageService>();
            builder.Services.AddSingleton<IClockInOutService, ClockInOutService>();
            builder.Services.AddSingleton<ISiteService, SiteService>();
            builder.Services.AddSingleton<ILocationService, LocationService.LocationService>();
            builder.Services.AddSingleton<IDailyActivityReportService, DailyActivityReportService>();
            builder.Services.AddSingleton<IFieldInspectionService, FieldInspectionService>();
            builder.Services.AddSingleton<IIncidentService, IncidentService>();
            builder.Services.AddSingleton<IAzureStorageService, AzureStorageService>();
            builder.Services.AddSingleton<IMaintenanceReportService, MaintenanceReportService>();
            builder.Services.AddSingleton<IParkingViolationService, ParkingViolationService>();
            builder.Services.AddSingleton<IPassOnLogService, PassOnLogService>();
            builder.Services.AddSingleton<ITourTrackerService, TourTrackerService>();
            builder.Services.AddSingleton<ITemperatureLogService, TemperatureLogService>();
            builder.Services.AddSingleton<ITruckCheckInOutService, TruckCheckInOutService>();
            builder.Services.AddSingleton<IPostOrderService, PostOrderService>();
            builder.Services.AddSingleton<IVisitorCheckInOutService, VisitorCheckInOutService>();
            builder.Services.AddSingleton<ISosService, SosService>();
            builder.Services.AddSingleton<IMessagingService, MessagingService>();
            builder.Services.AddSingleton<ISiteCheckReportService, SiteCheckReportService>();
            builder.Services.AddSingleton<ISignalRClient, SignalRClient>();
            builder.Services.AddSingleton<IAsotService, AsotService>();
            builder.Services.AddSingleton<ICustomReportService, CustomReportService>();
            builder.Services.AddSingleton<IDataSyncService, DataSyncService>();
            builder.Services.AddSingleton<ISchedulerService, SchedulerService>();

            return builder;
        }
    }
}
