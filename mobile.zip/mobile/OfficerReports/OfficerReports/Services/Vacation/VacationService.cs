﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.Vacation;
using OfficerReports.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Vacation
{
    public class VacationService : ApiBaseService, IVacationService
    {
        public async Task<ApiResponse> CreateVacationRequest(CreateVacationRequest request)
        {
            if (CanCallApi())
                return await ApiClient.Post<CreateVacationRequest, ApiResponse>(ApiConstants.CREATE_VACATION_API, request);
            else
                return await CacheData<CreateVacationRequest>(request);
        }

        public async Task<ApiResponse> GetVacationRequests()
        {
            var response = await ApiClient.Get<ApiResponse>(ApiConstants.GET_VACATION_REQUESTS_API);

            response.ProcessedData = (List<VacationRequest>)response.GetApiDataList<VacationRequest>();
            return response;
        }

        public async Task<ApiResponse> WithdrawVacationRequest(string vacationRequestId)
        {
            var vacationRequestIdParam = new QueryString
            {
                Key = "vacationRequestId",
                Value = vacationRequestId
            };
            var apiUrl = AddParametersToUrl(ApiConstants.WITHDRAW_VACATION_API, vacationRequestIdParam);
            return await ApiClient.Get<ApiResponse>(apiUrl);
        }
    }
}
