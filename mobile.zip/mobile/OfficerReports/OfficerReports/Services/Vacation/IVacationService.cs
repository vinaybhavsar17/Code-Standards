﻿using OfficerReports.Models.Base;
using OfficerReports.Models.Vacation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Vacation
{
    public interface IVacationService
    {
        public Task<ApiResponse> CreateVacationRequest(CreateVacationRequest request);

        public Task<ApiResponse> GetVacationRequests();

        public Task<ApiResponse> WithdrawVacationRequest(string vacationRequestId);
    }
}
