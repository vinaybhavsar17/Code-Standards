﻿using OfficerReports.Models.Base;
using OfficerReports.Models.PassOnLog;
using OfficerReports.Models.TruckCheckInOut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.TruckCheckInOut
{
    public interface ITruckCheckInOutService
    {
        public Task<ApiResponse> CreateTruckCheckInReportRequest(CreateTruckCheckInReportRequest request);
        public Task<ApiResponse> CreateTruckCheckOutReportRequest(CreateTruckCheckOutReportRequest request);
        public Task<ApiResponse> GetTruckCheckOutRecords();
    }
}
