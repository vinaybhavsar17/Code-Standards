﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.TruckCheckInOut;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.TruckCheckInOut
{
    public class TruckCheckInOutService : ApiBaseService, ITruckCheckInOutService
    {
        public async Task<ApiResponse> CreateTruckCheckInReportRequest(CreateTruckCheckInReportRequest request)
        {
            if (CanCallApi())
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_TRUCK_CHECK_IN_API, request);
            else
                return await CacheData<CreateTruckCheckInReportRequest>(request);
        }

        public async Task<ApiResponse> CreateTruckCheckOutReportRequest(CreateTruckCheckOutReportRequest request)
        {
            return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_TRUCK_CHECK_OUT_API, request);
        }
        

        public async Task<ApiResponse> GetTruckCheckOutRecords()
        {
            var siteIdParam = new QueryString
            {
                Key = "SiteID",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_TRUCK_CHECK_OUT_LOG_API, siteIdParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = response.GetApiDataList<TruckCheckOutRecord>();
            return response;
        }
    }
}
