﻿using OfficerReports.Models.Base;
using OfficerReports.Models.ParkingViolation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.ParkingViolation
{
    public interface IParkingViolationService
    {
        public Task<ApiResponse> GetParkingViolationType();
        public Task<ApiResponse> CreateParkingViolationReportRequest(CreateParkingViolationReportRequest request);
        public Task<ApiResponse> SearchParkingViolations(ParkingViolationSearchRequest request);
    }
}
