﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.ParkingViolation;
using OfficerReports.Models.Site;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.ParkingViolation
{
    public class ParkingViolationService : ApiBaseService, IParkingViolationService
    {
        public async Task<ApiResponse> GetParkingViolationType()
        {
            var apiData = (MasterData)GetCachedApiData<MasterDataDto>();
            var response = new ApiResponse
            {
                IsCached = true,
                Status = true,
                StatusCode = 200
            };

            if (apiData != null && apiData.ParkingViolationsType != null)
            {
                response.ProcessedData = apiData.ParkingViolationsType;
            }
            else
            {
                response.ProcessedData = new ParkingViolationType
                {
                    Data = new List<ParkingViolationTypeItem>()
                };
            }

            return response;
        }

        public async Task<ApiResponse> CreateParkingViolationReportRequest(CreateParkingViolationReportRequest request)
        {
            if (CanCallApi())
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_PARKING_VIOLATION_REPORT_API, request);
            else
                return await CacheData<CreateParkingViolationReportRequest>(request);
        }

        public async Task<ApiResponse> SearchParkingViolations(ParkingViolationSearchRequest request)
        {
            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.SEARCH_PARKING_VIOLATIONS_API, request);

            response.ProcessedData = response.GetApiData<ParkingViolationSearchResult>();
            return response;
        }
    }
}
