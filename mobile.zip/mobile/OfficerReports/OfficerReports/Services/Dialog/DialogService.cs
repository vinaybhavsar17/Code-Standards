﻿using CommunityToolkit.Maui.Views;
using OfficerReports.Controls;
using OfficerReports.Helpers;
using OfficerReports.Interfaces;
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Dialog
{
    public class DialogService : BaseService, IDialogService
    {
        public void HideLoading()
        {
            UserDialogs.Instance.HideLoading();
        }

        public void ShowLoading(string message = null)
        {
            if (string.IsNullOrWhiteSpace(message))
                message = AppResource.Loading_Text;

            UserDialogs.Instance.ShowLoading(message);
        }

        public void ShowMessage(string title, string message)
        {
            UserDialogs.Instance.Alert(message, title);
        }

        public async Task<bool> Confirm(string message, string title = null, string okText = null, string cancelText = null)
        {
            if (string.IsNullOrWhiteSpace(title))
                title = AppResource.Confirm;

            if (string.IsNullOrWhiteSpace(okText))
                okText = AppResource.Yes;

            if (string.IsNullOrWhiteSpace(cancelText))
                cancelText = AppResource.No;

            return await UserDialogs.Instance.ConfirmAsync(message, title, okText, cancelText);
        }

        public async Task<string> ShowOptions(string title, string cancel, string desctruction, params string[] buttons)
        {
            return await UserDialogs.Instance.ActionSheet(title, cancel, desctruction, buttons);
        }

        public IProgressBarHandler ShowProgress(string message = null)
        {
            if (string.IsNullOrWhiteSpace(message))
                message = AppResource.Uploading;

            return UserDialogs.Instance.ShowProgress(message);
        }

        public void HideProgress()
        {
            UserDialogs.Instance.HideProgress();
        }
    }
}
