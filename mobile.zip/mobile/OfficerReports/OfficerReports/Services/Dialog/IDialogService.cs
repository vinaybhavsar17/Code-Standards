﻿using OfficerReports.Controls;
using OfficerReports.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Dialog
{
    public interface IDialogService
    {
        public void ShowLoading(string message = null);

        public void HideLoading();

        public void ShowMessage(string title, string message);

        public Task<bool> Confirm(string message, string title = null, string okText = null, string cancelText = null);

        public Task<string> ShowOptions(string title, string cancel, string desctruction, params string[] buttons);

        public IProgressBarHandler ShowProgress(string message = null);

        public void HideProgress();
    }
}
