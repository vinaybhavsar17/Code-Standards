﻿using System;
using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.Scheduler;
using OfficerReports.Services.Base;

namespace OfficerReports.Services.Scheduler
{
	public class SchedulerService : ApiBaseService, ISchedulerService
    {
        public async Task<ApiResponse> GetScheduleByCustomer()
        {
            var timezoneParam = new QueryString
            {
                Key = "CurrentTimeZone",
                Value = TimeZoneInfo.Local.Id
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_SCHEDULE_BY_CUSTOMER, timezoneParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = response.GetApiDataList<Schedule>();
            return response;
        }

        public async Task<ApiResponse> GetScheduleByOfficer()
        {
            var request = new ScheduleRequest
            {
                CurrentTimeZone = TimeZoneInfo.Local.Id,
                OfficersIdArray = new int[1] { ViewModels.MenuViewModel.LoggedInUser.UserId }
            };

            var response = await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.GET_SCHEDULE_BY_OFFICER, request);
            response.ProcessedData = response.GetApiDataList<Schedule>();

            return response;
        }
    }
}

