﻿using System;
using OfficerReports.Models.Base;

namespace OfficerReports.Services.Scheduler
{
	public interface ISchedulerService
	{
        public Task<ApiResponse> GetScheduleByOfficer();

        public Task<ApiResponse> GetScheduleByCustomer();
    }
}

