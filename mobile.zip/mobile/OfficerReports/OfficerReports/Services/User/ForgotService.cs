﻿using OfficerReports.Constants;
using OfficerReports.Models.Base;
using OfficerReports.Models.User;
using OfficerReports.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.User
{
    public class ForgotService : ApiBaseService, IForgotService
    {
        public async Task<ApiResponse> ForgotPassword(string email)
        {
            var forgotPasswordRequest = new ForgotRequest
            {
                BaseUrl = ApiConstants.BASE_URL.Remove(ApiConstants.BASE_URL.Length - 5),
                UserName = email
                
            };
           
            var response = await ApiClient.Post<ForgotRequest, ApiResponse>(ApiConstants.FORGOT_PASSWORD_API, forgotPasswordRequest);
            return response;
        }

        public async Task<ApiResponse> ForgotUsername(string email)
        {
            var forgotUsernameRequest = new ForgotRequest
            {
                Email = email,
                BaseUrl = ApiConstants.BASE_URL.Remove(ApiConstants.BASE_URL.Length - 1)
            };
            var response = await ApiClient.Post<ForgotRequest, ApiResponse>(ApiConstants.FORGOT_USERNAME_API, forgotUsernameRequest);
            return response;
        }
    }
}
