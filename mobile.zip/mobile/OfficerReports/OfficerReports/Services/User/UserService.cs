﻿using Newtonsoft.Json;
using OfficerReports.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.User
{
    public class UserService : BaseService, IUserService
    {
        private static readonly string UserKey = "app.auth.user";

        public Models.Authentication.User GetLoggedInUserInfo()
        {
            var json = Preferences.Get(UserKey, String.Empty);
            var user = (Models.Authentication.User)JsonConvert.DeserializeObject(json, typeof(Models.Authentication.User));

            return user;
        }

        public void SaveLoggedInUserInfo(Models.Authentication.User user)
        {
            var json = JsonConvert.SerializeObject(user);
            Preferences.Set(UserKey, json);
        }

        public void RemoveLoggedInUserInfo()
        {
            Preferences.Remove(UserKey);
        }
    }
}
