﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.User
{
    public interface IUserService
    {
        public void SaveLoggedInUserInfo(Models.Authentication.User user);

        public Models.Authentication.User GetLoggedInUserInfo();

        public void RemoveLoggedInUserInfo();
    }
}
