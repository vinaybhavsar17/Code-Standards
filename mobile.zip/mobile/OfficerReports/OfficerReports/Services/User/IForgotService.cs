﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.User
{
    public interface IForgotService
    {
        public Task<ApiResponse> ForgotPassword(string email);
        public Task<ApiResponse> ForgotUsername(string email);
    }
}
