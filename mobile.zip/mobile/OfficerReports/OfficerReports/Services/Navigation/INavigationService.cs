﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Maui.Views;
using OfficerReports.Views.Base;

namespace OfficerReports.Services.Navigation
{
    public interface INavigationService
    {
        public Task PushAsync(Page page, bool animated = true);

        public Task PushModalAsync(Page page, bool animated = true);

        public Task PopModalAsync(bool animated = true);

        public Task PopAsync(bool animated = true);

        public void PushToRoot(Page page);

        public Task PopToRootAsync(bool animated = true);

        public void ShowPopup(Popup popup);

        public Task<object?> ShowPopupAsync(Popup popup);

        public Task ReplacePage(Page page, bool animated = true);
    }
}
