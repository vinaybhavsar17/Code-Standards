﻿using CommunityToolkit.Maui.Views;
using OfficerReports.Services.Base;
using OfficerReports.Views.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Navigation
{
    public class NavigationService : BaseService, INavigationService
    {
        public async Task PopAsync(bool animated = true)
        {
            var currentPage = Application.Current.MainPage;

            if (currentPage is NavigationPage)
                await((NavigationPage)currentPage).PopAsync(animated);
        }

        public async Task PopToRootAsync(bool animated = true)
        {
            var currentPage = Application.Current.MainPage;

            if (currentPage is NavigationPage)
                await((NavigationPage)currentPage).PopToRootAsync(animated);
        }

        /**
         * This is a work around we have applied because "Application.Current.MainPage = new NavigationPage(page);" this code is giving 
         * some issue in MAUI. It works in Xamarin forms but not sure why it's not working in MAUI.
         * So in future, when MAUI is officially released, we can try this code, and if it works, we can simply have
         * this one line of code rather than this workaround.
         */
        public async void PushToRoot(Page page)
        {
            try
            {
                var currentPage = Application.Current.MainPage;

                if (currentPage is NavigationPage)
                {
                    var navigation = ((NavigationPage)currentPage).Navigation;
                    var navStack = navigation.NavigationStack.ToList();
                    await navigation.PushAsync(page, true);

                    foreach (var navPage in navStack)
                    {
                        navigation.RemovePage(navPage);
                    }
                }
                else
                {
                    Application.Current.MainPage = page;
                }
            }
            catch (Exception)
            {
            }
        }

        public async Task PushAsync(Page page, bool animated = true)
        {
            var currentPage = Application.Current.MainPage;

            if (currentPage is NavigationPage np)
            {
                if(np.Navigation.ModalStack.Count > 0)
                {
                    var modalNp = np.Navigation.ModalStack.LastOrDefault();
                    if(modalNp != null && modalNp is NavigationPage mnp)
                    {
                        await mnp.PushAsync(page, animated);
                    }
                }
                else
                {
                    await np.PushAsync(page, animated);
                }
            }
            else
                Application.Current.MainPage = page;
        }

        public void ShowPopup(Popup popup)
        {
            var currentPage = Application.Current.MainPage;

            if (currentPage is NavigationPage)
                ((NavigationPage)currentPage).ShowPopup(popup);
        }

        public async Task<object?> ShowPopupAsync(Popup popup)
        {
            object result = null;

            var currentPage = Application.Current.MainPage;

            if (currentPage is NavigationPage)
                result = await ((NavigationPage)currentPage).ShowPopupAsync(popup);

            return result;
        }

        public async Task PushModalAsync(Page page, bool animated = true)
        {
            var currentPage = Application.Current.MainPage;

            if (currentPage is NavigationPage np)
            {
                if (np.Navigation.ModalStack.Count > 0)
                {
                    var modalNp = np.Navigation.ModalStack.LastOrDefault();
                    if (modalNp != null && modalNp is NavigationPage mnp)
                    {
                        await mnp.Navigation.PushModalAsync(page, animated);
                    }
                    else
                    {
                        await np.Navigation.PushModalAsync(page, animated);
                    }
                }
                else
                {
                    await np.Navigation.PushModalAsync(page, animated);
                }
            }
        }

        public async Task PopModalAsync(bool animated = true)
        {
            var currentPage = Application.Current.MainPage;

            if (currentPage is NavigationPage cp)
            {
                if(cp.Navigation.ModalStack.Count > 0)
                    await cp.Navigation.PopModalAsync(animated);
            }
        }

        public async Task ReplacePage(Page page, bool animated = true)
        {
            var currentPage = Application.Current.MainPage;

            if (currentPage is NavigationPage np)
            {
                var topPage = np.CurrentPage;
                await np.PushAsync(page, animated);

                np.Navigation.RemovePage(topPage);
            }
            else
            {
                Application.Current.MainPage = page;
            }
        }
    }
}
