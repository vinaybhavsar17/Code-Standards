﻿using OfficerReports.Constants;
using OfficerReports.Models.Base;
using OfficerReports.Models.PolicyManual;
using OfficerReports.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.PolicyManual
{
    public class PolicyManualService : ApiBaseService, IPolicyManualService
    {
        public async Task<ApiResponse> GetAllPolicyManuals()
        {
            var response = await ApiClient.Get<ApiResponse>(ApiConstants.GET_POLICY_MANUAL_API);

            var policyManualList = (List<Models.PolicyManual.PolicyManual>)response.GetApiDataList<Models.PolicyManual.PolicyManual>();
            response.ProcessedData = ConvertToHeirarchicalData(policyManualList);

            return response;
        }

        private List<PolicyManualGroup> ConvertToHeirarchicalData(List<Models.PolicyManual.PolicyManual> data)
        {
            var hierarchicalDataDictionary = new Dictionary<string, PolicyManualGroup>();
            //List<PolicyManualGroup> hierarchicalDataList = new List<PolicyManualGroup>();
            PolicyManualGroup hierarchicalData = default(PolicyManualGroup);

            foreach (var item in data)
            {
                if (hierarchicalData == null || !hierarchicalDataDictionary.ContainsKey(item.PolicyManualMainCategory))
                {
                    hierarchicalData = new PolicyManualGroup();

                    hierarchicalData.CategoryId = item.PolicyManualMainCategoryId;
                    hierarchicalData.CategoryName = item.PolicyManualMainCategory;

                    hierarchicalDataDictionary.Add(item.PolicyManualMainCategory, hierarchicalData);
                }

                hierarchicalDataDictionary[item.PolicyManualMainCategory].Add(item);
            }

            return hierarchicalDataDictionary.Values.ToList();
        }
    }
}
