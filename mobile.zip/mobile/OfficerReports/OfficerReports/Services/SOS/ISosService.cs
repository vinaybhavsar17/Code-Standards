﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Models.Base;
using OfficerReports.Models.SOS;

namespace OfficerReports.Services.SOS
{
    public interface ISosService
    {
        public Task<ApiResponse> SendSOSAlert(SosAlertRequest request);
    }
}
