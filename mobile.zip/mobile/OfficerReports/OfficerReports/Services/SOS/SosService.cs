﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Core;
using OfficerReports.Constants;
using OfficerReports.Models.Base;
using OfficerReports.Models.SOS;
using OfficerReports.Services.Base;

namespace OfficerReports.Services.SOS
{
    public class SosService : ApiBaseService, ISosService
    {
        public async Task<ApiResponse> SendSOSAlert(SosAlertRequest request)
        {
            return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_SOS_ALERT_API, request);
        }
    }
}
