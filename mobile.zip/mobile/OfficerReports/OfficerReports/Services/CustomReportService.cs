﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services
{
    public class CustomReportService : ApiBaseService, ICustomReportService
    {
        public async Task<ApiResponse> CreateCustomReportRequest(CustomReportRequest request)
        {
            if (CanCallApi())
                return await ApiClient.Post<CustomReportRequest, ApiResponse>(ApiConstants.CREATE_CUSTOM_REPORT_API, request);
            else
                return await CacheData<CustomReportRequest>(request);
        }
    }
}
