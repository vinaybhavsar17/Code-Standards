﻿using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.Vacation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services
{
    public interface ICustomReportService
    {
        public Task<ApiResponse> CreateCustomReportRequest(CustomReportRequest request);
    }
}
