﻿using Newtonsoft.Json;
using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.Incident;
using OfficerReports.Models.Site;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Incident
{
    public class IncidentService : ApiBaseService, IIncidentService
    {
        public async Task<ApiResponse> GetIncidentTypes()
        {
            var apiData = (MasterData)GetCachedApiData<MasterDataDto>();
            var response = new ApiResponse
            {
                IsCached = true,
                Status = true,
                StatusCode = 200
            };

            if (apiData != null && apiData.IncidentData != null)
            {
                response.ProcessedData = apiData.IncidentData;
            }
            else
            {
                response.ProcessedData = new IncidentType
                {
                    Data = new List<IncidentTypeItem>()
                };
            }

            return response;
        }

        public async Task<ApiResponse> CreateIncidentReportRequest(CreateIncidentReportRequest request)
        {
            if (CanCallApi())
            {
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_INCIDENT_REPORT_API, request);
            }
            else
            {
                return await CacheData<CreateIncidentReportRequest>(request);
            }
        }

        public async Task<ApiResponse> GetIncidentChecklist()
        {
            var clientSiteIdParam = new QueryString
            {
                Key = "ClientSiteId",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };
            var apiUrl = AddParametersToUrl(ApiConstants.GET_INCIDENT_CHECKLIST_API, clientSiteIdParam);

            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            var incidentChecklist = (List<IncidentCheck>)response.GetApiDataList<IncidentCheck>();
            response.ProcessedData = ConvertToHeirarchicalData(incidentChecklist);

            return response;
        }

        private object ConvertToHeirarchicalData(List<IncidentCheck> data)
        {
            var incidentChecklist = new List<IncidentChecklistGroup>();

            if(data != null)
            {
                foreach (var item in data)
                {
                    var incidentCheckSteps = JsonConvert.DeserializeObject<List<string>>(item.StepJson);
                    var incidentChecklistGroup = new IncidentChecklistGroup(incidentCheckSteps);
                    incidentChecklistGroup.IncidentChecklistId = item.IncidentChecklistId;
                    incidentChecklistGroup.IncidentType = item.IncidentType;

                    incidentChecklist.Add(incidentChecklistGroup);
                }
            }

            return incidentChecklist;
        }
    }
}
