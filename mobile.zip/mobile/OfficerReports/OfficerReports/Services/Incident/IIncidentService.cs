﻿using OfficerReports.Models.Base;
using OfficerReports.Models.Incident;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Incident
{
    public interface IIncidentService
    {
        public Task<ApiResponse> GetIncidentTypes();

        public Task<ApiResponse> CreateIncidentReportRequest(CreateIncidentReportRequest request);

        public Task<ApiResponse> GetIncidentChecklist();
    }
}
