﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.Chat;
using OfficerReports.Models.Site;
using OfficerReports.Services.Base;
using OfficerReports.Services.LocationService;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Site
{
    public class SiteService : ApiBaseService, ISiteService
    {
        public async Task<ApiResponse> GetAllSites()
        {
            var isEnabledParam = new QueryString
            {
                Key = "isEnabled",
                Value = "true"
            };

            var isDeletedParam = new QueryString
            {
                Key = "isDeleted",
                Value = "false"
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_All_SITES_API, isEnabledParam, isDeletedParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = (List<ClientSite>)response.GetApiDataList<ClientSite>();
            return response;
        }

        public async Task<ApiResponse> GetSitesInRange()
        {
            var locationService = App.ServiceProvider.GetRequiredService<ILocationService>();
            var userLocation = await locationService.GetCurrentLocation();

            if (userLocation == null)
                return new ApiResponse { IgnoreResponse = true };

            var latitudeParam = new QueryString
            {
                Key = "userLatitude",
                Value = userLocation.Latitude.ToString()
            };

            var longitudeParam = new QueryString
            {
                Key = "userLongitude",
                Value = userLocation.Longitude.ToString()
            };

            var isMobileParam = new QueryString
            {
                Key = "isMobile",
                Value = "true"
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_SITES_IN_RANGE_API, latitudeParam, longitudeParam, isMobileParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = (List<ClientSite>)response.GetApiDataList<ClientSite>();
            return response;
        }

        public async Task<ApiResponse> GetSiteMenu()
        {
            var siteIdParam = new QueryString
            {
                Key = "clientSiteId",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_OFFICER_PORTAL_MENU_LIST, siteIdParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = response.GetApiDataList<SiteMenuItem>();
            return response;
        }

        public async Task<ApiResponse> GetSiteMenuItemDetails(int itemId)
        {
            var itemIdParam = new QueryString
            {
                Key = "customReportId",
                Value = itemId.ToString()
            };
            var apiUrl = AddParametersToUrl(ApiConstants.GET_CUSTOM_REPORT_JSON, itemIdParam);

            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = response.GetApiData<SiteMenuItemDetails>();

            return response;
        }

        public async Task<ApiResponse> GetUnreadNotificationsCount()
        {
            var officerIdParam = new QueryString
            {
                Key = "officerId",
                Value = MenuViewModel.LoggedInUser.UserId.ToString()
            };

            var siteIdParam = new QueryString
            {
                Key = "clientSiteId",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_NEW_MESSAGES_COUNT_API, officerIdParam, siteIdParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = response.GetApiData<UnreadMessageCount>();
            return response;
        }

        public async Task<ApiResponse> GetAllReportsMasterData(int siteId)
        {
            var siteIdParam = new QueryString
            {
                Key = "clientSiteId",
                Value = siteId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_All_MASTER_DATA_API, siteIdParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            var masterData = (MasterData)response.GetApiData<MasterData>();
            response.ProcessedData = SortMasterData(masterData);

            if (response.Data != null)
                await CacheApiData<MasterData>(response.ProcessedData as MasterData);

            return response;
        }

        private MasterData SortMasterData(MasterData masterData)
        {
            var equipmentType = masterData.EquipmentType.Data.FirstOrDefault();
            if(equipmentType != null && equipmentType.SortOrder == 0)
            {
                masterData.EquipmentType.Data = masterData.EquipmentType.Data.OrderBy(t => t.TypeDataName).ToList();
            }

            var incidentType = masterData.IncidentData.Data.FirstOrDefault();
            if (incidentType != null && incidentType.SortOrder == 0)
            {
                masterData.IncidentData.Data = masterData.IncidentData.Data.OrderBy(t => t.TypeDataName).ToList();
            }

            var observationType = masterData.ObservationData.Data.FirstOrDefault();
            if (observationType != null && observationType.SortOrder == 0)
            {
                masterData.ObservationData.Data = masterData.ObservationData.Data.OrderBy(t => t.TypeDataName).ToList();
            }

            var maintenanceType = masterData.MaintenanceType.Data.FirstOrDefault();
            if (maintenanceType != null && maintenanceType.SortOrder == 0)
            {
                masterData.MaintenanceType.Data = masterData.MaintenanceType.Data.OrderBy(t => t.TypeDataName).ToList();
            }

            var parkingViolationsType = masterData.ParkingViolationsType.Data.FirstOrDefault();
            if (parkingViolationsType != null && parkingViolationsType.SortOrder == 0)
            {
                masterData.ParkingViolationsType.Data = masterData.ParkingViolationsType.Data.OrderBy(t => t.TypeDataName).ToList();
            }

            var visitorIdType = masterData.VisitorIdType.Data.FirstOrDefault();
            if (visitorIdType != null && visitorIdType.SortOrder == 0)
            {
                masterData.VisitorIdType.Data = masterData.VisitorIdType.Data.OrderBy(t => t.TypeDataName).ToList();
            }

            return masterData;
        }
    }
}
