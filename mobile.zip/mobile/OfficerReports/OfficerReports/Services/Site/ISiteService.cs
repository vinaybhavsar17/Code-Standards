﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.Site
{
    public interface ISiteService
    {
        public Task<ApiResponse> GetAllSites();

        public Task<ApiResponse> GetSitesInRange();

        public Task<ApiResponse> GetSiteMenu();

        public Task<ApiResponse> GetSiteMenuItemDetails(int itemId);

        public Task<ApiResponse> GetUnreadNotificationsCount();

        public Task<ApiResponse> GetAllReportsMasterData(int siteId);
    }
}
