﻿using OfficerReports.Models;
using OfficerReports.Constants;
using OfficerReports.Models.Base;
using OfficerReports.Services.Base;
using OfficerReports.Services.Vacation;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Models.VisitorCheckInOut;
using OfficerReports.Models.Site;

namespace OfficerReports.Services.VisitorCheckInOut
{
    public class VisitorCheckInOutService : ApiBaseService, IVisitorCheckInOutService
    {
        public async Task<ApiResponse> GetVisitorCheckOutRecords()
        {
            var siteIdParam = new QueryString
            {
                Key = "SiteID",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_VISITOR_CHECK_OUT_API, siteIdParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = response.GetApiDataList<VisitorCheckOutRecord>();
            return response;
        }

        public async Task<ApiResponse> UpdateVisitorCheckOutRecord(CreateVisitorCheckInOutRequest request)
        {
            return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.UPDATE_VISITOR_CHECK_OUT_LOG_API, request);
        }

        public async Task<ApiResponse> GetVisitorIdTypes()
        {
            var apiData = (MasterData)GetCachedApiData<MasterDataDto>();
            var response = new ApiResponse
            {
                IsCached = true,
                Status = true,
                StatusCode = 200
            };

            if (apiData != null && apiData.VisitorIdType != null)
            {
                response.ProcessedData = apiData.VisitorIdType;
            }
            else
            {
                response.ProcessedData = new VisitorIdType
                {
                    Data = new List<VisitorTypeItem>()
                };
            }

            return response;
        }

        public async Task<ApiResponse> CreateVisitorCheckInRequest(VisitorCheckInRequest request)
        {
            if (CanCallApi())
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_VISITOR_CHECKIN_API, request);
            else
                return await CacheData<VisitorCheckInRequest>(request);
        }
    }
}
