﻿using OfficerReports.Models.Base;
using OfficerReports.Models.VisitorCheckInOut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.VisitorCheckInOut
{
    public interface IVisitorCheckInOutService
    {
        public Task<ApiResponse> GetVisitorIdTypes();
        public Task<ApiResponse> CreateVisitorCheckInRequest(VisitorCheckInRequest request);
        public Task<ApiResponse> GetVisitorCheckOutRecords();
        public Task<ApiResponse> UpdateVisitorCheckOutRecord(CreateVisitorCheckInOutRequest request);
    }
}
