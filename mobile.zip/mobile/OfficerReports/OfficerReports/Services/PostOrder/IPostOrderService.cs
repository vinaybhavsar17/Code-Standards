﻿using OfficerReports.Models.Base;
using OfficerReports.Models.PostOrder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.PostOrder
{
   public interface IPostOrderService
    {
        public Task<ApiResponse> GetPostOrder(); 

    }
}
