﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.PostOrder;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.PostOrder
{
    public class PostOrderService : ApiBaseService, IPostOrderService
    {

        public async Task<ApiResponse> GetPostOrder()
        {
            var clientSiteIDParam = new QueryString
            {
                Key = "clientSiteId",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_POST_ORDER_API, clientSiteIDParam);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            var result = response.GetApiDataList<PostOrderDetail>();
            response.ProcessedData = result;
            return response;
        }

      
    }
}
