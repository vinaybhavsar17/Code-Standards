﻿using OfficerReports.Models.Base;
using OfficerReports.Models.PassOnLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.PassOnLog
{
    public interface IPassOnLogService
    {
        public Task<ApiResponse> CreatePassOnLogReport(CreatePassOnLogReportRequest request);
        public Task<ApiResponse> GetPassOnLogEntry();
        public Task<ApiResponse> GetPassOnLogEntryDetails(string passOnLogId);
        public Task<ApiResponse> ChangeMarkAsReadStatus(ChangeReadStatusRequest request);

    }
}
