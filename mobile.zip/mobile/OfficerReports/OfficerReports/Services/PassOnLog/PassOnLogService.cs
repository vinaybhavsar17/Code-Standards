﻿using OfficerReports.Constants;
using OfficerReports.Models;
using OfficerReports.Models.Base;
using OfficerReports.Models.PassOnLog;
using OfficerReports.Services.Base;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Services.PassOnLog
{
    public class PassOnLogService : ApiBaseService, IPassOnLogService
    {
        public async Task<ApiResponse> CreatePassOnLogReport(CreatePassOnLogReportRequest request)
        {
            if (CanCallApi())
                return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CREATE_PASS_ON_LOG_REPORT_API, request);
            else
                return await CacheData<CreatePassOnLogReportRequest>(request);
        }

        public async Task<ApiResponse> ChangeMarkAsReadStatus(ChangeReadStatusRequest request)
        {
            return await ApiClient.Post<ApiRequest, ApiResponse>(ApiConstants.CHANGE_READ_STATUS_PASS_ON_LOG_VIEW, request);
        }

        public async Task<ApiResponse> GetPassOnLogEntry()
        {
            var clientSiteId = new QueryString
            {
                Key = "ClientSiteId",
                Value = SiteMenuViewModel.Site.ClientSiteId.ToString()
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_PASS_ON_LOG_ENTRY_API, clientSiteId);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            response.ProcessedData = response.GetApiDataList<PassOnLogRecord>();
            return response;
        }

        public async Task<ApiResponse> GetPassOnLogEntryDetails(string passOnLogId)
        {
            var polId = new QueryString
            {
                Key = "passOnLogId",
                Value = passOnLogId
            };

            var apiUrl = AddParametersToUrl(ApiConstants.GET_PASS_ON_LOG_ENTRY_DETAIL_API, polId);
            var response = await ApiClient.Get<ApiResponse>(apiUrl);

            var data = (PassOnLogDetailRecord)response.GetApiData<PassOnLogDetailRecord>();
            data.ProcessedEntities = ExtractFiles(data.Entities);

            response.ProcessedData = data;
            return response;
        }

        private List<EntityFile> ExtractFiles(List<Entity> data)
        {

            var mediaObjectList = new List<EntityFile>();
   
            foreach (var objectItem in data)
            {

                foreach (var itemMedia in objectItem.ArrayEntityMedia)
                {

                    if (itemMedia.UploadUrl != null && itemMedia.FileName != null)
                    {
                        mediaObjectList.Add(itemMedia);
                    }
                }

                foreach (var itemPhoto in objectItem.ArrayEntityPhoto) {
                    
                     if (itemPhoto.UploadUrl != null && itemPhoto.FileName != null) {

                        mediaObjectList.Add(itemPhoto);
                    }
                   
                }
            }
            return mediaObjectList;
        }

    }
}
