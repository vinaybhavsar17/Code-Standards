﻿using Entry = OfficerReports.Controls.Entry;

namespace OfficerReports.Behaviors
{
    public abstract class EntryValidationBehavior : Behavior<Entry>
    {
        protected Entry Entry;
        protected bool Interacted; //This bool is used to check if user has interacted with the field. If yes, then we will validate and display error.

        public static readonly BindableProperty IsValidProperty = BindableProperty.Create(nameof(IsValid), typeof(bool), typeof(EntryValidationBehavior), false, defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty ValidationMessageProperty = BindableProperty.Create(nameof(ValidationMessage), typeof(string), typeof(EntryValidationBehavior), string.Empty, defaultBindingMode: BindingMode.OneWay);

        public bool IsValid
        {
            get => (bool)GetValue(IsValidProperty);
            set => SetValue(IsValidProperty, value);
        }

        public string ValidationMessage
        {
            get => (string)GetValue(ValidationMessageProperty);
            set => SetValue(ValidationMessageProperty, value);
        }

        protected abstract void Validate(object sender);

        protected override void OnAttachedTo(Entry bindable)
        {
            Entry = bindable;
            bindable.GetEntryField().Unfocused += HandleFocusChanged;
            bindable.GetEntryField().TextChanged += HandleTextChanged;
        }

        private void HandleTextChanged(object sender, TextChangedEventArgs e)
        {
            if(Entry.EntryField.IsReadOnly && !string.IsNullOrEmpty(Entry.Text))
                Interacted = true;

            Validate(sender);
        }

        private void HandleFocusChanged(object sender, FocusEventArgs e)
        {
            Interacted = true;
            Validate(sender);
        }

        protected override void OnDetachingFrom(Entry bindable)
        {
            bindable.GetEntryField().Unfocused -= HandleFocusChanged;
            bindable.GetEntryField().TextChanged -= HandleTextChanged;
        }

        public bool ForceValidate()
        {
            Interacted = true;
            Validate(Entry.GetEntryField());

            return IsValid;
        }

        public void Reset()
        {
            Interacted = false;
            Validate(Entry.GetEntryField());
        }
    }
}
