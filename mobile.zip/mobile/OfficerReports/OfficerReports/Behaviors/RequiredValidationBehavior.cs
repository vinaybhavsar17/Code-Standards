﻿using OfficerReports.Resources.Strings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Behaviors
{
    public class RequiredValidationBehavior : EntryValidationBehavior
    {
        protected override void Validate(object sender)
        {
            var entryField = (InputView)sender;
            IsValid = !string.IsNullOrWhiteSpace(entryField.Text);

            if (!IsValid && Interacted)
            {
                var validationMessage = ValidationMessage != string.Empty ? ValidationMessage : throw new ArgumentNullException("ValidationMessage is required");
                if (validationMessage.Contains("{0}"))
                {
                    var fieldName = AppResource.Value;
                    fieldName = !string.IsNullOrWhiteSpace(Entry.Title) ?
                        Entry.Title :
                        !string.IsNullOrWhiteSpace(Entry.Placeholder) ? Entry.Placeholder : fieldName;

                    validationMessage = String.Format(validationMessage, fieldName);
                }

                Entry.Errors[nameof(RequiredValidationBehavior)] = validationMessage;
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }
            else
            {
                Entry.Errors.Remove(nameof(RequiredValidationBehavior));
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }
        }
    }
}
