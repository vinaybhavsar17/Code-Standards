﻿using OfficerReports.Resources.Strings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Behaviors
{
    public class NumberValidationBehavior : EntryValidationBehavior
    {
        protected override void Validate(object sender)
        {
            var entryField = (InputView)sender;

            try
            {
                if (!string.IsNullOrEmpty(entryField.Text))
                {
                    var nummber = float.Parse(entryField.Text);
                    IsValid = true;
                }
                else
                {
                    IsValid = true;
                }
            }
            catch (Exception)
            {
                IsValid = false;
            }

            if (!IsValid && Interacted)
            {
                var validationMessage = ValidationMessage != string.Empty ? ValidationMessage : throw new ArgumentNullException("ValidationMessage is required");
                if (validationMessage.Contains("{0}"))
                {
                    var fieldName = AppResource.Value;
                    fieldName = !string.IsNullOrWhiteSpace(Entry.Title) ?
                        Entry.Title :
                        !string.IsNullOrWhiteSpace(Entry.Placeholder) ? Entry.Placeholder : fieldName;

                    validationMessage = String.Format(validationMessage, fieldName);
                }

                Entry.Errors[nameof(NumberValidationBehavior)] = validationMessage;
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }
            else
            {
                Entry.Errors.Remove(nameof(NumberValidationBehavior));
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }
        }
    }
}
