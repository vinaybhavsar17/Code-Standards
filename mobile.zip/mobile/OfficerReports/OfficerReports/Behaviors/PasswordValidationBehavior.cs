﻿using System;
using System.Text.RegularExpressions;

namespace OfficerReports.Behaviors
{
	public class PasswordValidationBehavior : EntryValidationBehavior
    {
        private const string _passwordRegex = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[!@#$&*]).{8,20}$";

        protected override void Validate(object sender)
        {
            var entryField = (InputView)sender;

            if (string.IsNullOrEmpty(entryField.Text))
                IsValid = true;
            else
                IsValid = (Regex.IsMatch(entryField.Text, _passwordRegex, RegexOptions.None, TimeSpan.FromMilliseconds(250)));

            if (!IsValid && Interacted)
            {
                Entry.Errors[nameof(PasswordValidationBehavior)] = ValidationMessage != string.Empty ? ValidationMessage : throw new ArgumentNullException("ValidationMessage is required for PasswordValidationBehavior");
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }
            else
            {
                Entry.Errors.Remove(nameof(PasswordValidationBehavior));
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }

        }
    }
}

