﻿using System;
using Entry = OfficerReports.Controls.Entry;

namespace OfficerReports.Behaviors
{
	public class PasswordCompareValidationBehavior : Behavior<Entry>
    {
        private Entry _entry;

        public static readonly BindableProperty IsValidProperty = BindableProperty.Create(nameof(IsValid), typeof(bool), typeof(PasswordCompareValidationBehavior), false, defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty ValidationMessageProperty = BindableProperty.Create(nameof(ValidationMessage), typeof(string), typeof(PasswordCompareValidationBehavior), string.Empty, defaultBindingMode: BindingMode.OneWay);
        public static readonly BindableProperty CompareToPasswordProperty = BindableProperty.Create(nameof(CompareToPassword), typeof(string), typeof(PasswordCompareValidationBehavior), string.Empty, defaultBindingMode: BindingMode.OneWay);

        public bool IsValid
        {
            get => (bool)GetValue(IsValidProperty);
            set => SetValue(IsValidProperty, value);
        }

        public string ValidationMessage
        {
            get => (string)GetValue(ValidationMessageProperty);
            set => SetValue(ValidationMessageProperty, value);
        }

        public string CompareToPassword
        {
            get => (string)GetValue(CompareToPasswordProperty);
            set => SetValue(CompareToPasswordProperty, value);
        }

        protected override void OnAttachedTo(Entry bindable)
        {
            _entry = bindable;
            bindable.GetEntryField().TextChanged += HandleTextChanged;
        }

        protected override void OnDetachingFrom(Entry bindable)
        {
            bindable.GetEntryField().TextChanged -= HandleTextChanged;
        }

        private void HandleTextChanged(object sender, TextChangedEventArgs e)
        {
            Validate(sender);
        }

        protected void Validate(object sender)
        {
            var entryField = (InputView)sender;

            try
            {
                if (string.IsNullOrEmpty(entryField.Text) || string.IsNullOrEmpty(CompareToPassword))
                {
                    IsValid = true;
                }
                else
                {
                    IsValid = entryField.Text.Equals(CompareToPassword);
                }
            }
            catch (Exception)
            {
                IsValid = false;
            }

            if (!IsValid)
            {
                _entry.Errors[nameof(PasswordCompareValidationBehavior)] = ValidationMessage != string.Empty ? ValidationMessage : throw new ArgumentNullException("ValidationMessage is required for PasswordCompareValidationBehavior");
                _entry.Errors = new Dictionary<string, string>(_entry.Errors);
            }
            else
            {
                _entry.Errors.Remove(nameof(PasswordCompareValidationBehavior));
                _entry.Errors = new Dictionary<string, string>(_entry.Errors);
            }
        }

        public void ForceValidate()
        {
            Validate(_entry.GetEntryField());
        }
    }
}

