﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace OfficerReports.Behaviors
{
    public class RegexValidationBehavior : EntryValidationBehavior
    {
        public virtual string RegexString { get; set; }

        protected override void Validate(object sender)
        {
            var entryField = (InputView)sender;

            if (string.IsNullOrEmpty(entryField.Text))
                IsValid = true;
            else
                IsValid = (Regex.IsMatch(entryField.Text, RegexString, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)));

            var type = this.GetType();
            if (!IsValid && Interacted)
            {
                Entry.Errors[type.Name] = ValidationMessage != string.Empty ? ValidationMessage : throw new ArgumentNullException("ValidationMessage is required for RegexValidationBehavior");
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }
            else
            {
                Entry.Errors.Remove(type.Name);
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }
        }
    }
}
