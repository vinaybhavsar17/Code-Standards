﻿using OfficerReports.Helpers;
using System.Text.RegularExpressions;

namespace OfficerReports.Behaviors
{
    public class EmailValidationBehavior : EntryValidationBehavior
    {
        private const string _emailRegex = @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
            @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$";

        protected override void Validate(object sender)
        {
            var entryField = (InputView)sender;

            if (string.IsNullOrEmpty(entryField.Text))
                IsValid = true;
            else
                IsValid = (Regex.IsMatch(entryField.Text, _emailRegex, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)));

            if (!IsValid && Interacted)
            {
                Entry.Errors[nameof(EmailValidationBehavior)] = ValidationMessage != string.Empty ? ValidationMessage : throw new ArgumentNullException("ValidationMessage is required for EmailValidationBehavior");
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }
            else
            {
                Entry.Errors.Remove(nameof(EmailValidationBehavior));
                Entry.Errors = new Dictionary<string, string>(Entry.Errors);
            }

        }
    }
}
