﻿using Android.Widget;
using Microsoft.Maui.Handlers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Controls
{
    public class BorderlessEditor : Editor
    {
        private static bool IsHandlerSet;

        public BorderlessEditor()
        {
            if (!IsHandlerSet)
            {
                EditorHandler.Mapper.AppendToMapping("CustomEditor", (handler, view) =>
                {
                    if (view is BorderlessEditor)
                    {
#if ANDROID
                        ((EditText)handler.PlatformView).Background = null;
                        ((EditText)handler.PlatformView).SetBackgroundColor(Android.Graphics.Color.Transparent);
                        ((EditText)handler.PlatformView).SetPadding(0, 0, 0, 0);
#endif
                    }
                });

                IsHandlerSet = true;
            }
        }
    }
}
