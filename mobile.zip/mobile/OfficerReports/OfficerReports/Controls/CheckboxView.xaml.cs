using OfficerReports.Models;
using System.Collections.ObjectModel;

namespace OfficerReports.Controls;

public partial class CheckboxView : ContentView
{
    public event EventHandler CheckedChanged;

    public static readonly BindableProperty CheckboxesProperty = BindableProperty.Create(nameof(CheckBoxes), typeof(ObservableCollection<CheckboxField>), typeof(CheckboxView));

    public ObservableCollection<CheckboxField> CheckBoxes
    {
        get => (ObservableCollection<CheckboxField>)GetValue(CheckboxesProperty);
        set => SetValue(CheckboxesProperty, value);
    }

    private bool _isMandatory;
    public bool IsMandatory
    {
        get { return _isMandatory; }
        set
        {
            _isMandatory = value;
            OnPropertyChanged(nameof(IsMandatory));
        }
    }

    private string _title;
    public string Title
    {
        get { return _title; }
        set
        {
            _title = value;
            OnPropertyChanged(nameof(Title));
        }
    }

    public CheckboxView()
	{
		InitializeComponent();

		BindingContext = this;
    }

    void CheckBox_CheckedChanged(System.Object sender, Microsoft.Maui.Controls.CheckedChangedEventArgs e)
    {
        CheckedChanged?.Invoke(sender, e);
    }
}