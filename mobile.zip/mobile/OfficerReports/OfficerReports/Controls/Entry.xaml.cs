using Microsoft.Maui.Handlers;
using OfficerReports.Constants;
using OfficerReports.Interfaces;
using OfficerReports.ViewModels.Base;
using System.Collections.ObjectModel;

namespace OfficerReports.Controls;

public partial class Entry : ContentView
{
    public event EventHandler<TextChangedEventArgs> TextChanged;

    //Entry control properties
    public static readonly BindableProperty TextProperty = BindableProperty.Create(nameof(Text), typeof(string), typeof(Entry), defaultBindingMode: BindingMode.TwoWay, propertyChanged: TextPropertyChanged);
    public static readonly BindableProperty PlaceholderProperty = BindableProperty.Create(nameof(Placeholder), typeof(string), typeof(Entry), string.Empty, propertyChanged: PlaceholderPropertyChanged);
    public static readonly BindableProperty MaxLengthProperty = BindableProperty.Create(nameof(MaxLength), typeof(int), typeof(Entry), int.MaxValue, propertyChanged: MaxLengthPropertyChanged);
    public static readonly BindableProperty IsPasswordProperty = BindableProperty.Create(nameof(IsPassword), typeof(bool), typeof(Entry), false, propertyChanged: IsPasswordPropertyChanged);
    public static readonly BindableProperty KeyboardProperty = BindableProperty.Create(nameof(Keyboard), typeof(Keyboard), typeof(Entry), Keyboard.Default, propertyChanged: KeyboardPropertyChanged);
    public static readonly BindableProperty ReturnTypeProperty = BindableProperty.Create(nameof(ReturnType), typeof(ReturnType), typeof(Entry), ReturnType.Default, propertyChanged: ReturnTypePropertyChanged);

    //Custom properties
    public static readonly BindableProperty ErrorsProperty = BindableProperty.Create(nameof(Errors), typeof(Dictionary<string,string>), typeof(Entry), defaultBindingMode: BindingMode.OneWay, propertyChanged: ErrorsPropertyChanged);
    public static readonly BindableProperty MinDateTimeProperty = BindableProperty.Create(nameof(MinDateTime), typeof(DateTime), typeof(Entry), defaultBindingMode: BindingMode.OneWay);
    public static readonly BindableProperty MaxDateTimeProperty = BindableProperty.Create(nameof(MaxDateTime), typeof(DateTime), typeof(Entry), defaultBindingMode: BindingMode.OneWay);
    public static readonly BindableProperty SelectedDateProperty = BindableProperty.Create(nameof(SelectedDate), typeof(DateTime), typeof(Entry), defaultBindingMode: BindingMode.TwoWay);
    public static readonly BindableProperty ItemsSourceProperty = BindableProperty.Create(nameof(ItemsSource), typeof(System.Collections.IList), typeof(Entry), defaultBindingMode: BindingMode.OneWay, propertyChanged: ItemsSourcePropertyChanged);
    public static readonly BindableProperty ItemDisplayBindingProperty = BindableProperty.Create(nameof(ItemDisplayBinding), typeof(string), typeof(Entry), defaultBindingMode: BindingMode.OneWay, propertyChanged: ItemDisplayBindingPropertyChanged);
    public static readonly BindableProperty SelectedItemIndexProperty = BindableProperty.Create(nameof(SelectedItemIndex), typeof(int), typeof(Entry), -1, defaultBindingMode: BindingMode.OneWayToSource, propertyChanged: SelectedItemIndexPropertyChanged);
    public static readonly BindableProperty SelectedItemProperty = BindableProperty.Create(nameof(SelectedItem), typeof(object), typeof(Entry), defaultBindingMode: BindingMode.TwoWay, propertyChanged: SelectedItemPropertyChanged);

    public string Text
    {
        get => (string)GetValue(TextProperty);
        set => SetValue(TextProperty, value);
    }

    public string Placeholder
    {
        get => (string)GetValue(PlaceholderProperty);
        set => SetValue(PlaceholderProperty, value);
    }

    public int MaxLength
    {
        get => (int)GetValue(MaxLengthProperty);
        set => SetValue(MaxLengthProperty, value);
    }

    public bool IsPassword
    {
        get => (bool)GetValue(IsPasswordProperty);
        set => SetValue(IsPasswordProperty, value);
    }

    public Keyboard Keyboard
    {
        get => (Keyboard)GetValue(KeyboardProperty);
        set => SetValue(KeyboardProperty, value);
    }

    public ReturnType ReturnType
    {
        get => (ReturnType)GetValue(ReturnTypeProperty);
        set => SetValue(ReturnTypeProperty, value);
    }

    public Dictionary<string, string> Errors
    {
        get => (Dictionary<string, string>)GetValue(ErrorsProperty);
        set => SetValue(ErrorsProperty, value);
    }

    public DateTime MinDateTime
    {
        get => (DateTime)GetValue(MinDateTimeProperty);
        set => SetValue(MinDateTimeProperty, value);
    }

    public DateTime MaxDateTime
    {
        get => (DateTime)GetValue(MaxDateTimeProperty);
        set => SetValue(MaxDateTimeProperty, value);
    }

    public DateTime SelectedDate
    {
        get => (DateTime)GetValue(SelectedDateProperty);
        set => SetValue(SelectedDateProperty, value);
    }

    public System.Collections.IList ItemsSource
    {
        get => (System.Collections.IList)GetValue(ItemsSourceProperty);
        set => SetValue(ItemsSourceProperty, value);
    }

    public string ItemDisplayBinding
    {
        get => (string)GetValue(ItemDisplayBindingProperty);
        set => SetValue(ItemDisplayBindingProperty, value);
    }

    public int SelectedItemIndex
    {
        get => (int)GetValue(SelectedItemIndexProperty);
        set => SetValue(SelectedItemIndexProperty, value);
    }

    public object SelectedItem
    {
        get => (object)GetValue(SelectedItemProperty);
        set => SetValue(SelectedItemProperty, value);
    }

    private string _title;
    public string Title
    {
        get { return _title; }
        set
        {
            _title = value;
            titleLbl.Text = _title;
            titleView.IsVisible = !string.IsNullOrWhiteSpace(_title);
            OnPropertyChanged(nameof(Title));
        }
    }

    private bool _isMandatory;
    public bool IsMandatory
    {
        get { return _isMandatory; }
        set
        {
            _isMandatory = value;
            asteriskLbl.IsVisible = _isMandatory;
            OnPropertyChanged(nameof(IsMandatory));
        }
    }

    private string _rightIcon;
    public string RightIcon
    {
        get { return _rightIcon; }
        set
        {
            _rightIcon = value;
            RightIconButton.IsVisible = !string.IsNullOrWhiteSpace(_rightIcon);
            RightIconButton.Source = ImageSource.FromFile(_rightIcon);
            OnPropertyChanged(nameof(RightIcon));
        }
    }

    public enum EntryTypeOptions
    {
        TextEntry,
        DatePicker,
        TimePicker,
        DateTimePicker,
        ListPicker,
        TextEditor
    }

    private EntryTypeOptions _entryType = EntryTypeOptions.TextEntry;
    public EntryTypeOptions EntryType
    {
        get { return _entryType; }
        set
        {
            _entryType = value;
            OnPropertyChanged(nameof(EntryType));
            UpdateEntryType();
        }
    }

    public InputView EntryField { 
        get 
        {
            return EntryType == EntryTypeOptions.TextEditor ? EditorTxt : EntryTxt;
        } 
    }

    public InputView GetEntryField()
    {
        return EntryField;
    }

    public Entry()
	{
		InitializeComponent();
        Errors = new Dictionary<string, string>();
        Text = String.Empty;
	}

    private static void TextPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if(newValue != null)
            ((Entry)bindable).EntryField.Text = newValue?.ToString();
    }

    private static void PlaceholderPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        ((Entry)bindable).EntryField.Placeholder = newValue?.ToString();
    }

    private static void MaxLengthPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        ((Entry)bindable).EntryField.MaxLength = int.Parse(newValue?.ToString());
    }

    private static void IsPasswordPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var entryBindable = (Entry)bindable;
        entryBindable.EntryTxt.IsPassword = bool.Parse(newValue?.ToString());
        entryBindable.RightIcon = "visibility_off";
        entryBindable.RightIconButton.Clicked += (s, e) => 
        {
            entryBindable.EntryTxt.IsPassword = !((Entry)bindable).EntryTxt.IsPassword;
            entryBindable.RightIcon = entryBindable.EntryTxt.IsPassword ? "visibility_off" : "visibility";
        };
    }

    private static void KeyboardPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        ((Entry)bindable).EntryField.Keyboard = (Keyboard)newValue;
    }

    private static void ReturnTypePropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        ((Entry)bindable).EntryTxt.ReturnType = (ReturnType)newValue;
    }

    private static void ErrorsPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var errors = (Dictionary<string, string>)newValue;
        var errorText = string.Empty;
        var errorsCount = errors.Count;

        var behaviors = ((Entry)bindable).Behaviors;

        if (behaviors != null && behaviors.Count > 0)
        {
            foreach (var behavior in behaviors)
            {
                var key = behavior.GetType().Name;
                if (errors.ContainsKey(key))
                {
                    errorText = errors[key] != null ? errors[key] : string.Empty;
                    break;
                }
            }
        }
        else
        {
            errorText = errors.Values.FirstOrDefault() != null ? errors.Values.FirstOrDefault() : string.Empty;
        }

        ((Entry)bindable).ErrorField.Text = errorText;
        ((Entry)bindable).ErrorField.IsVisible = errorsCount > 0 && errorText != string.Empty;
    }

    private static void ItemsSourcePropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var picker = (Picker)((Entry)bindable).EntryContainer.Children.Where((c) => c.GetType() == typeof(Picker)).FirstOrDefault();

        if (picker != null)
            picker.ItemsSource = (System.Collections.IList)newValue;
    }

    private static void ItemDisplayBindingPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var picker = (Picker)((Entry)bindable).EntryContainer.Children.Where((c) => c.GetType() == typeof(Picker)).FirstOrDefault();

        if (picker != null)
            picker.ItemDisplayBinding = new Binding(newValue.ToString());
    }

    private static void SelectedItemIndexPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var picker = (Picker)((Entry)bindable).EntryContainer.Children.Where((c) => c.GetType() == typeof(Picker)).FirstOrDefault();

        if (picker != null && picker.SelectedIndex != (int)newValue)
            picker.SelectedIndex = (int)newValue;
    }

    private static void SelectedItemPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var picker = (Picker)((Entry)bindable).EntryContainer.Children.Where((c) => c.GetType() == typeof(Picker)).FirstOrDefault();

        if (picker != null && picker.SelectedItem != newValue)
            picker.SelectedItem = newValue;
    }

    private void EntryField_TextChanged(object sender, TextChangedEventArgs e)
    {
        Text = ((InputView)sender).Text;
        TextChanged?.Invoke(sender, e);
    }

    private void EntryField_Completed(object sender, EventArgs e)
    {
        var entryList = (Parent as Layout).Children;
        var index = entryList.IndexOf(this);

        var nextIndex = index;
        var isEntryField = false;
        do
        {
            nextIndex = (nextIndex + 1) >= entryList.Count ? -1 : (nextIndex + 1);
            if(nextIndex != -1)
            {
                var nextEntry = entryList[nextIndex];
                isEntryField = nextEntry is Entry;
            }
        } while (nextIndex != -1 && !isEntryField);

        if(nextIndex != -1)
        {
            var nextEntry = entryList[nextIndex];
            ((Entry)nextEntry).EntryField.Focus();
        }
        else
        {
            //EntryField.Unfocus();

            //This is a workaround in xamarin because there is no method available to dismiss the keyboard
            EntryField.IsEnabled = false;
            EntryField.IsEnabled = true;
        }
    }

    private void UpdateEntryType()
    {
        switch (EntryType)
        {
            case EntryTypeOptions.TextEntry:
                ConfigureEntryForText();
                break;
            case EntryTypeOptions.DateTimePicker:
                ConfigureEntryForDateTime(EntryTypeOptions.DateTimePicker);
                break;
            case EntryTypeOptions.DatePicker:
                ConfigureEntryForDateTime(EntryTypeOptions.DatePicker);
                break;
            case EntryTypeOptions.TimePicker:
                ConfigureEntryForDateTime(EntryTypeOptions.TimePicker);
                break;
            case EntryTypeOptions.TextEditor:
                ConfigureEntryForEditor();
                break;
            case EntryTypeOptions.ListPicker:
                ConfigureEntryForListPicker();
                break;
            default:
                break;
        }
    }

    private void ConfigureEntryForText()
    {
        EntryFrame.IsVisible = true;
        EditorFrame.IsVisible = false;

        EntryField.IsReadOnly = false;

        RightIconButton.GestureRecognizers.Clear();
        EntryTxt.GestureRecognizers.Clear();
        GestureRecognizers.Clear();
    }

    private void ConfigureEntryForDateTime(EntryTypeOptions type)
    {
        EntryFrame.IsVisible = true;
        EditorFrame.IsVisible = false;

        EntryField.IsReadOnly = true;

        var tapGesture = new TapGestureRecognizer()
        {
            NumberOfTapsRequired = 1,
            Command = new Command(async() =>
            {
                if (type == EntryTypeOptions.DateTimePicker)
                {
                    var selectedDateTime = default(DateTime);

                    var date = await PlatformServices.ShowDatePicker(MinDateTime, MaxDateTime);
                    if (date != default(DateTime))
                    {
                        selectedDateTime = date;
                        var time = await PlatformServices.ShowTimePicker();

                        if (time != default(TimeSpan))
                        {
                            selectedDateTime = selectedDateTime.Date.Add(time);

                            Text = selectedDateTime.ToString(AppConstants.DateTimeFormat);
                            SelectedDate = selectedDateTime;
                        }
                    }
                }
                else if (type == EntryTypeOptions.DatePicker)
                {
                    var date = await PlatformServices.ShowDatePicker(MinDateTime, MaxDateTime);
                    if (date != default(DateTime))
                    {
                        Text = date.ToString(AppConstants.DateFormat);
                        SelectedDate = date;
                    }
                }
                else if (type == EntryTypeOptions.TimePicker)
                {
                    var time = await PlatformServices.ShowTimePicker();
                    if (time != default(TimeSpan))
                    {
                        Text = time.ToString(AppConstants.TimeFormat);
                    }
                }
            })
        };

        EntryTxt.GestureRecognizers.Add(tapGesture);
        RightIconButton.GestureRecognizers.Add(tapGesture);
        GestureRecognizers.Add(tapGesture);
    }

    private void ConfigureEntryForEditor()
    {
        EntryFrame.IsVisible = false;
        EditorFrame.IsVisible = true;

        EntryTxt.GestureRecognizers.Clear();
        RightIconButton.GestureRecognizers.Clear();
        GestureRecognizers.Clear();
    }

    private void ConfigureEntryForListPicker()
    {
        EntryFrame.IsVisible = true;
        EditorFrame.IsVisible = false;

        EntryField.IsReadOnly = true;

        RightIcon = "arrow_down";

        var picker = new Picker
        {
            Title = Title,
            Opacity = 0
        };
        picker.ItemsSource = ItemsSource;
        picker.SelectedIndexChanged += (sender, args) =>
        {
            if (picker.SelectedItem != null)
            {
                if (picker.SelectedItem is string)
                {
                    Text = picker.SelectedItem.ToString();
                }
                else
                {
                    var textProp = picker.SelectedItem.GetType().GetProperty(ItemDisplayBinding);
                    Text = textProp.GetValue(picker.SelectedItem).ToString();
                }
            }
            else
            {
                Text = string.Empty;
            }
            SelectedItemIndex = picker.SelectedIndex;
            SelectedItem = picker.SelectedItem;
        };
        Grid.SetColumnSpan(picker, 2);
        EntryContainer.Add(picker);

        var tapGesture = new TapGestureRecognizer()
        {
            NumberOfTapsRequired = 1,
            Command = new Command(() =>
            {
                picker.Focus();
            })
        };

        EntryTxt.GestureRecognizers.Add(tapGesture);
        RightIconButton.GestureRecognizers.Add(tapGesture);
        GestureRecognizers.Add(tapGesture);
    }
}