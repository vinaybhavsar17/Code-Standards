﻿using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace OfficerReports.Controls;

[ContentProperty("TabItems")]
public class TabView : ContentView
{
    private StackLayout _tabItemsLayout;
    private StackLayout _tabContentView;
    private BoxView _tabIndicator;
    private int _selectedIndex = -1;

    public event EventHandler<TabChangeEventArgs> TabChanged;

    public static readonly BindableProperty TabItemsProperty = BindableProperty.Create(nameof(TabItems), typeof(ObservableCollection<TabItem>), typeof(TabView));

    public ObservableCollection<TabItem> TabItems
    {
        get => (ObservableCollection<TabItem>)GetValue(TabItemsProperty);
        set => SetValue(TabItemsProperty, value);
    }

    private Color _barColor = (Color)App.GetResource("WhiteColor", App.ResourceFile.DefaultTheme);
    public Color BarColor { 
        get 
        {
            return _barColor;
        } 
        set 
        {
            _barColor = value;
            OnPropertyChanged(nameof(BarColor));
        } 
    }

    private Color _selectionColor = (Color)App.GetResource("PrimaryColor", App.ResourceFile.DefaultTheme);
    public Color SelectionColor
    {
        get
        {
            return _selectionColor;
        }
        set
        {
            _selectionColor = value;
            OnPropertyChanged(nameof(SelectionColor));
        }
    }

    public TabView()
    {
        TabItems = new ObservableCollection<TabItem>();
        TabItems.CollectionChanged += TabItemsCollectionChanged;

        var mainContainer = new Grid();

        var outerStackLayout = new StackLayout();
        mainContainer.Add(outerStackLayout);

        var proxyView = new BoxView {
            Color = Colors.Transparent,
            HorizontalOptions = LayoutOptions.FillAndExpand,
            HeightRequest = 48
        };
        outerStackLayout.Add(proxyView);

        _tabContentView = new StackLayout
        {
            Orientation = StackOrientation.Horizontal,
            WidthRequest = 0,
            HorizontalOptions = LayoutOptions.Start
        };
        outerStackLayout.Add(_tabContentView);

        var gridContainer = new Grid
        {
            HeightRequest = 48,
            VerticalOptions = LayoutOptions.Start
        };
        mainContainer.Add(gridContainer);

        _tabItemsLayout = new StackLayout
        {
            Orientation = StackOrientation.Horizontal,
            Spacing = 0
        };
        _tabItemsLayout.SetBinding(StackLayout.BackgroundColorProperty, new Binding(nameof(BarColor), source: this));
        _tabItemsLayout.Shadow = new Shadow
        {
            Brush = new SolidColorBrush(Color.Parse("#0800000F")),
            Offset = new Point(0, 20),
            Radius = 40
        };
        gridContainer.Add(_tabItemsLayout);

        _tabIndicator = new BoxView
        {
            HeightRequest = 2,
            VerticalOptions = LayoutOptions.End,
            HorizontalOptions = LayoutOptions.Start
        };
        _tabIndicator.SetBinding(BoxView.ColorProperty, new Binding(nameof(SelectionColor), source: this));
        gridContainer.Add(_tabIndicator);

        Content = mainContainer;
    }

    protected override void OnSizeAllocated(double width, double height)
    {
        base.OnSizeAllocated(width, height);

        if(width > -1 && height > -1 && TabItems.Count > 0)
        {
            _tabIndicator.WidthRequest = TabItems[0].Width;
        }
    }

    private void TabItemsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
        if (e.NewItems == null || e.NewItems.Count == 0)
            return;

        foreach (var item in e.NewItems)
        {
            var tabItem = (TabItem)item;

            if (_selectedIndex == -1 && TabItems.Count == 1)
            {
                _selectedIndex = 0;
                tabItem.Selected = true;
            }

            var tabItemTapGesture = new TapGestureRecognizer();
            tabItemTapGesture.Tapped += TabSelected;
            tabItem.GestureRecognizers.Add(tabItemTapGesture);
            tabItem.TabContentView.WidthRequest = DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density;

            _tabItemsLayout.Add(tabItem);
            _tabContentView.Add(tabItem.TabContentView);
            _tabContentView.WidthRequest = _tabContentView.WidthRequest + tabItem.TabContentView.WidthRequest;
        }
    }

    private void TabSelected(object sender, EventArgs e)
    {
        var previousSelectedTab = TabItems[_selectedIndex];
        var currentSelectedTab = (TabItem)sender;

        if (currentSelectedTab == previousSelectedTab)
            return;

        currentSelectedTab.Selected = true;
        previousSelectedTab.Selected = false;

        var tabChangeEventArgs = new TabChangeEventArgs
        {
            OldTabIndex = _selectedIndex
        };

        _selectedIndex = TabItems.IndexOf(currentSelectedTab);
        tabChangeEventArgs.NewTabIndex = _selectedIndex;

        UpdateTabIndicatorPosition();

        _tabContentView.TranslateTo(-(_selectedIndex * currentSelectedTab.TabContentView.Width), 0, 150);        

        TabChanged?.Invoke(this, tabChangeEventArgs);
    }

    private void UpdateTabIndicatorPosition()
    {
        _tabIndicator.TranslateTo(_selectedIndex * _tabIndicator.Width, 0);
    }

    public class TabChangeEventArgs : EventArgs
    {
        public int OldTabIndex { get; set; }
        public int NewTabIndex { get; set; }
    }
}