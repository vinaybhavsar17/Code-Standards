using CommunityToolkit.Maui.Views;

namespace OfficerReports.Controls;

public partial class LoadingIndicator : Popup
{
    private string _message;
    public string Message
    {
        get { return _message; }
        set
        {
            _message = value;
            OnPropertyChanged(nameof(Message));
        }
    }

    public LoadingIndicator()
	{
		InitializeComponent();

		BindingContext = this;
	}
}