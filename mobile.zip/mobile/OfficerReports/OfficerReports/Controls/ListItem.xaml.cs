using System.Windows.Input;

namespace OfficerReports.Controls;

public partial class ListItem : ContentView
{
	public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(ICommand), typeof(ListItem));
    public static readonly BindableProperty TitleProperty = BindableProperty.Create(nameof(Title), typeof(string), typeof(ListItem), propertyChanged: OnTitlePropertyChanged);
    public static readonly BindableProperty CommandParameterProperty = BindableProperty.Create(nameof(CommandParameter), typeof(object), typeof(ListItem));
    public static readonly BindableProperty BadgeCountProperty = BindableProperty.Create(nameof(BadgeCount), typeof(int), typeof(BadgeView));

    public ICommand Command
	{
		get => (ICommand)GetValue(CommandProperty);
		set => SetValue(CommandProperty, value);
	}

    public object CommandParameter
    {
        get => (object)GetValue(CommandParameterProperty);
        set => SetValue(CommandParameterProperty, value);
    }

    public string Title
    {
        get => (string)GetValue(TitleProperty);
        set => SetValue(TitleProperty, value);
    }

    private static void OnTitlePropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
		(bindable as ListItem).titleTxt.Text = newValue?.ToString();
    }

    public int BadgeCount
    {
        get => (int)GetValue(BadgeCountProperty);
        set => SetValue(BadgeCountProperty, value);
    }

    private BadgeView.BadgeTypeOptions _badgeType;
    public BadgeView.BadgeTypeOptions BadgeType { 
        get { return _badgeType; } 
        set 
        {
            _badgeType = value;
            OnPropertyChanged(nameof(BadgeType));
        } 
    }

    private string _icon;
	public string Icon
	{
		get { return _icon; }
		set
		{
			_icon = value;

            if (string.IsNullOrEmpty(value))
            {
				IconFrame.IsVisible = false;
			}
            else
            {
				IconImage.Source = ImageSource.FromFile(value);
				IconFrame.IsVisible = true;
			}

			OnPropertyChanged();
		}
	}

	public ListItem()
	{
		InitializeComponent();
	}

    private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
    {
        if (Command != null && Command.CanExecute(CommandParameter))
            Command.Execute(CommandParameter);
    }
}