namespace OfficerReports.Controls;

[ContentProperty("TabContentView")]
public partial class TabItem : ContentView
{
    public static readonly BindableProperty TitleProperty = BindableProperty.Create(nameof(Title), typeof(string), typeof(TabItem));
    public static readonly BindableProperty SelectedProperty = BindableProperty.Create(nameof(Selected), typeof(bool), typeof(TabItem), propertyChanged: SelectedPropertyChanged);
    public static readonly BindableProperty TabContentViewProperty = BindableProperty.Create(nameof(TabContentView), typeof(View), typeof(TabItem), propertyChanged: TabContentViewPropertyChanged);
    public static readonly BindableProperty BadgeCountProperty = BindableProperty.Create(nameof(BadgeCount), typeof(int), typeof(TabItem), propertyChanged: BadgeCountPropertyChanged);

    private static void BadgeCountPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        
    }

    private static void SelectedPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var tabItem = (TabItem)bindable;
        var selected = (bool)newValue;
        if (selected)
            tabItem.tabTitleLbl.TextColor = (Color)App.GetResource("AccentTextColor", App.ResourceFile.DefaultTheme);
        else
            tabItem.tabTitleLbl.TextColor = (Color)App.GetResource("SecondaryTextColor", App.ResourceFile.DefaultTheme);
    }

    protected static void TabContentViewPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var tabItem = ((TabItem)bindable);

        if (tabItem.ViewContentLayout == null || newValue == tabItem.ViewContentLayout)
            tabItem.Content = tabItem.TabContentView;
    }

    public string Title
    {
        get => (string)GetValue(TitleProperty);
        set => SetValue(TitleProperty, value);
    }

    public bool Selected
    {
        get => (bool)GetValue(SelectedProperty);
        set => SetValue(SelectedProperty, value);
    }

    public int BadgeCount
    {
        get => (int)GetValue(BadgeCountProperty);
        set => SetValue(BadgeCountProperty, value);
    }

    public View TabContentView
    {
        get => (View)GetValue(TabContentViewProperty);
        set => SetValue(TabContentViewProperty, value);
    }

    public TabItem()
	{
		InitializeComponent();

        Selected = false;
	}
}