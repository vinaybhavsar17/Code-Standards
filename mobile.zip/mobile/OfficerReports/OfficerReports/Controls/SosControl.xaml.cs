using System.Windows.Input;
using System.Timers;
using Timer = System.Timers.Timer;
using OfficerReports.Resources.Strings;

namespace OfficerReports.Controls;

public partial class SosControl : ContentView
{
    private int _countSeconds;
    private Timer _timer;
    private bool _isSosRequested;

    public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(ICommand), typeof(SosControl));
    public ICommand Command
    {
        get => (ICommand)GetValue(CommandProperty);
        set => SetValue(CommandProperty, value);
    }

    private string _count;
    public string Count
    {
        get { return _count; }
        set
        {
            _count = value;
            OnPropertyChanged(nameof(Count));
        }
    }

    public SosControl()
	{
		InitializeComponent();
        SetTimer();
    }

    private void SetTimer()
    {
        _timer = new Timer(1000);
        _timer.Elapsed += TimerElapsed;
    }

    private void TimerElapsed(object sender, ElapsedEventArgs e)
    {
        _countSeconds--;
        Count = _countSeconds.ToString();
        if (_countSeconds == 0)
        {
            _timer.Stop();
            _isSosRequested = true;
            Count = AppResource.Release_To_Send_Alert;
        }
    }

    private async void SosButtonPressed(object sender, EventArgs e)
    {
        await sosButton.ScaleTo(1.3);
        Vibration.Default.Vibrate(500);
        _countSeconds = 5;
        _timer.Start();
    }

    private async void SosButtonReleased(object sender, EventArgs e)
    {
        await sosButton.ScaleTo(1);
        if (_countSeconds > 0)
        {
            _timer.Stop();
        }
        if (_isSosRequested)
        {
            _isSosRequested = false;
            Command?.Execute(true);
        }
        Count = string.Empty;
    }
}