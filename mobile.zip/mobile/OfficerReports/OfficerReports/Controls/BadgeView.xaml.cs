namespace OfficerReports.Controls;

public partial class BadgeView : ContentView
{
    public enum BadgeTypeOptions
    {
        Number,
        Dot
    }

    public static readonly BindableProperty BadgeCountProperty = BindableProperty.Create(nameof(BadgeCount), typeof(int), typeof(BadgeView), propertyChanged: BadgeCountPropertyChanged);
    public static readonly BindableProperty BadgeTypeProperty = BindableProperty.Create(nameof(BadgeType), typeof(BadgeTypeOptions), typeof(BadgeView), propertyChanged: BadgeTypePropertyChanged);

    private static void BadgeTypePropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        ((BadgeView)bindable).UpdateBadgeType();
    }

    private static void BadgeCountPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var badgeView = (BadgeView)bindable;
        var p = badgeView.Parent;
        if (badgeView.BadgeCount < 100)
            badgeView.badgeLbl.Text = badgeView.BadgeCount.ToString();
        else
            badgeView.badgeLbl.Text = "*";
    }

    public int BadgeCount
    {
        get => (int)GetValue(BadgeCountProperty);
        set => SetValue(BadgeCountProperty, value);
    }

    public BadgeTypeOptions BadgeType
    {
        get => (BadgeTypeOptions)GetValue(BadgeTypeProperty);
        set => SetValue(BadgeTypeProperty, value);
    }

    public BadgeView()
	{
		InitializeComponent();
	}

    private void UpdateBadgeType()
    {
        if(BadgeType == BadgeTypeOptions.Dot)
        {
            badgeLbl.IsVisible = false;
            Scale = 0.5;
        }
    }
}