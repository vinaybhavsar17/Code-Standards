using OfficerReports.Resources.Strings;
using OfficerReports.Services.Dialog;
using OfficerReports.ViewModels.Base;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace OfficerReports.Controls;

public partial class FileUpload : ContentView
{
    public event EventHandler ItemsChanged;

    private static readonly long _fileSizeLimit = 786432000;
    private readonly string _fileTypeImage = "image/*";
    private readonly string _fileTypeVideo = "video/*";
    private readonly string _fileTypeAudio = "audio/*";
    private readonly string _fileTypePdf = "pdf/*";
    private FilePickerFileType _customFileType = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
    {
        { DevicePlatform.Android, new[]{ "image/*", "video/*", "audio/*" } }
    });
    private IDialogService _dialogService;

    public static readonly BindableProperty FilesProperty = BindableProperty.Create(nameof(Files), typeof(ObservableCollection<Models.FileInfo>), typeof(FileUpload), defaultBindingMode: BindingMode.TwoWay);

    public ObservableCollection<Models.FileInfo> Files
    {
        get => (ObservableCollection<Models.FileInfo>)GetValue(FilesProperty);
        set => SetValue(FilesProperty, value);
    }

    public string FilePropertyName { get; set; } = nameof(Files);

    private int _maxFileCount;
    public int MaxFileCount
    {
        get { return _maxFileCount; }
        set
        {
            _maxFileCount = value;
            OnPropertyChanged(nameof(MaxFileCount));
        }
    }

    private string _supportedFileTypes = "image,video,audio";
    public string SupportedFileTypes
    {
        get { return _supportedFileTypes; }
        set
        {
            _supportedFileTypes = value;
            OnPropertyChanged(nameof(SupportedFileTypes));

            try
            {
                var fileTypesArray = GetSupportedFileTypes(_supportedFileTypes);

                _customFileType = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
                {
                    { DevicePlatform.Android, fileTypesArray }
                });
            }
            catch (Exception)
            {
            }
        }
    }

    public ICommand DeleteFileCommand => new Command<Models.FileInfo>((fileInfo) => DeleteFile(fileInfo));

    public FileUpload()
	{
		InitializeComponent();

        _dialogService = App.ServiceProvider.GetRequiredService<IDialogService>();
    }

    private string[] GetSupportedFileTypes(string commaSeparatedFileTypes)
    {
        var fileTypesList = new List<string>();
        SupportedTypesLabel.Text = $"(+{AppResource.Add}";

        var fileTypesArr = commaSeparatedFileTypes.Split(",");
        if(fileTypesArr != null && fileTypesArr.Count() > 0)
        {
            foreach (var fileType in fileTypesArr)
            {
                switch (fileType)
                {
                    case "image":
                        fileTypesList.Add(_fileTypeImage);
                        SupportedTypesLabel.Text = SupportedTypesLabel.Text + " " + AppResource.Photo.ToLower() + ",";
                        break;
                    case "video":
                        fileTypesList.Add(_fileTypeVideo);
                        SupportedTypesLabel.Text = SupportedTypesLabel.Text + " " + AppResource.Video.ToLower() + ",";
                        break;
                    case "audio":
                        fileTypesList.Add(_fileTypeAudio);
                        SupportedTypesLabel.Text = SupportedTypesLabel.Text + " " + AppResource.Audio.ToLower() + ",";
                        break;
                    case "pdf":
                        fileTypesList.Add(_fileTypePdf);
                        SupportedTypesLabel.Text = SupportedTypesLabel.Text + " " + AppResource.Pdf.ToLower() + ",";
                        break;
                    default:
                        break;
                }
            }

            SupportedTypesLabel.Text = SupportedTypesLabel.Text.Remove(SupportedTypesLabel.Text.Length - 1);
            var lastCommaIndex = SupportedTypesLabel.Text.LastIndexOf(",");
            if(lastCommaIndex != -1)
            {
                SupportedTypesLabel.Text = SupportedTypesLabel.Text.Remove(lastCommaIndex, 1);
                SupportedTypesLabel.Text = SupportedTypesLabel.Text.Insert(lastCommaIndex, $" {AppResource.Or}");
            }
            SupportedTypesLabel.Text = SupportedTypesLabel.Text + ")";

            return fileTypesList.ToArray();
        }
        else
        {
            return new[] { "image/*", "video/*", "audio/*" };
        }
    }

    private void FileUploadTapped(object sender, EventArgs e)
    {
        if (MaxFileCount > 0)
        {
            if (Files == null)
                PickFile();
            else if (Files.Count < MaxFileCount)
                PickFile();
            else
                _dialogService.ShowMessage(AppResource.Alert, String.Format(AppResource.File_Count_Validation, (MaxFileCount)));
        }
        else
        {
            PickFile();
        }
    }

    private async void PickFile()
    {
        if (MediaPicker.Default.IsCaptureSupported)
        {
            var buttons = new List<string>();

            if (SupportedFileTypes.Contains("image"))
                buttons.Add(AppResource.Take_Photo);

            if (SupportedFileTypes.Contains("video"))
                buttons.Add(AppResource.Take_Video);

            buttons.Add(AppResource.Gallery);

            var selectionOption = await _dialogService.ShowOptions(AppResource.Select_Option, AppResource.Cancel, null, buttons.ToArray());

            if (selectionOption == AppResource.Gallery)
                PickFileFromGallery();
            else if (selectionOption == AppResource.Take_Photo)
                PickPhotoFromCamera();
            else if (selectionOption == AppResource.Take_Video)
                PickVideoFromCamera();
        }
        else
        {
            PickFileFromGallery();
        }
    }

    private async void PickFileFromGallery()
    {
        var result = await FilePicker.PickAsync(new PickOptions
        {
            FileTypes = _customFileType,
            PickerTitle = "Select a file"
        });

        ProcessFileResult(result);
    }

    private async void PickPhotoFromCamera()
    {
        if (MediaPicker.Default.IsCaptureSupported)
        {
            FileResult photo = await MediaPicker.Default.CapturePhotoAsync();

            ProcessFileResult(photo);
        }
    }

    private async void PickVideoFromCamera()
    {
        if (MediaPicker.Default.IsCaptureSupported)
        {
            FileResult video = await MediaPicker.Default.CaptureVideoAsync();

            ProcessFileResult(video);
        }
    }

    private async void ProcessFileResult(FileResult result)
    {
        if (result == null) return;

        var fileStream = await result.OpenReadAsync();
        if (fileStream == null) return;

        if (fileStream.Length > _fileSizeLimit)
        {
            await Task.Delay(100); //Waiting for file picker window to close otherwise alert popup will not display.
            _dialogService.ShowMessage(AppResource.Alert, String.Format(AppResource.File_Size_Validation, (_fileSizeLimit / 1048576) + " MB"));
            return;
        }

        if (Files == null)
            Files = new ObservableCollection<Models.FileInfo>();

        var file = new Models.FileInfo
        {
            ContentType = result.ContentType,
            FileName = result.FileName,
            FullPath = result.FullPath,
            FileSize = fileStream.Length,
            CreatedDate = DateTime.UtcNow

        };

        if (result.ContentType.Contains("image"))
        {
            file.Image = ImageSource.FromFile(result.FullPath);
            file.IsImage = true;
        }

        Files.Add(file);

        ((ViewModelBase)BindingContext).RaisePropertyChanged(FilePropertyName);

        ItemsChanged?.Invoke(this, new EventArgs());
    }

    private void DeleteFile(Models.FileInfo fileInfo)
    {
        Files.Remove(fileInfo);

        ((ViewModelBase)BindingContext).RaisePropertyChanged(FilePropertyName);

        ItemsChanged?.Invoke(this, new EventArgs());
    }

    void Entry_TextChanged(System.Object sender, Microsoft.Maui.Controls.TextChangedEventArgs e)
    {
        ((ViewModelBase)BindingContext).RaisePropertyChanged(FilePropertyName);
    }
}