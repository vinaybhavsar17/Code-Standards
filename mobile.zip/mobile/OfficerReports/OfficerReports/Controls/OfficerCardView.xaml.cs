namespace OfficerReports.Controls;

public partial class OfficerCardView : CardView
{
	public OfficerCardView()
	{
		InitializeComponent();
	}

    private void CardTapped(object sender, EventArgs e)
    {
        if (Command != null && Command.CanExecute(CommandParameter))
            Command.Execute(CommandParameter);
    }
}