using System.Windows.Input;

namespace OfficerReports.Controls;

public partial class ImageTextButton : ContentView
{
    public static readonly BindableProperty TextProperty = BindableProperty.Create(nameof(Text), typeof(string), typeof(ImageTextButton), defaultBindingMode: BindingMode.OneWay, propertyChanged: TextPropertyChanged);
    public static readonly BindableProperty IconProperty = BindableProperty.Create(nameof(Icon), typeof(string), typeof(ImageTextButton), defaultBindingMode: BindingMode.OneWay, propertyChanged: IconPropertyChanged);
    public static readonly BindableProperty BgColorProperty = BindableProperty.Create(nameof(BgColor), typeof(Color), typeof(ImageTextButton), defaultBindingMode: BindingMode.OneWay, propertyChanged: BgColorPropertyChanged);
    public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(ICommand), typeof(ImageTextButton));

    public ICommand Command
    {
        get => (ICommand)GetValue(CommandProperty);
        set => SetValue(CommandProperty, value);
    }

    public Color BgColor
    {
        get => (Color)GetValue(BgColorProperty);
        set => SetValue(BgColorProperty, value);
    }

    public string Text
    {
        get => (string)GetValue(TextProperty);
        set => SetValue(TextProperty, value);
    }

    public string Icon
    {
        get => (string)GetValue(TextProperty);
        set => SetValue(TextProperty, value);
    }

    public ImageTextButton()
	{
		InitializeComponent();
	}

    private static void TextPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (newValue != null)
            ((ImageTextButton)bindable).ButtonLabel.Text = newValue?.ToString();
    }

    private static void IconPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (newValue != null)
            ((ImageTextButton)bindable).ButtonIcon.Source = ImageSource.FromFile(newValue.ToString());
    }

    private static void BgColorPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (newValue != null)
            ((ImageTextButton)bindable).ButtonFrame.BackgroundColor = (Color)newValue;
    }

    private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
    {
        if (Command != null && Command.CanExecute(null))
            Command.Execute(null);
    }
}