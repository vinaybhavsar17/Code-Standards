using CommunityToolkit.Maui.Views;
using OfficerReports.Interfaces;

namespace OfficerReports.Controls;

public partial class UploadProgressIndicator : Popup
{
    public IProgressBarHandler ProgressBarHandler { get; set; }

    public bool IsClosed { get; set; }

    private string _message;
    public string Message
    {
        get { return _message; }
        set
        {
            _message = value;
            OnPropertyChanged(nameof(Message));
        }
    }

    private string _percentage;
    public string Percentage
    {
        get { return _percentage; }
        set
        {
            _percentage = value;
            OnPropertyChanged(nameof(Percentage));
        }
    }

    public UploadProgressIndicator()
	{
		InitializeComponent();

        InnerLayout.WidthRequest = (DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density) - 40;

        BindingContext = this;

        ProgressBarHandler = new ProgressBarHandler(progressBar, this);
    }
}

public class ProgressBarHandler : IProgressBarHandler
{
    private UploadProgressIndicator _progressPopup;
    private ProgressBar _progressBar;

    public ProgressBarHandler(ProgressBar progressBar, UploadProgressIndicator progressPopup)
    {
        _progressPopup = progressPopup;
        _progressBar = progressBar;
    }

    public void SetProgress(double progress)
    {
        if (progress <= 1)
        {
            _progressBar.ProgressTo(progress, 100, Easing.Linear);

            var percentage = Convert.ToInt32(progress * 100);
            _progressPopup.Percentage = $"({percentage}%)";
        }

    }

    public double Progress
    {
        get
        {
            return _progressBar.Progress;
        }
    }

    public void SetMessage(string message)
    {
        _progressPopup.Message = message;
    }
}