using System.Windows.Input;

namespace OfficerReports.Controls;

public partial class CardView : ContentView
{
    public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(ICommand), typeof(CardView));
    public static readonly BindableProperty CommandParameterProperty = BindableProperty.Create(nameof(CommandParameter), typeof(object), typeof(CardView));

    public ICommand Command
    {
        get => (ICommand)GetValue(CommandProperty);
        set => SetValue(CommandProperty, value);
    }

    public object CommandParameter
    {
        get => (object)GetValue(CommandParameterProperty);
        set => SetValue(CommandParameterProperty, value);
    }

    private Color _cardBackgroundColor = (Color)App.GetResource("CardBackgroundColor", App.ResourceFile.DefaultTheme);
    public Color CardBackgroundColor {
        get { return _cardBackgroundColor; }
        set
        {
            _cardBackgroundColor = value;
            OnPropertyChanged(nameof(CardBackgroundColor));
        }
    }

    private Style _cardViewPaddingStyle = (Style)App.GetResource("CardViewPaddingStyle", App.ResourceFile.AppStyles);
    public Style CardViewPaddingStyle
    {
        get { return _cardViewPaddingStyle; }
        set
        {
            _cardViewPaddingStyle = value;
            OnPropertyChanged(nameof(CardViewPaddingStyle));
        }
    }

    public CardView()
	{
		InitializeComponent();
	}

    private void CardTapped(object sender, EventArgs e)
    {
        if (Command != null && Command.CanExecute(CommandParameter))
            Command.Execute(CommandParameter);
    }
}