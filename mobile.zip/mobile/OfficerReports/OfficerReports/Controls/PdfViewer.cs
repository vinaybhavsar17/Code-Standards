﻿using Microsoft.Maui.Handlers;
using System.Net;

namespace OfficerReports.Controls
{
    public class PdfViewer : WebView
    {
        private static bool IsHandlerSet;
        public string Url { 
            get 
            {
                return (Source as UrlWebViewSource).Url;
            }
            set 
            {
                Source = new UrlWebViewSource
                {
                    Url = $"file:///android_asset/pdfjs/web/viewer.html?" + $"file={WebUtility.UrlEncode(value)}"
                };
            } 
        }

        public PdfViewer()
        {
            if (!IsHandlerSet)
            {
                WebViewHandler.Mapper.AppendToMapping("CustomWebView", (handler, view) =>
                {
                    if (view is PdfViewer)
                    {
#if ANDROID
                        handler.PlatformView.Settings.JavaScriptEnabled = true;
                        handler.PlatformView.Settings.BuiltInZoomControls = true;
                        handler.PlatformView.Settings.AllowContentAccess = true;
                        handler.PlatformView.Settings.AllowFileAccess = true;
                        handler.PlatformView.Settings.AllowFileAccessFromFileURLs = true;
                        handler.PlatformView.Settings.AllowUniversalAccessFromFileURLs = true;
#endif
                    }
                });

                IsHandlerSet = true;
            }
        }
    }
}
