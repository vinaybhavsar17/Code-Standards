using OfficerReports.Resources.Strings;
using OfficerReports.Views;
using OfficerReports.Views.Site;

namespace OfficerReports.Controls;

public partial class NavigationBar : ContentView
{
    public event EventHandler BackButtonPressed;

	private string _backButtonSource = "arrow_back";
	public string BackButtonSource
	{
		get { return _backButtonSource; }
		set
		{
			_backButtonSource = value;
			OnPropertyChanged();
		}
	}

    private string _backButtonText;
	public string BackButtonText
	{
		get { return _backButtonText; }
		set
		{
			_backButtonText = value;
			OnPropertyChanged();
		}
	}

    private Thickness _leftButtonMargin = new Thickness(15, 0, 0, 0);
    public Thickness LeftButtonMargin
    {
        get { return _leftButtonMargin; }
        set
        {
            _leftButtonMargin = value;
            OnPropertyChanged();
        }
    }

    public static readonly BindableProperty IsBackButtonVisibleProperty = BindableProperty.Create(nameof(IsBackButtonVisible), typeof(bool), typeof(NavigationBar));

    public bool IsBackButtonVisible
    {
        get => (bool)GetValue(IsBackButtonVisibleProperty);
        set => SetValue(IsBackButtonVisibleProperty, value);
    }

    public static readonly BindableProperty ShowLogoProperty = BindableProperty.Create(nameof(ShowLogo), typeof(bool), typeof(NavigationBar));

    public bool ShowLogo
    {
        get => (bool)GetValue(ShowLogoProperty);
        set => SetValue(ShowLogoProperty, value);
    }

    public static readonly BindableProperty HasShadowProperty = BindableProperty.Create(nameof(HasShadow), typeof(bool), typeof(NavigationBar));

    public bool HasShadow
    {
        get => (bool)GetValue(HasShadowProperty);
        set => SetValue(HasShadowProperty, value);
    }

    public NavigationBar()
	{
		InitializeComponent();

		BindingContext = this;

		if(App.Current.MainPage is NavigationPage np)
        {
			var navStack = np.Navigation.NavigationStack;
			var previousPage = navStack[navStack.Count - 1];
			if (previousPage is MenuView || previousPage is SiteMenuView)
			{
                BackButtonText = AppResource.Home;
            }
			else {
				
               BackButtonText = AppResource.Back;
            }
				
			
		}
	}

    private void BackButtonTapped(object sender, EventArgs e)
    {
        BackButtonPressed?.Invoke(this, new EventArgs());
    }
}