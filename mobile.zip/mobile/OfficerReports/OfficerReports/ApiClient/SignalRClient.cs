﻿using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using OfficerReports.Constants;
using OfficerReports.Interfaces;
using OfficerReports.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ApiClient
{
    public class SignalRClient : ISignalRClient
    {
        private HubConnection _hubConnection;

        public bool IsConnected =>
            _hubConnection?.State == HubConnectionState.Connected;

        public bool IsConnecting =>
            _hubConnection?.State == HubConnectionState.Connecting || _hubConnection?.State == HubConnectionState.Reconnecting;

        private bool _isStopped;

        public SignalRClient()
        {
            Connectivity.ConnectivityChanged += (s, e) =>
            {
                if (Helpers.NetworkUtility.IsInternetConnected)
                {
                    Reconnect();
                }
            };
        }

        public async void Connect(Action onConnect)
        {
            try
            {
                if (_hubConnection != null && (_hubConnection.State == HubConnectionState.Connected || 
                                               _hubConnection.State == HubConnectionState.Connecting || 
                                               _hubConnection.State == HubConnectionState.Reconnecting))
                    return;

                if(_hubConnection == null)
                {
                    _hubConnection = new HubConnectionBuilder()
                    .WithUrl(ApiConstants.BASE_URL + ApiConstants.SignalRNotify, options =>
                    {
                        options.SkipNegotiation = true;
                        options.Transports = Microsoft.AspNetCore.Http.Connections.HttpTransportType.WebSockets;
                    })
                    .WithAutomaticReconnect()
                    .Build();
                    _hubConnection.ServerTimeout = TimeSpan.FromMinutes(30);
                    _hubConnection.Closed += HubConnection_Closed;
                    _hubConnection.Reconnected += HubConnection_Reconnected;
                    _hubConnection.Reconnecting += HubConnection_Reconnecting;

                    RegisterListeners(_hubConnection);
                }

                if(!IsConnected)
                    await _hubConnection?.StartAsync();

                _isStopped = false;
                ShowToast("SignalR Connection Established");

                onConnect?.Invoke();
            }
            catch (Exception ex)
            {
                ShowToast("SignalR Connection Failed => " + ex.Message);
                App.Logger.LogError(ex.Message);
            }
        }

        private void RegisterListeners(HubConnection hubConnection)
        {
            hubConnection.On<string, string>(ApiConstants.SignalRMethod_ReceiveNew, (user, message) =>
            {
                MessagingCenter.Send<ISignalRClient, string>(this, AppConstants.MessageNewChat, message);
            });

            hubConnection.On<string, string>(ApiConstants.SignalRMethod_ReceiveMessage, (user, message) =>
            {
                MessagingCenter.Send<ISignalRClient, string>(this, AppConstants.MessageReceiveChat, message);

                ShowToast("SignalR Message Received");
            });
        }

        private void Reconnect()
        {
            Connect(null);
        }

        private Task HubConnection_Reconnected(string arg)
        {
            _isStopped = false;
            ShowToast("SignalR Reconnected => " + arg);
            return Task.CompletedTask;
        }

        private Task HubConnection_Reconnecting(Exception arg)
        {
            ShowToast("SignalR Reconnecting => " + arg.Message);
            return Task.CompletedTask;
        }

        private Task HubConnection_Closed(Exception arg)
        {
            _isStopped = true;
            ShowToast("SignalR Closed => " + arg?.Message);

            if (arg != null)
            {
                ShowToast("SignalR trying to reconnect => " + arg.Message);
                Reconnect();
            }

            return Task.CompletedTask;
        }

        public async void Disconnect()
        {
            try
            {
                if(!IsConnected)
                    return;

                await _hubConnection?.StopAsync();
                _hubConnection = null;
                _isStopped = true;

                ShowToast("SignalR Connection Stopped");
            }
            catch (Exception ex)
            {
                ShowToast("SignalR Connection stop failed => " + ex.Message);
                App.Logger.LogError(ex.Message);
            }
        }

        public async Task<bool> SendMessage(string methodName, object data, Action onSuccess = null)
        {
            var result = false;
            try
            {
                if (IsConnected)
                {
                    await _hubConnection?.InvokeAsync(methodName, data);

                    result = true;
                    ShowToast("SignalR Message Sent");

                    onSuccess?.Invoke();
                }
                else
                {
                    ShowToast("SignalR cannot send message because it's not connected");
                    Reconnect();
                }
            }
            catch (Exception ex)
            {
                ShowToast("SignalR Message sent failed => " + ex.Message);
                App.Logger.LogError(ex.Message);
            }

            return result;
        }

        public async void SendMessage(string methodName, string userName, object data)
        {
            try
            {
                if (IsConnected)
                {
                    await _hubConnection?.InvokeAsync(methodName, userName, data);

                    ShowToast("SignalR Message Sent");
                }
                else
                {
                    ShowToast("SignalR cannot send message because it's not connected");
                    Reconnect();
                }
            }
            catch (Exception ex)
            {
                ShowToast("SignalR Message sent failed => " + ex.Message);
                App.Logger.LogError(ex.Message);
            }
        }

        public async void SendMessage(string methodName, string data1, string data2)
        {
            try
            {
                if (IsConnected)
                {
                    await _hubConnection?.InvokeAsync(methodName, data1, data2);

                    ShowToast("SignalR Message Sent");
                }
                else
                {
                    ShowToast("SignalR cannot send message because it's not connected");
                    Reconnect();
                }
            }
            catch (Exception ex)
            {
                ShowToast("SignalR Message sent failed => " + ex.Message);
                App.Logger.LogError(ex.Message);
            }
        }

        public async Task SendMessage(string methodName, int userId, object data, Action onSuccess = null)
        {
            try
            {
                if (IsConnected)
                {
                    await _hubConnection?.InvokeAsync(methodName, userId, data);

                    ShowToast("SignalR Message Sent");

                    onSuccess?.Invoke();
                }
                else
                {
                    ShowToast("SignalR cannot send message because it's not connected");
                    Reconnect();
                }
            }
            catch (Exception ex)
            {
                ShowToast("SignalR Message sent failed => " + ex.Message);
                App.Logger.LogError(ex.Message);
            }
        }

        private void ShowToast(string text)
        {
#if DEBUG
            Console.WriteLine(text);
            //PlatformServices.ShowToast(text);
#endif
            AsotLogViewModel.AddLog(text);
        }
    }
}
