﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ApiClient
{
    public interface ISignalRClient
    {
        public bool IsConnecting { get; }

        public bool IsConnected { get; }

        public void Connect(Action onConnect);

        public void Disconnect();

        public Task<bool> SendMessage(string methodName, object data, Action onSuccess = null);

        public Task SendMessage(string methodName, int userId, object data, Action onSuccess = null);

        public void SendMessage(string methodName, string userName, object data);

        public void SendMessage(string methodName, string data1, string data2);
    }
}
