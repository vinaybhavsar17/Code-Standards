﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using OfficerReports.Constants;
using OfficerReports.Converters;
using OfficerReports.Helpers;
using OfficerReports.Models.Authentication;
using OfficerReports.Resources.Strings;
using OfficerReports.ViewModels.Authentication;
using System.Net.Http.Headers;
using System.Text;

namespace OfficerReports.ApiClient
{
    public class RestApiClient : IRestApiClient
    {
        private HttpClient _client;
        private ILogger<RestApiClient> _logger;
        private JsonSerializerSettings _serializerSettings;

        public RestApiClient(ILogger<RestApiClient> logger)
        {
            _client = new HttpClient
            {
                BaseAddress = new Uri(ApiConstants.BASE_URL),
                Timeout = TimeSpan.FromSeconds(30)
            };

            _serializerSettings = new JsonSerializerSettings();
            //Currently this is not working in MAUI but it works fine in xamarin forms. It actually convertes UTC date time to local date time at the time of parsing the json.
            //Since it is not working as of now, so temporarily we have also converted to local time in Model classes. But in future, we should remove local time conversion from all model classes and use this one.
            _serializerSettings.Converters.Add(new LocalDateTimeConverter());

            _logger = logger;

            MessagingCenter.Subscribe<MimicViewModel, MimicData>(this, AppConstants.MessageMimicStart, (sender, mimicData) =>
            {
                MimicDataManager.MimicData = mimicData;

                _client = new HttpClient
                {
                    BaseAddress = new Uri(mimicData.MimicUrl),
                    Timeout = TimeSpan.FromSeconds(30)
                };
            });

            MessagingCenter.Subscribe<App>(this, AppConstants.MessageMimicStop, (sender) =>
            {
                MimicDataManager.MimicData = null;

                _client = new HttpClient
                {
                    BaseAddress = new Uri(ApiConstants.BASE_URL),
                    Timeout = TimeSpan.FromSeconds(30)
                };
            });
        }

        public async Task<TResponse> Get<TResponse>(string url, string token = null, CancellationToken cancellationToken = default)
        {
            _logger.LogInformation($"URL: {url}");
            TResponse response = default(TResponse);

            try
            {
                response = await Connect<TResponse>(
                    client: _client,
                    httpClientMethod: async () => await _client.GetAsync(url, cancellationToken),
                    token: token
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }

            return response;
        }

        public async Task<TResponse> Post<TRequest, TResponse>(string url, TRequest request, string token = null, CancellationToken cancellationToken = default)
        {
            TResponse response = default(TResponse);

            try
            {
                _logger.LogInformation($"URL: {url}");

                var json = JsonConvert.SerializeObject(request);
                _logger.LogInformation($"Request Body:\n{json}");

                var content = new StringContent(json, Encoding.UTF8, "application/json");

                response = await Connect<TResponse>(
                    client: _client,
                    httpClientMethod: async () => await _client.PostAsync(url, content, cancellationToken),
                    token: token
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            

            return response;
        }

        public async Task<TResponse> PostWithNewClient<TRequest, TResponse>(string baseUrl, string endpoint, TRequest request, string token = null, CancellationToken cancellationToken = default)
        {
            TResponse response = default(TResponse);

            try
            {
                _logger.LogInformation($"URL: {endpoint}");

                var json = JsonConvert.SerializeObject(request);
                _logger.LogInformation($"Request Body:\n{json}");

                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var client = new HttpClient
                {
                    BaseAddress = new Uri(baseUrl),
                    Timeout = TimeSpan.FromSeconds(30)
                };
                response = await Connect<TResponse>(
                    client: client,
                    httpClientMethod: async () => await client.PostAsync(endpoint, content, cancellationToken),
                    token: token
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }


            return response;
        }

        public Task<TResponse> Put<TRequest, TResponse>(string url, TRequest request, string token = null, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<TResponse> Delete<TResponse>(string url, string token = null, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        private bool AddAuthenticationHeader(HttpClient client, string token)
        {
            var isTokenAvailable = false;

            if (string.IsNullOrEmpty(token))
                token = AuthTokenManager.Token;

            if (!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                isTokenAvailable = true;
                _logger.LogInformation($"Token:\n{token}");
            }

            return isTokenAvailable;
        }

        private async Task<TResponse> Connect<TResponse>(HttpClient client, Func<Task<HttpResponseMessage>> httpClientMethod, string token)
        {
            TResponse response = default(TResponse);

            if (!NetworkUtility.IsInternetConnected)
            {
                var param = new object[] { AppResource.Internet_Not_Available };
                response = (TResponse)Activator.CreateInstance(typeof(TResponse), param);

                return response;
            }

            try
            {
                var isTokenAdded = AddAuthenticationHeader(client, token);

                HttpResponseMessage result = await httpClientMethod();

                _logger.LogInformation($"Response: {result.StatusCode} {result.ReasonPhrase}");

                var responseString = await result.Content.ReadAsStringAsync();

                _logger.LogInformation($"Response Body:\n{responseString}");

                if (isTokenAdded && 
                    result.StatusCode == System.Net.HttpStatusCode.Unauthorized &&
                    string.IsNullOrEmpty(responseString))
                {
                    //Creating and returning a response object indicating unauthorized response. In this case, view model layer will redirect to login page.
                    var param = new object[] { true };
                    response = (TResponse)Activator.CreateInstance(typeof(TResponse), param);
                    return response;
                }

                response = JsonConvert.DeserializeObject<TResponse>(responseString, _serializerSettings);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);

                var param = new object[] { $"{AppResource.Server_Error} \n\n {ex.Message}" };
                response = (TResponse)Activator.CreateInstance(typeof(TResponse), param);
            }

            if(response == null)
            {
                var param = new object[] { AppResource.Server_Error };
                response = (TResponse)Activator.CreateInstance(typeof(TResponse), param);
            }

            return response;
        }

        public async Task<byte[]> DownloadData(string url, string token = default, CancellationToken cancellationToken = default)
        {
            var data = default(byte[]);
            try
            {
                var httpClient = new HttpClient();
                var result = await httpClient.GetAsync(url, cancellationToken);

                if (result.IsSuccessStatusCode)
                {
                    data = await result.Content.ReadAsByteArrayAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }

            return data;
        }
    }
}
