﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.ApiClient
{
    public interface IRestApiClient
    {
        public Task<TResponse> Get<TResponse>(string url, string token = default, CancellationToken cancellationToken = default);

        public Task<TResponse> Post<TRequest, TResponse>(string url, TRequest request, string token = default, CancellationToken cancellationToken = default);

        public Task<TResponse> PostWithNewClient<TRequest, TResponse>(string baseUrl, string endpoint, TRequest request, string token = default, CancellationToken cancellationToken = default);

        public Task<TResponse> Put<TRequest, TResponse>(string url, TRequest request, string token = default, CancellationToken cancellationToken = default);

        public Task<TResponse> Delete<TResponse>(string url, string token = default, CancellationToken cancellationToken = default);

        public Task<byte[]> DownloadData(string url, string token = default, CancellationToken cancellationToken = default);
    }
}
