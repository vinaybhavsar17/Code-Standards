﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.SiteCheckReport
{
    public class CreateSiteCheckReport : ApiRequest
    {
        public int ClientSiteId { get; set; }
        public int ClientId { get; set; }
        public string Details { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new CreateSiteCheckReportDto
            {
                ClientId = ClientId,
                ClientSiteId = ClientSiteId,
                Details = Details,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class CreateSiteCheckReportDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public int ClientSiteId { get; set; }
        public int ClientId { get; set; }
        public string Details { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateSiteCheckReport
            {
                ClientId = ClientId,
                ClientSiteId = ClientSiteId,
                Details = Details,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }
}
