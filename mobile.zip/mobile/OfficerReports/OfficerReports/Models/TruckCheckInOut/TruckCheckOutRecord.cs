﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.TruckCheckInOut
{
    public class TruckCheckOutRecord : ApiData
    {
        public int TruckLogId { get; set; }
        public int? ClientSiteId { get; set; }
        public string Client { get; set; }
        public string Site { get; set; }
        public int InUserId { get; set; }
        public string? TractorNumber { get; set; }
        public string Company { get; set; }
        public string InDriver { get; set; }
        public string? InTrailerNumber { get; set; }
        public string? InSealNumber { get; set; }
        public string InNotes { get; set; }
        public DateTimeOffset InDate { get; set; }
        public object OutDriver { get; set; }
        public int? OutUserId { get; set; }
        public object OutTrailerNumber { get; set; }
        public object OutSealNumber { get; set; }
        public object OutNotes { get; set; }
        public DateTime? OutDate { get; set; }
        public long? IsOut { get; set; }
        public string? Lpnumber { get; set; }
        public string Vin { get; set; }
        public string? DockBayNumber { get; set; }
        public DateTimeOffset? CreatedDate { get; set; }
        public long? CreatedById { get; set; }
        public bool? IsDeleted { get; set; }
        public object DeletedDate { get; set; }
        public object DeletedById { get; set; }
        public object ModifiedDate { get; set; }
        public object ModifiedById { get; set; }

    }
}
