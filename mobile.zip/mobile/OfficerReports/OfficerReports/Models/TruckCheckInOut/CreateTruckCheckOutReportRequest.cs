﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.TruckCheckInOut
{
    public class CreateTruckCheckOutReportRequest : ApiRequest
    {
        public int ClientSiteId { get; set; }
        public int TruckLogId { get; set; }
        public string TractorNumber { get; set; }
        public string Company { get; set; }
        public string InDriver { get; set; }
        public string InTrailerNumber { get; set; }
        public string InSealNumber { get; set; }
        public string InNotes { get; set; }
        public string Lpnumber { get; set; }
        public string Vin { get; set; }
        public string DockBayNumber { get; set; }
        public string OutDriver { get; set; }
        public string OutSealNumber { get; set; }
        public string OutTrailerNumber { get; set; }
        public string OutNotes { get; set; }
        public int IsOut { get; set; }
        public DateTimeOffset InDate { get; set; }
        public int InUserId { get; set; }
        public int UserId { get; set; }
        public int OutUserId { get; set; }
        public object OutDate { get; set; }
    }
}