﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.TruckCheckInOut
{
    public class CreateTruckCheckInReportRequest : ApiRequest
    {
        public int ClientSiteId { get; set; }
        public string TractorNumber { get; set; }
        public string Company { get; set; }
        public string InDriver { get; set; }
        public string InTrailerNumber { get; set; }
        public string InSealNumber { get; set; }
        public string InNotes { get; set; }
        public string Lpnumber { get; set; }
        public string Vin { get; set; }
        public string DockBayNumber { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new CreateTruckCheckInReportRequestDto
            {
                ClientSiteId = ClientSiteId,
                Company = Company,
                DockBayNumber = DockBayNumber,
                InDriver = InDriver,
                InNotes = InNotes,
                InSealNumber = InSealNumber,
                InTrailerNumber = InTrailerNumber,
                Lpnumber = Lpnumber,
                TractorNumber = TractorNumber,
                Vin = Vin,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class CreateTruckCheckInReportRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public int ClientSiteId { get; set; }
        public string TractorNumber { get; set; }
        public string Company { get; set; }
        public string InDriver { get; set; }
        public string InTrailerNumber { get; set; }
        public string InSealNumber { get; set; }
        public string InNotes { get; set; }
        public string Lpnumber { get; set; }
        public string Vin { get; set; }
        public string DockBayNumber { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateTruckCheckInReportRequest
            {
                ClientSiteId = ClientSiteId,
                Company = Company,
                DockBayNumber = DockBayNumber,
                InDriver = InDriver,
                InNotes = InNotes,
                InSealNumber = InSealNumber,
                InTrailerNumber = InTrailerNumber,
                Lpnumber = Lpnumber,
                TractorNumber = TractorNumber,
                Vin = Vin,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }
}