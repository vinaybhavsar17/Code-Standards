﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Chat
{
    public class UnreadMessageCount : ApiData
    {
        private int _unreadMessagesCount;
        public int UnreadMessagesCount
        {
            get
            {
                return _unreadMessagesCount;
            }
            set
            {
                _unreadMessagesCount = value;
                RaisePropertyChanged(() => UnreadMessagesCount);
            }
        }

        private int _officerUnreadMessagesCount;
        public int OfficerUnreadMessagesCount
        {
            get
            {
                return _officerUnreadMessagesCount;
            }
            set
            {
                _officerUnreadMessagesCount = value;
                RaisePropertyChanged(() => OfficerUnreadMessagesCount);
            }
        }

        private int _siteUnreadMessagesCount;
        public int SiteUnreadMessagesCount
        {
            get
            {
                return _siteUnreadMessagesCount;
            }
            set
            {
                _siteUnreadMessagesCount = value;
                RaisePropertyChanged(() => SiteUnreadMessagesCount);
            }
        }

        public List<GroupMessageCount> GroupMessagesCount { get; set; }

    }

    public class GroupMessageCount
    {
        public int GroupId { get; set; }
        public int Count { get; set; }
    }
}
