﻿using System;
using Realms;

namespace OfficerReports.Models.Chat
{
	public class MessageDto : RealmObject
	{
        [PrimaryKey]
        public Guid Id { get; set; }
        public string User { get; set; }
        public string MsgText { get; set; }
        public string GroupName { get; set; }
        public int GroupId { get; set; }
        public int CustomerId { get; set; }
        public int UserId { get; set; }

        public MessageDto Copy()
        {
            return new MessageDto
            {
                Id = Id,
                User = User,
                MsgText = MsgText,
                GroupName = GroupName,
                GroupId = GroupId,
                CustomerId = CustomerId,
                UserId = UserId
            };
        }

        public object ToDynamic()
        {
            return new
            {
                user = User,
                msgText = MsgText,
                groupName = GroupName,
                groupId = GroupId,
                customerId = CustomerId,
                userId = UserId
            };
        }

        public Message ToMessage()
        {
            return new Message(MsgText);
        }
    }
}

