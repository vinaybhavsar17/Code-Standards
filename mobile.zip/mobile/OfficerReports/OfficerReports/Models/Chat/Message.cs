﻿using Newtonsoft.Json;
using OfficerReports.Converters;
using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static OfficerReports.Models.Chat.Message;

namespace OfficerReports.Models.Chat
{
    public class Message
    {
        private static JsonSerializerSettings _deserializerSettings;

        public Message()
        {
            if(_deserializerSettings == null)
            {
                _deserializerSettings = new JsonSerializerSettings();
                //_deserializerSettings.Converters.Add(new LocalDateTimeConverter());
            }
        }

        public Message(string message) : base()
        {
            ConvertStringToMessageContent(message);
            CreatedDate = MessageContent.DateTime;
        }

        public Message(MessageContent messageContent) : base()
        {
            _messageContent = messageContent;
            ConvertMessageContentToString(messageContent);
        }

        public int MessageId { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsRead { get; set; }
        public string MessageLine { get; set; }

        private MessageContent _messageContent;
        [JsonIgnore]
        public MessageContent MessageContent { 
            get
            {
                if(_messageContent == null)
                {
                    ConvertStringToMessageContent(MessageLine);
                }
                return _messageContent;
            }
        }

        private void ConvertStringToMessageContent(string messageLine)
        {
            try
            {
                _messageContent = JsonConvert.DeserializeObject<MessageContent>(messageLine, _deserializerSettings);                
                _messageContent.Type = MessageContent.MessageType.Chat;

                string htmlMessage;
                _messageContent.Images = ExtractImages(out htmlMessage, _messageContent);

                htmlMessage = RemoveUnwantedHtmlTags(htmlMessage);
                _messageContent.Message = AddLineBreaks(htmlMessage);

                if (_messageContent.Images != null && _messageContent.Images.Count > 0)
                    _messageContent.Images[0].ImageMessage = _messageContent.Message;
            }
            catch (Exception)
            {
                _messageContent = new MessageContent();
                _messageContent.Message = messageLine;
                _messageContent.Type = MessageContent.MessageType.Event;
                _messageContent.DateTime = CreatedDate.ToLocalTime();
            }
        }

        private string AddLineBreaks(string message)
        {
            return message?.Replace("\n", "<br>");
        }

        private string AddHtmlTags(string message)
        {
            var formattedMessage = message?.Replace("\n", "<br>");

            formattedMessage = Regex.Replace(formattedMessage, "\\/[^\\/].[^\\/]*[^\\/]\\/", (m) =>
            {
                var matchString = m.ToString();
                matchString = $"<i>{matchString.Substring(1, matchString.Length - 2)}</i>";

                return matchString;
            });

            formattedMessage = Regex.Replace(formattedMessage, "\\*[^*].[^*]*[^*]\\*", (m) =>
            {
                var matchString = m.ToString();
                matchString = $"<b>{matchString.Substring(1, matchString.Length - 2)}</b>";

                return matchString;
            });

            formattedMessage = Regex.Replace(formattedMessage, "_[^_].[^_]*[^_]_", (m) =>
            {
                var matchString = m.ToString();
                matchString = $"<u>{matchString.Substring(1, matchString.Length - 2)}</u>";

                return matchString;
            });

            return formattedMessage;
        }

        private void ConvertMessageContentToString(MessageContent messageContent)
        {
            try
            {
                //messageContent.Message = AddLineBreaks(messageContent.Message);
                messageContent.Message = AddHtmlTags(messageContent.Message);
                MessageLine = JsonConvert.SerializeObject(messageContent);
            }
            catch (Exception ex)
            {
            }
        }

        /**
         * This method is used teporarily, beause there is a known bug in Xamarin and MAUI, that
         * it adds extra space at the bottom if there's <p> or <div> tag in the html text. So here
         * we are removing these tags. But this method can be removed in future if this issues is resolved
         * by Microsoft - https://github.com/xamarin/Xamarin.Forms/issues/14134
         */
        private string RemoveUnwantedHtmlTags(string htmlText)
        {
            var formattedHtml = htmlText?.Replace("<p>", "")?.Replace("</p>", "<br>");
            int? lastBrIndex = -1;
            lastBrIndex = formattedHtml?.LastIndexOf("<br>");
            if (lastBrIndex > -1 && formattedHtml.Length == lastBrIndex + 4)
                formattedHtml = formattedHtml.Substring(0, (int)lastBrIndex);

            return formattedHtml;
        }

        private List<ImageContent> ExtractImages(out string outputMessage, MessageContent messageContent)
        {
            var htmlMessage = messageContent.Message;
            List<ImageContent> imgUrls = null;

            try
            {
                int i = 0;
                while (htmlMessage.IndexOf("<img") > -1)
                {
                    i++;

                    if (imgUrls == null)
                        imgUrls = new List<ImageContent>();

                    var imgOpenIndex = htmlMessage.IndexOf("<img");
                    var imgCloseIndex = htmlMessage.IndexOf("</img>", imgOpenIndex);
                    if (imgCloseIndex == -1)
                        imgCloseIndex = htmlMessage.IndexOf(">", imgOpenIndex);

                    var srcStartIndex = htmlMessage.IndexOf("src=", imgOpenIndex, imgCloseIndex - imgOpenIndex) + 5;
                    var srcEndIndex = htmlMessage.IndexOf("\"", srcStartIndex);
                    if (srcEndIndex == -1)
                        srcEndIndex = htmlMessage.IndexOf("'", srcStartIndex);

                    var imgUrl = htmlMessage.Substring(srcStartIndex, srcEndIndex - srcStartIndex);
                    var imgContent = new ImageContent
                    {
                        Image = ImageSource.FromUri(new Uri(imgUrl)),
                        FullName = messageContent.FullName,
                        DateTime = messageContent.DateTime
                    };

                    imgUrls.Add(imgContent);

                    htmlMessage = htmlMessage.Remove(imgOpenIndex, (imgCloseIndex - imgOpenIndex) + 1);
                }
            }
            catch (Exception)
            {
            }

            outputMessage = htmlMessage;
            return imgUrls;
        }
    }

    public class MessageContent : ViewModels.Base.ExtendedBindableObject
    {
        public enum MessageType
        {
            Chat,
            Event
        }

        [JsonProperty("groupId")]
        public int GroupId { get; set; }
        [JsonProperty("message")]
        public string Message { get; set; }
        [JsonProperty("userId")]
        public int UserId { get; set; }
        [JsonProperty("fullName")]
        public string FullName { get; set; }
        [JsonProperty("datetime")]
        public DateTime DateTime { get; set; }

        [JsonIgnore]
        public MessageType Type { get; set; }
        [JsonIgnore]
        public List<ImageContent> Images { get; set; }

        private bool _isOffline;
        [JsonIgnore]
        public bool IsOffline
        {
            get
            {
                return _isOffline;
            }

            set
            {
                _isOffline = value;
                RaisePropertyChanged(() => IsOffline);
            }
        }
    }

    public class ImageContent
    {
        public string ImageMessage { get; set; }
        public string FullName { get; set; }
        public DateTime DateTime { get; set; }
        public ImageSource Image { get; set; }
    }

    public class ChatMessagesResult : ApiData
    {
        public int Count { get; set; }
        public List<Message> Records { get; set; }
    }
}
