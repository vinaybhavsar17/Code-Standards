﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Chat
{
    public class ChatMessagesRequest : ApiRequest
    {
        public int GroupId { get; set; }
        public string CurrentTimeZone { get; set; }
        public Paging GridFilters { get; set; }
    }
}
