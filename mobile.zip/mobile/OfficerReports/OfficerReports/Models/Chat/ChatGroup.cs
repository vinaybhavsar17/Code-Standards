﻿using Newtonsoft.Json;
using OfficerReports.Models.Base;
using OfficerReports.ViewModels.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Chat
{
    public class ChatGroup : ExtendedBindableObject
    {
        public DateTime CreatedDate { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public string GroupDisplayName { get; set; }
        public int CustomerId { get; set; }
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public string Description { get; set; }
        public bool IsSiteGroup { get; set; }

        private int _msgCount;
        public int Msgcount {
            get 
            {
                return _msgCount;
            }
            set 
            {
                _msgCount = value;
                RaisePropertyChanged(() => Msgcount);
            }
        }
    }

    public class ChatGroupsResult : ApiData
    {
        public int Count { get; set; }
        public List<ChatGroup> Records { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new ChatGroupsResultDto
            {
                 Count = Count,
                 Records = JsonConvert.SerializeObject(Records)
            };
        }
    }

    public class ChatGroupsResultDto : RealmObject, IApiData
    {
        public enum ChatGroupType
        {
            OfficerGroup,
            SiteGroup
        }
        public int Count { get; set; }
        public string Records { get; set; }
        public int UserId { get; set; }
        public ChatGroupType GroupType {
            get { return (ChatGroupType)ChatGroupTypeId; }
            set { ChatGroupTypeId = (int)value; }
        }
        public int ChatGroupTypeId { get; set; }

        public ApiData ToApiObject()
        {
            return new ChatGroupsResult
            {
                Count = Count,
                Records = JsonConvert.DeserializeObject<List<ChatGroup>>(Records)
            };
        }
    }
}
