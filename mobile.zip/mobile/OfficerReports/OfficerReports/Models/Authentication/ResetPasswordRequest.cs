﻿using System;
using OfficerReports.Models.Base;

namespace OfficerReports.Models.Authentication
{
	public class ResetPasswordRequest : ApiRequest
	{
		public string ConfirmPassword { get; set; }

		public string OldPassword { get; set; }

		public string Password { get; set; }

		public string UserName { get; set; }
	}
}

