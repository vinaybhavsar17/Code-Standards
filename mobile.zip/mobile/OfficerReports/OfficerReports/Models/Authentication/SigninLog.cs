﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Authentication
{
    public class SigninLog : ApiRequest
    {
        public int ClientSiteId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public bool IsSignin { get; set; }
        public bool IsTourTracker { get; set; }
        public string TourTrackerVersion { get; set; }
        public string DeviceType { get; set; }
        public string DeviceInfo { get; set; }
    }
}
