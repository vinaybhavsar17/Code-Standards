﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Authentication
{
    public class MimicData
    {
        public string MimicUrl { get; set; }
        public string MimicUserName { get; set; }
        public string MimicLatitude { get; set; }
        public string MimicLongitude { get; set; }
    }
}
