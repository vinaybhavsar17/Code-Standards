﻿using Newtonsoft.Json;
using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Authentication
{
    public class LoginRequest : ApiRequest
    {
        [JsonProperty("userName")]
        public string Username { get; set; } = string.Empty;

        [JsonProperty("password")]
        public string Password { get; set; } = string.Empty;

        [JsonProperty("deviceType")]
        public string DeviceType { get; set; } = string.Empty;

        [JsonProperty("browserInfo")]
        public string BrowserInfo { get; set; } = string.Empty;

        [JsonProperty("signInApp")]
        public bool SignInApp { get; set; }

        [JsonProperty("appVersion")]
        public string AppVersion { get; set; } = string.Empty;

        [JsonProperty("deviceInfo")]
        public string DeviceInfo { get; set; } = string.Empty;

        public string IpAddress { get; set; }

        public double? Latitude { get; set; }

        public double? Longitude { get; set; }


    }
}
