﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Authentication
{
    public class SasToken : ApiData
    {
        public string Container { get; set; }
        public string StorageAccessToken { get; set; }
        public string StorageUri { get; set; }
    }
}
