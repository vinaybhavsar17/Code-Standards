﻿using Newtonsoft.Json;
using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Authentication
{
    public class User : ApiData
    {
        public const string AdminRole = "Admin";
        public const string CustomerRole = "Customer Admin";
        public const string SupervisorRole = "Supervisor";
        public const string SiteUserRole = "Site User";
        public const string ClientUserRole = "Client User";
        public const string OfficerRole = "Officer";
        public const string ARManagerRole = "ARManager";
        public const string CcrRole = "CCR";

        [JsonProperty("userId")]
        public int UserId { get; set; }

        [JsonProperty("userName")]
        public string UserName { get; set; }

        [JsonProperty("userFullName")]
        public string FullName { get; set; }

        [JsonProperty("userRoleId")]
        public int RoleId { get; set; }

        [JsonProperty("userRoleName")]
        public string RoleName { get; set; }

        [JsonProperty("customerId")]
        public int? CustomerId { get; set; }

        [JsonProperty("clientId")]
        public object ClientId { get; set; }

        [JsonProperty("clientSiteId")]
        public object ClientSiteId { get; set; }

        [JsonProperty("isActive")]
        public bool IsActive { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("hasAdminAccess")]
        public bool HasAdminAccess { get; set; }

        [JsonProperty("hasAccessOfficerPortal")]
        public bool HasAccessOfficerPortal { get; set; }

        [JsonProperty("hasAccessCustomerPortal")]
        public bool HasAccessCustomerPortal { get; set; }

        [JsonProperty("isBackend")]
        public bool IsBackend { get; set; }

        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("result")]
        public string Result { get; set; }

        [JsonProperty("phone")]
        public string Phone { get; set; }

        [JsonProperty("themeEnabled")]
        public bool ThemeEnabled { get; set; }

        [JsonProperty("themeUrlPrefix")]
        public string ThemeUrlPrefix { get; set; }

        [JsonProperty("themeJson")]
        public string ThemeJson { get; set; }

        [JsonProperty("themeLogo")]
        public string ThemeLogo { get; set; }

        [JsonProperty("mobilePetrolEnabled")]
        public bool MobilePetrolEnabled { get; set; }

        public bool TourTrackingEnabled { get; set; }

    }
}
