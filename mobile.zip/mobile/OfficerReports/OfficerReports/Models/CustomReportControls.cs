﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models
{
    public class CustomReportControls
    {
        [JsonProperty("section_title")]
        public List<Section> Sections { get; set; }
    }

    public class Section
    {
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("skills")]
        public List<Field> Fields { get; set; }
    }

    public class Field
    {
        [JsonProperty("fieldValue")]
        public string FieldValue { get; set; }
        [JsonProperty("displayName")]
        public string DisplayName { get; set; }
        [JsonProperty("fieldType")]
        public string FieldType { get; set; }
        [JsonProperty("defaultValue")]
        public object DefaultValue { get; set; }
        [JsonProperty("isMandatory")]
        public bool IsMandatory { get; set; }
        [JsonProperty("date")]
        public string Date { get; set; }
        [JsonProperty("image")]
        public string ImageUrl { get; set; }
        [JsonProperty("numberOfCheck")]
        public int NumberOfCheck { get; set; }
        [JsonProperty("checkBoxes")]
        public List<CheckboxField> CheckBoxes { get; set; }
    }

    public class CheckboxField
    {
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("value")]
        public bool Value { get; set; }
    }
}
