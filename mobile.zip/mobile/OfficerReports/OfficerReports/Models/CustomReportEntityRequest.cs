﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models
{
    public class CustomReportEntityRequest : EntityRequest
    {
        public int CustomReportDataId { get; set; }
        public int CustomReportId { get; set; }
        public List<CustomReportEntityMedia> CustomReportAttachmentDataModel { get; set; }

        public override int EntityId => CustomReportDataId;
        public override int EntityTypeId => CustomReportId;
    }

    public class CustomReportEntityMedia : EntityFile
    {
        public string Description { get; set; }
        public string OriginalName { get; set; }
        public int CustomReportAttachmentId { get; set; }

        public override string EntityFileName => OriginalName;
    }
}
