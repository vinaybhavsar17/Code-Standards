﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.VisitorCheckInOut
{
    public class CreateVisitorCheckInOutRequest : ApiRequest
    {
        public int VisitorLogId { get; set; }
        public int VisitorIdTypeId { get; set; }
        public string VisitorIdTypeName { get; set; }
        public int ClientSiteId { get; set; }
        public int ClientId { get; set; }
        public int CustomerId { get; set; }
        public int UserId { get; set; }
        public string VisitorIdOther { get; set; }
        public string VisitorName { get; set; }
        public string Destination { get; set; }
        public string Company { get; set; }
        public int InUserId { get; set; }
        public string InNotes { get; set; }
        public DateTimeOffset InDate { get; set; }
        public int OutUserId { get; set; }
        public string OutNotes { get; set; }
        public object OutDate { get; set; }
        public int IsOut { get; set; }
        public string Lpnumber { get; set; }
        public string BadgeNumber { get; set; }
        public string Temperature { get; set; }
        public string FaceCovering { get; set; }
        public int CreatedById { get; set; }
        public string CreatedBy { get; set; }
        public DateTimeOffset DateEntered { get; set; }
        public DateTimeOffset SubmissionDate { get; set; }
        public bool IsDeleted { get; set; }

    }
}

