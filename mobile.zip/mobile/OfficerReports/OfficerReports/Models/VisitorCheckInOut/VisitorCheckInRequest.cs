﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.VisitorCheckInOut
{
    public class VisitorCheckInRequest : ApiRequest
    {
        public int VisitorIdTypeId { get; set; }
        public int ClientSiteId { get; set; }
        public string VisitorIdOther { get; set; }
        public string VisitorName { get; set; }
        public string Destination { get; set; }
        public string Company { get; set; }
        public string InNotes { get; set; }
        public string Lpnumber { get; set; }
        public string BadgeNumber { get; set; }
        public string Temperature { get; set; }
        public string FaceCovering { get; set; }
        public string UserId { get; set; }
        public string CreatedById { get; set; }
        public string InUserId { get; set; }
        public int OutUserId { get; set; }
        public int IsOut { get; set; }
        public string CreatedDate { get; set; }
        public string InDate { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new VisitorCheckInRequestDto
            {
                BadgeNumber = BadgeNumber,
                ClientSiteId = ClientSiteId,
                Company = Company,
                CreatedById = CreatedById,
                CreatedDate = CreatedDate,
                Destination = Destination,
                FaceCovering = FaceCovering,
                InDate = InDate,
                InNotes = InNotes,
                InUserId = InUserId,
                IsOut =  IsOut,
                Lpnumber = Lpnumber,
                OutUserId = OutUserId,
                Temperature = Temperature,
                UserId = UserId,
                VisitorIdOther = VisitorIdOther,
                VisitorIdTypeId = VisitorIdTypeId,
                VisitorName = VisitorName,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class VisitorCheckInRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public int VisitorIdTypeId { get; set; }
        public int ClientSiteId { get; set; }
        public string VisitorIdOther { get; set; }
        public string VisitorName { get; set; }
        public string Destination { get; set; }
        public string Company { get; set; }
        public string InNotes { get; set; }
        public string Lpnumber { get; set; }
        public string BadgeNumber { get; set; }
        public string Temperature { get; set; }
        public string FaceCovering { get; set; }
        public string UserId { get; set; }
        public string CreatedById { get; set; }
        public string InUserId { get; set; }
        public int OutUserId { get; set; }
        public int IsOut { get; set; }
        public string CreatedDate { get; set; }
        public string InDate { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new VisitorCheckInRequest
            {
                BadgeNumber = BadgeNumber,
                ClientSiteId = ClientSiteId,
                Company = Company,
                CreatedById = CreatedById,
                CreatedDate = CreatedDate,
                Destination = Destination,
                FaceCovering = FaceCovering,
                InDate = InDate,
                InNotes = InNotes,
                InUserId = InUserId,
                IsOut = IsOut,
                Lpnumber = Lpnumber,
                OutUserId = OutUserId,
                Temperature = Temperature,
                UserId = UserId,
                VisitorIdOther = VisitorIdOther,
                VisitorIdTypeId = VisitorIdTypeId,
                VisitorName = VisitorName,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }
}
