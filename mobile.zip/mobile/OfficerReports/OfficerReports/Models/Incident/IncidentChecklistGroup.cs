﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Incident
{
    public class IncidentChecklistGroup : List<string>
    {
        public int IncidentChecklistId { get; set; }

        public string IncidentType { get; set; }

        public IncidentChecklistGroup()
        {

        }

        public IncidentChecklistGroup(IEnumerable<string> collection) : base(collection)
        {

        }
    }
}
