﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Incident
{
    public class IncidentCheck : ApiData
    {
        public int IncidentChecklistId { get; set; }
        public string IncidentType { get; set; }
        public string StepJson { get; set; }
    }
}
