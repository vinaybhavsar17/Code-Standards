﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Incident
{
    public class IncidentType : ApiData
    {
        public List<IncidentTypeItem> Data { get; set; }
    }

    public class IncidentTypeItem {
        public int TypeDataId { get; set; }
        public string TypeDataName { get; set; }
        public int SortOrder { get; set; }
    }
}
