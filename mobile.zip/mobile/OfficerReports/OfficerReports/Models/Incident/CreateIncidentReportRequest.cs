﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Incident
{
    public class CreateIncidentReportRequest : ApiRequest
    {
        public string IncidentTypeId { get; set; }
        public string OfficerId { get; set; }
        public string ClientSiteId { get; set; }
        public string IncidentReportNumber { get; set; }
        public string IncidentDate { get; set; }
        public string IncidentOtherType { get; set; }
        public string VictimName { get; set; }
        public string SuspectNames { get; set; }
        public string IncidentLocation { get; set; }
        public string IncidentSummary { get; set; }
        public string PoliceCalled { get; set; }
        public string WhyPoliceNotCalled { get; set; }
        public string PoliceInfo { get; set; }
        public string FireTruckNumber { get; set; }
        public string AmbulanceNumber { get; set; }
        public string IncidentDetails { get; set; }
        public string OfficerActions { get; set; }
        public string WitnessNames { get; set; }
        public string WitnessContactInfo { get; set; }
        public string VictimContactInfo { get; set; }
        public string SuspectContactInfo { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new CreateIncidentReportRequestDto
            {
                AmbulanceNumber = AmbulanceNumber,
                ClientSiteId = ClientSiteId,
                FireTruckNumber = FireTruckNumber,
                IncidentDate = IncidentDate,
                IncidentDetails = IncidentDetails,
                IncidentLocation = IncidentLocation,
                IncidentOtherType = IncidentOtherType,
                IncidentReportNumber = IncidentReportNumber,
                IncidentSummary = IncidentSummary,
                IncidentTypeId = IncidentTypeId,
                OfficerActions = OfficerActions,
                OfficerId = OfficerId,
                PoliceCalled = PoliceCalled,
                PoliceInfo = PoliceInfo,
                SuspectContactInfo = SuspectContactInfo,
                SuspectNames = SuspectNames,
                VictimContactInfo = VictimContactInfo,
                VictimName = VictimName,
                WhyPoliceNotCalled = WhyPoliceNotCalled,
                WitnessContactInfo = WitnessContactInfo,
                WitnessNames = WitnessNames,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class CreateIncidentReportRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public string IncidentTypeId { get; set; }
        public string OfficerId { get; set; }
        public string ClientSiteId { get; set; }
        public string IncidentReportNumber { get; set; }
        public string IncidentDate { get; set; }
        public string IncidentOtherType { get; set; }
        public string VictimName { get; set; }
        public string SuspectNames { get; set; }
        public string IncidentLocation { get; set; }
        public string IncidentSummary { get; set; }
        public string PoliceCalled { get; set; }
        public string WhyPoliceNotCalled { get; set; }
        public string PoliceInfo { get; set; }
        public string FireTruckNumber { get; set; }
        public string AmbulanceNumber { get; set; }
        public string IncidentDetails { get; set; }
        public string OfficerActions { get; set; }
        public string WitnessNames { get; set; }
        public string WitnessContactInfo { get; set; }
        public string VictimContactInfo { get; set; }
        public string SuspectContactInfo { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateIncidentReportRequest
            {
                AmbulanceNumber = AmbulanceNumber,
                ClientSiteId = ClientSiteId,
                FireTruckNumber = FireTruckNumber,
                IncidentDate = IncidentDate,
                IncidentDetails = IncidentDetails,
                IncidentLocation = IncidentLocation,
                IncidentOtherType = IncidentOtherType,
                IncidentReportNumber = IncidentReportNumber,
                IncidentSummary = IncidentSummary,
                IncidentTypeId = IncidentTypeId,
                OfficerActions = OfficerActions,
                OfficerId = OfficerId,
                PoliceCalled = PoliceCalled,
                PoliceInfo = PoliceInfo,
                SuspectContactInfo = SuspectContactInfo,
                SuspectNames = SuspectNames,
                VictimContactInfo = VictimContactInfo,
                VictimName = VictimName,
                WhyPoliceNotCalled = WhyPoliceNotCalled,
                WitnessContactInfo = WitnessContactInfo,
                WitnessNames = WitnessNames,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }
}
