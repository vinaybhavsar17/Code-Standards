﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.PassOnLog
{
    public class CreatePassOnLogReportRequest : ApiRequest
    {
        public int ClientSiteId { get; set; }
        public string PostShift { get; set; }
        public string Note { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new CreatePassOnLogReportRequestDto
            {
                ClientSiteId = ClientSiteId,
                PostShift = PostShift,
                Note = Note,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class CreatePassOnLogReportRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public int ClientSiteId { get; set; }
        public string PostShift { get; set; }
        public string Note { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreatePassOnLogReportRequest
            {
                ClientSiteId = ClientSiteId,
                PostShift = PostShift,
                Note = Note,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class ChangeReadStatusRequest : ApiRequest
    {
        public int PassOnLogId { get; set; }

    }

}
