﻿using Newtonsoft.Json;
using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.PassOnLog
{
    public class PassOnLogDetailRecord : ApiData
    {
        public int PassOnLogId { get; set; }
        public int UserId { get; set; }
        public int ClientSiteId { get; set; }
        public string PostShift { get; set; }
        public string Note { get; set; }
        public DateTime CreatedDate { get; set; }
        public int CreatedById { get; set; }
        public bool IsDeleted { get; set; }
        public object DeletedDate { get; set; }
        public object DeletedById { get; set; }
        public object LastUpdatedDate { get; set; }
        public object LastUpdatedById { get; set; }
        public bool IsRead { get; set; }
        public List<Entity> Entities { get; set; }
        public object ReportLogo { get; set; }
        public string EnteredBy { get; set; }

        [JsonIgnore]
        public List<EntityFile> ProcessedEntities { get; set; }
    }

    public class Entity : ApiData
    {
        public List<EntityPhoto> ArrayEntityPhoto { get; set; }
        public List<EntityMedia> ArrayEntityMedia { get; set; }
        public List<object> ArrayEntityAttachment { get; set; }
        public List<object> ArrayEntityComments { get; set; }
    }
}
