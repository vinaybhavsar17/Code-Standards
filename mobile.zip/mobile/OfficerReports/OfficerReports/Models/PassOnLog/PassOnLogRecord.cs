﻿using OfficerReports.Constants;
using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.PassOnLog
{
    public class PassOnLogRecord : ApiData
    {
        public DateTime CreatedDate { get; set; }
        public DateTime SubmissionDate { get; set; }
        public string PostShift { get; set; }
        public string Note { get; set; }
        public string OfficerName { get; set; }
        public string SiteName { get; set; }
        public string ClientName { get; set; }

        private bool _isRead;
        public bool IsRead
        {
            get { return _isRead; }
            set
            {
                _isRead = value;
                RaisePropertyChanged(() => IsRead);
                RaisePropertyChanged(() => ReadStatus);
            }
        }

        public int ClientSiteId { get; set; }
        public int ClientId { get; set; }
        public int PassOnLogId { get; set; }
        public int UserId { get; set; }

        public string ReadStatus { get {
                return IsRead ? AppConstants.PassOnLogStatusRead : AppConstants.PassOnLogStatusUnRead;
            }
        }


    }
}