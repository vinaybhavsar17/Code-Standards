﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Models.Base;

namespace OfficerReports.Models.SOS
{
    public class SosAlertRequest : ApiRequest
    {
        public int ClientSiteId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
