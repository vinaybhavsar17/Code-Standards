﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Vacation
{
    public class CreateVacationRequest : ApiRequest
    {
        public string Phone { get; set; }

        public string EmailAddress { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

        public string Comments { get; set; }

        public string CurrentTimezone { get; set; }

        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");

        public override RealmObject ToRealmObject()
        {
            return new CreateVacationRequestDto
            {
                Comments = Comments,
                EmailAddress = EmailAddress,
                EndDate = EndDate,
                Phone = Phone,
                StartDate = StartDate,
                UserSubmissionDate = UserSubmissionDate,
                CurrentTimezone = CurrentTimezone
            };
        }
    }

    public class CreateVacationRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();

        public string Phone { get; set; }

        public string EmailAddress { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

        public string Comments { get; set; }

        public string CurrentTimezone { get; set; }

        public string UserSubmissionDate { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateVacationRequest
            {
                Comments = Comments,
                EmailAddress = EmailAddress,
                EndDate = EndDate,
                Phone = Phone,
                StartDate = StartDate,
                UserSubmissionDate = UserSubmissionDate,
                CurrentTimezone = CurrentTimezone
            };
        }
    }
}
