﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Vacation
{
    public class VacationRequest : ApiData
    {
        public const int STATUS_PENDING = 1;
        public const int STATUS_APPROVED = 2;
        public const int STATUS_REJECTED = 3;
        public const int STATUS_WITHDRAWN = 4;

        public string VacationRequestStatusName { get; set; }
        public int VacationRequestId { get; set; }
        public int VacationRequestStatusId { get; set; }

        private DateTime _submissionDate;
        public DateTime SubmissionDate { 
            get 
            { 
                return _submissionDate.ToLocalTime();
            }
            set 
            { 
                _submissionDate = value;
            } 
        }

        public int UserId { get; set; }
        public string Phone { get; set; }
        public string EmailAddress { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Comments { get; set; }
    }
}
