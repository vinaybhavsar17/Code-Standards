﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.FieldInspection
{
    public class CreateFieldInspectionRequest : ApiRequest
    {
        public string CustomerId { get; set; }
        public string ClientSiteId { get; set; }
        public string ClientId { get; set; }
        public string InspectedOfficerId { get; set; }
        public bool MeetClient { get; set; }
        public string MeetClientDescription { get; set; }
        public bool Darcompleted { get; set; }
        public string DarDescription { get; set; }
        public string OfficerPhoto { get; set; }
        public string VehiclePhoto { get; set; }
        public string Attachments { get; set; }
        public string OpenedDate { get; set; }
        public bool ProperUniform { get; set; }
        public string ProperUniformDescription { get; set; }
        public bool ValidLicenses { get; set; }
        public string ValidLicensesDescription { get; set; }
        public bool AdminQuestions { get; set; }
        public string AdminQuestionsDescription { get; set; }
        public bool KnowPostOrders { get; set; }
        public string KnowPostOrderDescription { get; set; }
        public string OpenedLatitude { get; set; }
        public string OpenedLongitude { get; set; }
        public string CreatedLatitude { get; set; }
        public string CreatedLongitude { get; set; }
        public string InspectedOfficer { get; set; }
        public string OtherInspectedOfficer { get; set; }
        public string UnderInfluence { get; set; }
        public bool IsProperGroomed { get; set; }
        public string ProperlyGroomed { get; set; }
        public string AdditionalComments { get; set; }
        public bool IsVehicleDocsPresent { get; set; }
        public string VehicleDocsPresent { get; set; }
        public bool IsVehicleServiceRequired { get; set; }
        public string VehicleServiceRequired { get; set; }
        public bool IsVehicleGoodCondition { get; set; }
        public string VehicleGoodCondition { get; set; }
        public bool IsAlert { get; set; }
        public string AlertDescription { get; set; }
        public bool IsDistracted { get; set; }
        public string DistractedDescription { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new CreateFieldInspectionRequestDto
            {
                CustomerId = CustomerId,
                AdditionalComments = AdditionalComments,
                AdminQuestions = AdminQuestions,
                AdminQuestionsDescription = AdminQuestionsDescription,
                AlertDescription = AlertDescription,
                Attachments = Attachments,
                ClientId = ClientId,
                ClientSiteId = ClientSiteId,
                CreatedLatitude = CreatedLatitude,
                CreatedLongitude = CreatedLongitude,
                Darcompleted = Darcompleted,
                DarDescription = DarDescription,
                DistractedDescription = DistractedDescription,
                InspectedOfficer = InspectedOfficer,
                InspectedOfficerId = InspectedOfficerId,
                IsAlert = IsAlert,
                IsDistracted = IsDistracted,
                IsProperGroomed = IsProperGroomed,
                IsVehicleDocsPresent = IsVehicleDocsPresent,
                IsVehicleGoodCondition = IsVehicleGoodCondition,
                IsVehicleServiceRequired = IsVehicleServiceRequired,
                KnowPostOrderDescription = KnowPostOrderDescription,
                KnowPostOrders = KnowPostOrders,
                MeetClient = MeetClient,
                MeetClientDescription = MeetClientDescription,
                OfficerPhoto = OfficerPhoto,
                OpenedDate = OpenedDate,
                OpenedLatitude = OpenedLatitude,
                OpenedLongitude = OpenedLongitude,
                OtherInspectedOfficer = OtherInspectedOfficer,
                ProperlyGroomed = ProperlyGroomed,
                ProperUniform = ProperUniform,
                ProperUniformDescription = ProperUniformDescription,
                UnderInfluence = UnderInfluence,
                ValidLicenses = ValidLicenses,
                ValidLicensesDescription = ValidLicensesDescription,
                VehicleDocsPresent = VehicleDocsPresent,
                VehicleGoodCondition = VehicleGoodCondition,
                VehiclePhoto = VehiclePhoto,
                VehicleServiceRequired = VehicleServiceRequired,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }

    }

    public class CreateFieldInspectionRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public string CustomerId { get; set; }
        public string ClientSiteId { get; set; }
        public string ClientId { get; set; }
        public string InspectedOfficerId { get; set; }
        public bool MeetClient { get; set; }
        public string MeetClientDescription { get; set; }
        public bool Darcompleted { get; set; }
        public string DarDescription { get; set; }
        public string OfficerPhoto { get; set; }
        public string VehiclePhoto { get; set; }
        public string Attachments { get; set; }
        public string OpenedDate { get; set; }
        public bool ProperUniform { get; set; }
        public string ProperUniformDescription { get; set; }
        public bool ValidLicenses { get; set; }
        public string ValidLicensesDescription { get; set; }
        public bool AdminQuestions { get; set; }
        public string AdminQuestionsDescription { get; set; }
        public bool KnowPostOrders { get; set; }
        public string KnowPostOrderDescription { get; set; }
        public string OpenedLatitude { get; set; }
        public string OpenedLongitude { get; set; }
        public string CreatedLatitude { get; set; }
        public string CreatedLongitude { get; set; }
        public string InspectedOfficer { get; set; }
        public string OtherInspectedOfficer { get; set; }
        public string UnderInfluence { get; set; }
        public bool IsProperGroomed { get; set; }
        public string ProperlyGroomed { get; set; }
        public string AdditionalComments { get; set; }
        public bool IsVehicleDocsPresent { get; set; }
        public string VehicleDocsPresent { get; set; }
        public bool IsVehicleServiceRequired { get; set; }
        public string VehicleServiceRequired { get; set; }
        public bool IsVehicleGoodCondition { get; set; }
        public string VehicleGoodCondition { get; set; }
        public bool IsAlert { get; set; }
        public string AlertDescription { get; set; }
        public bool IsDistracted { get; set; }
        public string DistractedDescription { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateFieldInspectionRequest
            {
                CustomerId = CustomerId,
                AdditionalComments = AdditionalComments,
                AdminQuestions = AdminQuestions,
                AdminQuestionsDescription = AdminQuestionsDescription,
                AlertDescription = AlertDescription,
                Attachments = Attachments,
                ClientId = ClientId,
                ClientSiteId = ClientSiteId,
                CreatedLatitude = CreatedLatitude,
                CreatedLongitude = CreatedLongitude,
                Darcompleted = Darcompleted,
                DarDescription = DarDescription,
                DistractedDescription = DistractedDescription,
                InspectedOfficer = InspectedOfficer,
                InspectedOfficerId = InspectedOfficerId,
                IsAlert = IsAlert,
                IsDistracted = IsDistracted,
                IsProperGroomed = IsProperGroomed,
                IsVehicleDocsPresent = IsVehicleDocsPresent,
                IsVehicleGoodCondition = IsVehicleGoodCondition,
                IsVehicleServiceRequired = IsVehicleServiceRequired,
                KnowPostOrderDescription = KnowPostOrderDescription,
                KnowPostOrders = KnowPostOrders,
                MeetClient = MeetClient,
                MeetClientDescription = MeetClientDescription,
                OfficerPhoto = OfficerPhoto,
                OpenedDate = OpenedDate,
                OpenedLatitude = OpenedLatitude,
                OpenedLongitude = OpenedLongitude,
                OtherInspectedOfficer = OtherInspectedOfficer,
                ProperlyGroomed = ProperlyGroomed,
                ProperUniform = ProperUniform,
                ProperUniformDescription = ProperUniformDescription,
                UnderInfluence = UnderInfluence,
                ValidLicenses = ValidLicenses,
                ValidLicensesDescription = ValidLicensesDescription,
                VehicleDocsPresent = VehicleDocsPresent,
                VehicleGoodCondition = VehicleGoodCondition,
                VehiclePhoto = VehiclePhoto,
                VehicleServiceRequired = VehicleServiceRequired,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }
}
