﻿using System;
using Realms;
using OfficerReports.Models.Base;

namespace OfficerReports.Models.Asot
{
    public class AsotRequest : ApiRequest
    {
        public int ClientSiteId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int AccuracyFeet { get; set; }
        public double BatteryPercentage { get; set; }
        public bool IsBatteryCharging { get; set; }
        public DateTime LiveDateTime { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public int UserId { get; set; }
        public string Accuracy { get; set; }
        public double AccurateWithin { get; set; }
        public bool IsSync { get; set; }
        public string DeviceId { get; set; }
        public string Colour { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new AsotRequestDto
            {
                Accuracy = Accuracy,
                IsSync = IsSync,
                AccuracyFeet = AccuracyFeet,
                AccurateWithin = AccurateWithin,
                BatteryPercentage = BatteryPercentage,
                ClientSiteId = ClientSiteId,
                Colour = Colour,
                DeviceId = DeviceId,
                FirstName = FirstName,
                IsBatteryCharging = IsBatteryCharging,
                LastName = LastName,
                Latitude = Latitude,
                Longitude = Longitude,
                LiveDateTime = LiveDateTime,
                UserId = UserId,
                UserName = UserName
            };
        }
    }

    public class AsotRequestDto : RealmObject, IApiRequest
    {
        public int ClientSiteId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int AccuracyFeet { get; set; }
        public double BatteryPercentage { get; set; }
        public bool IsBatteryCharging { get; set; }
        public DateTimeOffset LiveDateTime { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public int UserId { get; set; }
        public string Accuracy { get; set; }
        public double AccurateWithin { get; set; }
        public bool IsSync { get; set; }
        public string DeviceId { get; set; }
        public string Colour { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new AsotRequest
            {
                Accuracy = Accuracy,
                IsSync = IsSync,
                AccuracyFeet = AccuracyFeet,
                AccurateWithin = AccurateWithin,
                BatteryPercentage = BatteryPercentage,
                ClientSiteId = ClientSiteId,
                Colour = Colour,
                DeviceId = DeviceId,
                FirstName = FirstName,
                IsBatteryCharging = IsBatteryCharging,
                LastName = LastName,
                Latitude = Latitude,
                Longitude = Longitude,
                LiveDateTime = LiveDateTime.DateTime,
                UserId = UserId,
                UserName = UserName
            };
        }
    }
}

