﻿using System;
using OfficerReports.Models.Base;

namespace OfficerReports.Models.Scheduler
{
	public class ScheduleRequest : ApiRequest
    {
		public string CurrentTimeZone { get; set; }
		public int[] OfficersIdArray { get; set; }
	}
}

