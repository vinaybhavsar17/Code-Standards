﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using Newtonsoft.Json;
using OfficerReports.Models.Base;
using Syncfusion.Maui.Scheduler;

namespace OfficerReports.Models.Scheduler
{
	public class Schedule : ApiData
	{
        public object ScheduleId { get; set; }
        public int ClientSiteId { get; set; }
        public int CustomerId { get; set; }
        public string SiteName { get; set; }
        public string SiteColor { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string StartTimezone { get; set; }
        public string EndTimezone { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsAllDay { get; set; }
        public string RecurrenceRule { get; set; }
        [JsonIgnore]
        public object RecurrenceId { get; set; }
        public string RecurrenceException { get; set; }
        public int ParentScheduleId { get; set; }
        public bool HasEndDate { get; set; }
        public List<Officer> OfficerList { get; set; }

        [JsonIgnore]
        public TimeZoneInfo StartTimeZoneInfo
        {
            get
            {
                if (string.IsNullOrEmpty(StartTimezone))
                    return TimeZoneInfo.Local;
                else
                    return TimeZoneInfo.FindSystemTimeZoneById(StartTimezone);
            }
            set { }
        }
        [JsonIgnore]
        public TimeZoneInfo EndTimeZoneInfo
        {
            get
            {
                if (string.IsNullOrEmpty(EndTimezone))
                    return TimeZoneInfo.Local;
                else
                    return TimeZoneInfo.FindSystemTimeZoneById(EndTimezone);
            }
            set { }
        }
        [JsonIgnore]
        public Brush Background
        {
            get { return new SolidColorBrush(Color.FromArgb(SiteColor)); }
            set { }
        }
        [JsonIgnore]
        public ObservableCollection<DateTime> RecurrenceExceptions
        {
            get
            {
                try
                {
                    var exceptions = RecurrenceException.Split(",");
                    var list = Array.ConvertAll(exceptions, item => DateTime.Parse(item)).ToList();
                    return new ObservableCollection<DateTime>(list);
                }
                catch (Exception ex)
                {
                    return new ObservableCollection<DateTime>();
                }
            }
            set { }
        }
        [JsonIgnore]
        public string Notes
        {
            get
            {
                return $"Site: {SiteName} - {Title}";
            }
            set { }
        }
        [JsonIgnore]
        public string Rule
        {
            get
            {
                if (RecurrenceRule == null)
                    return RecurrenceRule;

                try
                {
                    var recurrenceRule = RecurrenceRule.Replace(" ", "");
                    SchedulerRecurrenceManager.ParseRRule(recurrenceRule, StartDate);
                    return recurrenceRule;
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
            set { }
        }
    }

    public class Officer
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }
}

