﻿using Newtonsoft.Json;
using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models
{
    public class EntityRequest : ApiRequest
    {
        public const int EntityTypeCustom = 1;
        public const int EntityTypeDailyActivityReport = 2;
        public const int EntityTypeIncidentReport = 3;
        public const int EntityTypeMaintenanceReport = 4;
        public const int EntityTypeParkingViolation = 5;
        public const int EntityTypeTemperatureLog = 6;
        public const int EntityTypeTruckLog = 7;
        public const int EntityTypeVisitorLog = 8;
        public const int EntityTypeCleryReport = 9;
        public const int EntityTypePassOnLog = 10;
        public const int EntityTypeInspectionReport = 11;
        public const int EntityTypeSiteCheckReport = 12;

        public virtual int EntityId { get; set; }
        public virtual int EntityTypeId { get; set; }
        public List<EntityMedia> EntityMedia { get; set; }
        public List<EntityPhoto> EntityPhoto { get; set; }
        public List<string> EntityComment { get; set; }
        public List<string> EntityAttachment { get; set; }
        public bool IsEdit { get; set; } = false;
    }

    public abstract class EntityFile
    {
        public string FileName { get; set; }
        public string FileType { get; set; }
        public string FileUrl { get; set; }
        public string UploadUrl { get; set; }
        public string RelatedSection { get; set; }
        public DateTime CreatedDate { get; set; }

        [JsonIgnore]
        public abstract string EntityFileName { get; }
    }

    public class EntityPhoto : EntityFile
    {
        public string PhotoOriginal { get; set; }
        public string PhotoDescription { get; set; }

        public override string EntityFileName => PhotoOriginal;
    }

    public class EntityMedia : EntityFile
    {
        public string AttachmentDescription { get; set; }
        public string OriginalFileName { get; set; }

        public override string EntityFileName => OriginalFileName;
    }
}
