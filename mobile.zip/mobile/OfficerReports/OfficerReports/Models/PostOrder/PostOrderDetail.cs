﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.PostOrder
{
    public class PostOrderDetail : ApiData
    {
        public int ClientSiteId { get; set; }
        public int ClientId { get; set; }
        public string Phone { get; set; }
        public string ClientContact { get; set; }
        public string Contact { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string MaintenanceContact { get; set; }
        public string MaintenancePhone { get; set; }
        public string PoliceContact { get; set; }
        public string PolicePhone { get; set; }
        public string TowingContact { get; set; }
        public string TowingPhone { get; set; }
        public string PostOrderComments { get; set; }
        public string PoFileName { get; set; }
        public string PoOriginalFileName { get; set; }
        public string? PoFileUrl { get; set; }
        public DateTime? PostOrderUpdateDate { get; set; }

    }
}