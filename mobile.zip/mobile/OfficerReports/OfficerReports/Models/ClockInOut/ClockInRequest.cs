﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ClockInOut
{
    public class ClockInRequest : ApiRequest
    {
        public int InClientSiteId { get; set; }
        public bool InHasLocationInfo { get; set; }
        public double InLatitude { get; set; }
        public double InLongitude { get; set; }
        public int InAccuracyFeet { get; set; }
        public int InDistanceFromSiteFeet { get; set; }
        public string InDeviceType { get; set; }
        public string InDeviceInfo { get; set; }
        public string Comment { get; set; }
        public string InComment { get; set; }
        public int InClockTypeId { get; set; }
        public DateTime? InDateLocal { get; set; }
        public DateTime? OutDateLocal { get; set; }
        public string CurrentTimeZone { get; set; }
    }
}
