﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ClockInOut
{
    public class ClockType : ApiData
    {
        public const int UNKNOWN = 1;
        public const int SHIFT = 2;
        public const int LUNCH = 3;
        public const int BREAK = 4;

        public int ClockTypeId { get; set; }

        public string ClockTypeName { get; set; }
    }
}
