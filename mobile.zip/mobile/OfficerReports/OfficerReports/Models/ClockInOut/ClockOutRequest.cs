﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ClockInOut
{
    public class ClockOutRequest : ApiRequest
    {
        public int ClockInOutId { get; set; }
        public int OutClientSiteId { get; set; }
        public bool OutHasLocationInfo { get; set; }
        public double OutLatitude { get; set; }
        public double OutLongitude { get; set; }
        public int OutAccuracyFeet { get; set; }
        public int OutDistanceFromSiteFeet { get; set; }
        public string OutDeviceType { get; set; }
        public string OutDeviceInfo { get; set; }
        public string Comment { get; set; }
        public string OutComment { get; set; }
        public int OutClockTypeId { get; set; }
        public DateTime? InDateLocal { get; set; }
        public DateTime? OutDateLocal { get; set; }
        public string CurrentTimeZone { get; set; }
    }
}
