﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ClockInOut
{
    public class ClockEntry : ApiData
    {
        public int ClockInOutId { get; set; }
        public int UserId { get; set; }
        public DateTime? InDate { get; set; }
        public DateTime? InDateForFilter { get; set; }
        public int? InClientSiteId { get; set; }
        public DateTime? OutDate { get; set; }
        public int? OutClientSiteId { get; set; }
        public int IsComplete { get; set; }
        public string MinutesBetween { get; set; }
        public string Comment { get; set; }
        public string InComment { get; set; }
        public string OutComment { get; set; }
        public int? InClockTypeId { get; set; }
        public string InClockType { get; set; }
        public int? OutClockTypeId { get; set; }
        public string OutClockType { get; set; }
        public DateTime? InDateLocal { get; set; }
        public DateTime? OutDateLocal { get; set; }
    }
}
