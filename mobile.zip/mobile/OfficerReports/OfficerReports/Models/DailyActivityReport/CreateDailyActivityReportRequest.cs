﻿using Newtonsoft.Json;
using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.DailyActivityReport
{
    public class CreateDailyActivityReportRequest : ApiRequest
    {
        public string ClientSiteId { get; set; }
        public string CreatedById { get; set; }
        public string PostItemsReceived { get; set; }
        public string PostShift { get; set; }
        public string RelievingOfficerFirstName { get; set; }
        public string RelievingOfficerLastName { get; set; }
        public string SpecialInstructions { get; set; }
        public string UserId { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }
        public List<Observation> ObservationArray { get; set; }

        public override RealmObject ToRealmObject()
        {
            var obj = new CreateDailyActivityReportRequestDto
            {
                ClientSiteId = ClientSiteId,
                CreatedById = CreatedById,
                PostItemsReceived = PostItemsReceived,
                PostShift = PostShift,
                RelievingOfficerFirstName = RelievingOfficerFirstName,
                RelievingOfficerLastName = RelievingOfficerLastName,
                SpecialInstructions = SpecialInstructions,
                UserId = UserId,
                UserSubmissionDate = UserSubmissionDate,
                ObservationArray = JsonConvert.SerializeObject(ObservationArray),
                IsAttachmentAdded = IsAttachmentAdded
            };
            return obj;
        }
    }

    public class Observation
    {
        public int ObservationTypeId { get; set; }
        public string Comments { get; set; }
        public DateTime CreatedDate { get; set; }

        [JsonIgnore]
        public ObservationTypeItem ObservationType { get; set; }
    }

    public class CreateDailyActivityReportRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public string ClientSiteId { get; set; }
        public string CreatedById { get; set; }
        public string PostItemsReceived { get; set; }
        public string PostShift { get; set; }
        public string RelievingOfficerFirstName { get; set; }
        public string RelievingOfficerLastName { get; set; }
        public string SpecialInstructions { get; set; }
        public string UserId { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }
        public string ObservationArray { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateDailyActivityReportRequest
            {
                ClientSiteId = ClientSiteId,
                CreatedById = CreatedById,
                PostItemsReceived = PostItemsReceived,
                PostShift = PostShift,
                RelievingOfficerFirstName = RelievingOfficerFirstName,
                RelievingOfficerLastName = RelievingOfficerLastName,
                SpecialInstructions = SpecialInstructions,
                UserId = UserId,
                UserSubmissionDate = UserSubmissionDate,
                ObservationArray = JsonConvert.DeserializeObject<List<Observation>>(ObservationArray),
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }
}
