﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models
{
    public class CustomReportRequest : ApiRequest
    {
        public int CustomReportId { get; set; }
        public int ClientId { get; set; }
        public int ClientSiteId { get; set; }
        public int CustomerId { get; set; }
        public string ReportDataJson { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new CustomReportRequestDto
            {
                ClientId = ClientId,
                ClientSiteId = ClientSiteId,
                CustomerId = CustomerId,
                CustomReportId = CustomReportId,
                ReportDataJson = ReportDataJson,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class CustomReportRequestDto : RealmObject
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public int CustomReportId { get; set; }
        public int ClientId { get; set; }
        public int ClientSiteId { get; set; }
        public int CustomerId { get; set; }
        public string ReportDataJson { get; set; }
        public bool IsAttachmentAdded { get; set; }
    }
}
