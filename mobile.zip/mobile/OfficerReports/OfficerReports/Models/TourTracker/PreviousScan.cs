﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.TourTracker
{
    public class PreviousScan : ApiData
    {
        public int TourStopScanId { get; set; }
        public int SiteTourStopId { get; set; }
        public string TourStopName { get; set; }
        public string TourStopDescription { get; set; }
        public DateTime ScanDate { get; set; }
    }
}
