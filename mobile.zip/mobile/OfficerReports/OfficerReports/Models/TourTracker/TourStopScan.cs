﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.TourTracker
{
    public class TourStopScan : ApiRequest
    {
        public int SiteTourStopId { get; set; }
        public string ScanDate { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string DeviceInfo { get; set; }
        public int TourStopTypeId { get; set; }
        public int ClientSiteId { get; set; }
        public bool IsSync { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");

        public override RealmObject ToRealmObject()
        {
            return new TourStopScanDto
            {
                ClientSiteId = ClientSiteId,
                DeviceInfo = DeviceInfo,
                Latitude = Latitude,
                Longitude = Longitude,
                ScanDate = ScanDate,
                SiteTourStopId = SiteTourStopId,
                TourStopTypeId = TourStopTypeId,
                UserSubmissionDate = UserSubmissionDate
            };
        }
    }

    public class TourStopScanDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public int SiteTourStopId { get; set; }
        public string ScanDate { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string DeviceInfo { get; set; }
        public int TourStopTypeId { get; set; }
        public int ClientSiteId { get; set; }
        public bool IsSync { get; set; }
        public string UserSubmissionDate { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new TourStopScan
            {
                ClientSiteId = ClientSiteId,
                DeviceInfo = DeviceInfo,
                Latitude = Latitude,
                Longitude = Longitude,
                ScanDate = ScanDate,
                SiteTourStopId = SiteTourStopId,
                TourStopTypeId = TourStopTypeId,
                UserSubmissionDate = UserSubmissionDate,
                IsSync = true
            };
        }
    }
}
