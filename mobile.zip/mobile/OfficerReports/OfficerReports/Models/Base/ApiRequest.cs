﻿using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Base
{
    public interface IApiRequest
    {
        public ApiRequest ToApiRequest();
    }

    public class ApiRequest
    {
        public virtual RealmObject ToRealmObject()
        {
            return null;
        }

        public virtual TData FromRealmObject<TData>()
        {
            return default(TData);
        }
    }
}
