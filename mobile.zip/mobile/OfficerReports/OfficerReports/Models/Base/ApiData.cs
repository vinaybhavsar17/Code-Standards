﻿using Newtonsoft.Json;
using OfficerReports.ViewModels.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Base
{
    public interface IApiData
    {
        public ApiData ToApiObject();
    }

    public class ApiData : ExtendedBindableObject
    {
        public virtual RealmObject ToRealmObject()
        {
            return null;
        }

        public static TData ConvertToObject<TData>(dynamic data)
        {
            var result = default(TData);

            try
            {
                var json = JsonConvert.SerializeObject(data);

                if (json == null || json == "null")
                    json = "{}";

                result = JsonConvert.DeserializeObject<TData>(json);
            }
            catch (Exception ex)
            {
            }
            
            return result;
        }

        public static List<TData> ConvertToList<TData>(dynamic data)
        {
            var result = default(List<TData>);

            try
            {
                var json = JsonConvert.SerializeObject(data);

                if (json == null || json == "null")
                    json = "[]";

                result = JsonConvert.DeserializeObject<List<TData>>(json);
            }
            catch (Exception ex)
            {
            }
            
            return result;
        }
    }
}
