﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Base
{
    public class ApiResponse
    {
        public ApiResponse()
        {

        }

        public ApiResponse(bool isUnauthorized)
        {
            IsUnauthorized = isUnauthorized;
        }

        public ApiResponse(string message)
        {
            Message = message;
        }

        public int StatusCode { get; set; }

        public bool Status { get; set; }

        public string Message { get; set; }

        public string Title { get; set; }

        public dynamic Errors { get; set; }

        public dynamic Data { get; set; }

        [JsonIgnore]
        public object ProcessedData { get; set; }

        [JsonIgnore]
        public bool IsSuccess { 
            get 
            {
                if (Status && StatusCode == 0)
                    return false;
                else
                    return Status;
            } 
        }

        [JsonIgnore]
        public bool IsUnauthorized { get; set; } = false;

        [JsonIgnore]
        public bool IsCached { get; set; }

        [JsonIgnore]
        public Guid CachedDataId { get; set; }

        public bool IgnoreResponse { get; set; }

        private ApiData _apiData;
        public ApiData GetApiData<TData>() 
        { 
            if(_apiData == null)
                _apiData = ApiData.ConvertToObject<TData>(Data);
            
            return _apiData;
        }

        private IEnumerable<ApiData> _apiDataList;
        public IEnumerable<ApiData> GetApiDataList<TData>()
        {
            if (_apiDataList == null)
                _apiDataList = ApiData.ConvertToList<TData>(Data);

            return _apiDataList;
        }
    }
}
