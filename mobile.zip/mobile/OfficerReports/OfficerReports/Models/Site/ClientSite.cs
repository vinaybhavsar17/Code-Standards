﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Site
{
    public class ClientSite : ApiData
    {
        public int ClientSiteId { get; set; }
        public int CustomerId { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string SiteName { get; set; }
        public string SiteLatitude { get; set; }
        public string SiteLongitude { get; set; }

    }
}
