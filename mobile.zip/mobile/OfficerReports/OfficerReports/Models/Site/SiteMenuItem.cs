﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Site
{
    public class SiteMenuItem : ApiData
    {
        public int OfficerPortalActivityId { get; set; }
        public string DisplayName { get; set; }
        public string IconUrl { get; set; }
        public string MobileUrl { get; set; }
        public string WebnUrl { get; set; }
        public int SortOrder { get; set; }
        public int RoleId { get; set; }
        public int ActivityId { get; set; }
        public string ActivityName { get; set; }
        public string Category { get; set; }
    }
}
