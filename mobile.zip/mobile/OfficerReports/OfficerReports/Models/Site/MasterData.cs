﻿using System;
using OfficerReports.Models.Base;
using OfficerReports.Models.Incident;
using OfficerReports.Models.DailyActivityReport;
using OfficerReports.Models.MaintenanceReport;
using OfficerReports.Models.ParkingViolation;
using OfficerReports.Models.TemperatureLog;
using OfficerReports.Models.VisitorCheckInOut;
using OfficerReports.Models.FieldInspection;
using Realms;
using Newtonsoft.Json;

namespace OfficerReports.Models.Site
{
	public class MasterData : ApiData
	{
		public IncidentType IncidentData { get; set; }
		public ObservationType ObservationData { get; set; }
        public MaintenanceType MaintenanceType { get; set; }
        public ParkingViolationType ParkingViolationsType { get; set; }
        public EquipmentType EquipmentType { get; set; }
        public VisitorIdType VisitorIdType { get; set; }
        public dynamic Officers { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new MasterDataDto
            {
                IncidentData = JsonConvert.SerializeObject(IncidentData),
                ObservationData = JsonConvert.SerializeObject(ObservationData),
                MaintenanceType = JsonConvert.SerializeObject(MaintenanceType),
                ParkingViolationsType = JsonConvert.SerializeObject(ParkingViolationsType),
                EquipmentType = JsonConvert.SerializeObject(EquipmentType),
                VisitorIdType = JsonConvert.SerializeObject(VisitorIdType),
                Officers = JsonConvert.SerializeObject(Officers),
            };
        }
    }

    public class MasterDataDto : RealmObject, IApiData
    {
        [PrimaryKey]
        public int Id { get; set; } = 1;
        public string IncidentData { get; set; }
        public string ObservationData { get; set; }
        public string MaintenanceType { get; set; }
        public string ParkingViolationsType { get; set; }
        public string EquipmentType { get; set; }
        public string VisitorIdType { get; set; }
        public string Officers { get; set; }

        public ApiData ToApiObject()
        {
            return new MasterData
            {
                IncidentData = JsonConvert.DeserializeObject<IncidentType>(IncidentData),
                ObservationData = JsonConvert.DeserializeObject<ObservationType>(ObservationData),
                MaintenanceType = JsonConvert.DeserializeObject<MaintenanceType>(MaintenanceType),
                ParkingViolationsType = JsonConvert.DeserializeObject<ParkingViolationType>(ParkingViolationsType),
                EquipmentType = JsonConvert.DeserializeObject<EquipmentType>(EquipmentType),
                VisitorIdType = JsonConvert.DeserializeObject<VisitorIdType>(VisitorIdType),
                Officers = JsonConvert.DeserializeObject<dynamic>(Officers)
            };
        }
    }
}

