﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.Site
{
    public class SiteMenuItemDetails : ApiData
    {
        public int CustomReportId { get; set; }
        public int ClientCount { get; set; }
        public int SiteCount { get; set; }
        public int ClientId { get; set; }
        public int CustomerId { get; set; }
        public int? EntityId { get; set; }
        public string ReportNameSingular { get; set; }
        public string ReportNamePlural { get; set; }
        public string ReportJson { get; set; }
        public bool UploadEnabled { get; set; }
        public bool IsPortalEnabled { get; set; }
        public bool IsMainSiteEnabled { get; set; }
        public bool InternalOnly { get; set; }
        public bool Editable { get; set; }
        public bool ApprovalRequired { get; set; }
        public string EmailSubjectAbbrev { get; set; }
        public string EmailSubjectFieldId { get; set; }
        public bool EmailSiteUsers { get; set; }
        public bool EmailClientUsers { get; set; }
        public bool EmailCustomerAdmin { get; set; }
        public string EmailList { get; set; }
        public object OwnerEmailList { get; set; }
        public bool CaptureGeoOpen { get; set; }
        public bool CaptureGeoCreate { get; set; }
        public bool IsSupervisorOnly { get; set; }
        public bool EmailSupervisors { get; set; }
        public bool IsDeleted { get; set; }
        public object DeletedDate { get; set; }
        public int? DeletedById { get; set; }
        public DateTime? SubmissionDate { get; set; }
        public DateTimeOffset? CreatedDate { get; set; }
        public int CreatedById { get; set; }
        public DateTimeOffset? ModifiedDate { get; set; }
        public int? ModifiedById { get; set; }
        public object EnteredBy { get; set; }
        public object ModifiedBy { get; set; }
        public bool VisibleToSite { get; set; }
        public bool VisibleToClient { get; set; }
    }
}
