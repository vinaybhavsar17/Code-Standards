﻿using Newtonsoft.Json;
using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.MaintenanceReport
{
    public class CreateMaintenanceReportRequest : ApiRequest
    {
        public string ClientSiteId { get; set; }
        public string MaintenanceTypeId { get; set; }
        public string TypeIfOther { get; set; }
        public string Details { get; set; }
        public string Notification { get; set; }
        public string EmailClient { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new CreateMaintenanceReportRequestDto
            {
                ClientSiteId = ClientSiteId,
                Details = Details,
                EmailClient = EmailClient,
                MaintenanceTypeId = MaintenanceTypeId,
                Notification = Notification,
                TypeIfOther = TypeIfOther,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class CreateMaintenanceReportRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public string ClientSiteId { get; set; }
        public string MaintenanceTypeId { get; set; }
        public string TypeIfOther { get; set; }
        public string Details { get; set; }
        public string Notification { get; set; }
        public string EmailClient { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateMaintenanceReportRequest
            {
                ClientSiteId = ClientSiteId,
                Details = Details,
                EmailClient = EmailClient,
                MaintenanceTypeId = MaintenanceTypeId,
                Notification = Notification,
                TypeIfOther = TypeIfOther,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }
}
