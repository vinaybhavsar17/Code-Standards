﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ParkingViolation
{
    public class ParkingViolationSearchRequest : ApiRequest
    {
        public string LicensePlateNumber { get; set; }
        public int ParkingViolationsTypeId { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public int ClientSiteId { get; set; }
        public int LicensePlateNumberBySearch { get; set; }
        public Paging GridFilters { get; set; }
    }
}
