﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ParkingViolation
{
    public class CreateParkingViolationReportRequest : ApiRequest
    {

        public string ParkingViolationTypeId { get; set; }
        public string ClientSiteId { get; set; }
        public string TypeIfOther { get; set; }
        public string ViolatorFirstName { get; set; }
        public string ViolatorLastName { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public string LicensePlateNumber { get; set; }
        public string Location { get; set; }
        public string Detail { get; set; }
        public string VehicleColor { get; set; }
        public string Fine { get; set; }
        public string Vin { get; set; }
        public string ViolationNumber { get; set; }
        public string VehicleTowed { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");
        public bool IsAttachmentAdded { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new CreateParkingViolationReportRequestDto
            {
                ClientSiteId = ClientSiteId,
                Detail = Detail,
                Fine = Fine,
                LicensePlateNumber = LicensePlateNumber,
                Location = Location,
                ParkingViolationTypeId = ParkingViolationTypeId,
                TypeIfOther = TypeIfOther,
                VehicleColor = VehicleColor,
                VehicleMake = VehicleMake,
                VehicleModel = VehicleModel,
                VehicleTowed = VehicleTowed,
                Vin = Vin,
                ViolationNumber = ViolationNumber,
                ViolatorFirstName = ViolatorFirstName,
                ViolatorLastName = ViolatorLastName,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }

    public class CreateParkingViolationReportRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public string ParkingViolationTypeId { get; set; }
        public string ClientSiteId { get; set; }
        public string TypeIfOther { get; set; }
        public string ViolatorFirstName { get; set; }
        public string ViolatorLastName { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public string LicensePlateNumber { get; set; }
        public string Location { get; set; }
        public string Detail { get; set; }
        public string VehicleColor { get; set; }
        public string Fine { get; set; }
        public string Vin { get; set; }
        public string ViolationNumber { get; set; }
        public string VehicleTowed { get; set; }
        public string UserSubmissionDate { get; set; }
        public bool IsAttachmentAdded { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateParkingViolationReportRequest
            {
                ClientSiteId = ClientSiteId,
                Detail = Detail,
                Fine = Fine,
                LicensePlateNumber = LicensePlateNumber,
                Location = Location,
                ParkingViolationTypeId = ParkingViolationTypeId,
                TypeIfOther = TypeIfOther,
                VehicleColor = VehicleColor,
                VehicleMake = VehicleMake,
                VehicleModel = VehicleModel,
                VehicleTowed = VehicleTowed,
                Vin = Vin,
                ViolationNumber = ViolationNumber,
                ViolatorFirstName = ViolatorFirstName,
                ViolatorLastName = ViolatorLastName,
                UserSubmissionDate = UserSubmissionDate,
                IsAttachmentAdded = IsAttachmentAdded
            };
        }
    }
}
