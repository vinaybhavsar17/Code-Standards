﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ParkingViolation
{
    public class ParkingViolationType : ApiData
    {
        public List<ParkingViolationTypeItem> Data { get; set; }
    }

    public class ParkingViolationTypeItem
    {
        public int TypeDataId { get; set; }
        public string TypeDataName { get; set; }
        public int SortOrder { get; set; }
    }
}
