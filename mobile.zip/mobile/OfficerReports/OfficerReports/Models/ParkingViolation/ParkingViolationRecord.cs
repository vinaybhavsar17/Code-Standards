﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ParkingViolation
{
    public class ParkingViolationRecord
    {
        public DateTime CreatedDate { get; set; }
        public string ViolatorFirstName { get; set; }
        public string ViolatorLastName { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public string LicensePlateNumber { get; set; }
        public string Vin { get; set; }
        public string VehicleColor { get; set; }
        [JsonProperty("typeDataName")]
        public string ViolationType { get; set; }
        public string TypeIfOther { get; set; }
    }
}

