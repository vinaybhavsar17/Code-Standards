﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.ParkingViolation
{
    public class ParkingViolationSearchResult : ApiData
    {
        public int Count { get; set; }
        public List<ParkingViolationRecord> Records { get; set; }
    }
}
