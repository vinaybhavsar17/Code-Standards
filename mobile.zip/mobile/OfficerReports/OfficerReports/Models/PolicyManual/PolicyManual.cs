﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.PolicyManual
{
    public class PolicyManual : ApiData
    {
        public int PolicyManualEntryId { get; set; }
        public int PolicyManualSubCategoryId { get; set; }
        public int PolicyManualMainCategoryId { get; set; }
        public string PolicyManualSubCategory { get; set; }
        public string PolicyManualMainCategory { get; set; }
        public int CustomerId { get; set; }
        public string Title { get; set; }
        public string Details { get; set; }
        public string FileName { get; set; }
        public string OriginalFileName { get; set; }
        public string FileUrl { get; set; }

        private DateTime _createdDate;
        public DateTime CreatedDate
        {
            get
            {
                return _createdDate.ToLocalTime();
            }
            set
            {
                _createdDate = value;
            }
        }
    }
}
