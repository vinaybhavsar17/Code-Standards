﻿using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.TemperatureLog
{
    public class CreateTemperatureLogRequest : ApiRequest
    {
        public int EquipmentTypeId { get; set; }
        public string EquipmentId { get; set; }
        public float Temperature { get; set; }
        public string Humidity { get; set; }
        public string FuelLevel { get; set; }
        public string Co2Level { get; set; }
        public int ClientSiteId { get; set; }
        public string UserSubmissionDate { get; set; } = DateTime.Now.ToString("O");

        public override RealmObject ToRealmObject()
        {
            return new CreateTemperatureLogRequestDto
            {
                ClientSiteId = ClientSiteId,
                Co2Level = Co2Level,
                EquipmentId = EquipmentId,
                EquipmentTypeId = EquipmentTypeId,
                FuelLevel = FuelLevel,
                Humidity = Humidity,
                Temperature = Temperature,
                UserSubmissionDate = UserSubmissionDate
            };
        }
    }

    public class CreateTemperatureLogRequestDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public int EquipmentTypeId { get; set; }
        public string EquipmentId { get; set; }
        public float Temperature { get; set; }
        public string Humidity { get; set; }
        public string FuelLevel { get; set; }
        public string Co2Level { get; set; }
        public int ClientSiteId { get; set; }
        public string UserSubmissionDate { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new CreateTemperatureLogRequest
            {
                ClientSiteId = ClientSiteId,
                Co2Level = Co2Level,
                EquipmentId = EquipmentId,
                EquipmentTypeId = EquipmentTypeId,
                FuelLevel = FuelLevel,
                Humidity = Humidity,
                Temperature = Temperature,
                UserSubmissionDate = UserSubmissionDate
            };
        }
    }
}
