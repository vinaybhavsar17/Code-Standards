﻿using Newtonsoft.Json;
using OfficerReports.Models.Base;
using Realms;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models
{
    public class FileInfo : ApiRequest
    {
        public string ContentType { get; set; }
        public string FileName { get; set; }
        public string FullPath { get; set; }
        public long FileSize { get; set; }
        public bool IsImage { get; set; }
        public string Notes { get; set; }
        public string AzureFileName { get; set; }
        public string AzureFileUrl { get; set; }
        public ImageSource Image { get; set; }
        public string CompressedImagePath { get; set; }
        public DateTime CreatedDate { get; set; }

        public override RealmObject ToRealmObject()
        {
            return new FileInfoDto
            {
                ContentType = ContentType,
                FileName = FileName,
                FullPath = FullPath,
                FileSize = FileSize,
                AzureFileName = AzureFileName,
                AzureFileUrl = AzureFileUrl,
                CompressedImagePath = CompressedImagePath,
                CreatedDate = CreatedDate,
                ImageSource = ((FileImageSource)Image)?.File,
                IsImage = IsImage,
                Notes = Notes
            };
        }
    }

    public class FileInfoDto : RealmObject, IApiRequest
    {
        [PrimaryKey]
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid ReportId { get; set; }
        public string Section { get; set; }
        public string Purpose { get; set; }
        public int EntityType { get; set; }
        public string ContentType { get; set; }
        public string FileName { get; set; }
        public string FullPath { get; set; }
        public long FileSize { get; set; }
        public bool IsImage { get; set; }
        public string Notes { get; set; }
        public string AzureFileName { get; set; }
        public string AzureFileUrl { get; set; }
        public string ImageSource { get; set; }
        public string CompressedImagePath { get; set; }
        public DateTimeOffset CreatedDate { get; set; }

        public ApiRequest ToApiRequest()
        {
            return new FileInfo
            {
                ContentType = ContentType,
                FileName = FileName,
                FullPath = FullPath,
                FileSize = FileSize,
                AzureFileName = AzureFileName,
                AzureFileUrl = AzureFileUrl,
                CompressedImagePath = CompressedImagePath,
                CreatedDate = CreatedDate.DateTime,
                Image = FileImageSource.FromFile(ImageSource),
                IsImage = IsImage,
                Notes = Notes
            };
        }
    }
}
