﻿using OfficerReports.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Models.User
{
    public class ForgotRequest : ApiRequest
    {
        public string Email { get; set; }
        public string BaseUrl { get; set; }
        public string UserName { get; set; }
    }
}
