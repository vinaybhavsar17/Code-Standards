﻿
using OfficerReports.Resources.Strings;
using OfficerReports.Services.Dialog;
using OfficerReports.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficerReports.Constants;
using OfficerReports.Models.Authentication;
using OfficerReports.ViewModels.Authentication;
using OfficerReports.Helpers;

namespace OfficerReports.Services.LocationService
{
    public class LocationService : ILocationService
    {
        private IDialogService _dialogService;
        private bool _shouldTrackLocation;

        public LocationService(){
            _dialogService = App.ServiceProvider.GetRequiredService<IDialogService>();
        }

        public async Task<Location> GetCurrentLocation(bool isBackground = true)
        {
            var mimicLocation = MimicDataManager.MimicLocation;
            if (mimicLocation != null)
                return mimicLocation;
            

            Location location = null;

            try
            {
                if(!isBackground)
                    _dialogService.ShowLoading(AppResource.Fetching_Location);

                location = await Geolocation.GetLocationAsync(new GeolocationRequest
                {
                    DesiredAccuracy = GeolocationAccuracy.Best,
                    Timeout = TimeSpan.FromSeconds(10)
                });

                if (location == null)
                    _dialogService.ShowMessage(AppResource.Location_Access_Title, AppResource.Unable_Fetch_Location);
                else if (location.IsFromMockProvider)
                    _dialogService.ShowMessage(AppResource.Mock_Location_Found, AppResource.Mock_Location_Message);
            }
            catch (FeatureNotSupportedException fnsEx)
            {
                // Handle not supported on device exception
                _dialogService.ShowMessage(AppResource.Location_Access_Title, AppResource.Device_Not_Support_Location);
            }
            catch (FeatureNotEnabledException fneEx)
            {
                // Handle not enabled on device exception
                var isConfirmed = await _dialogService.Confirm(AppResource.GPS_Turn_Off, AppResource.Location_Access_Title, AppResource.Settings, AppResource.No_Thanks);
                if (isConfirmed)
                    DeviceSettings.OpenLocationSetting();
            }
            catch (PermissionException pEx)
            {
                // Handle permission exception
                _dialogService.ShowMessage(AppResource.Location_Access_Title, AppResource.Location_Permission_Denied);
            }
            catch (Exception ex)
            {
                _dialogService.ShowMessage(AppResource.Location_Access_Title, AppResource.Unable_Fetch_Location);
            }

            if (!isBackground)
                _dialogService.HideLoading();

            return location;
        }

        public async void StartLocationTracking()
        {
            _shouldTrackLocation = true;

            var alwaysPermissionStatus = await Permissions.CheckStatusAsync<Permissions.LocationAlways>();
            var whenInUsePermissionStatus = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            if (alwaysPermissionStatus != PermissionStatus.Granted && whenInUsePermissionStatus != PermissionStatus.Granted)
            {
                alwaysPermissionStatus = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
                whenInUsePermissionStatus = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
                if (alwaysPermissionStatus == PermissionStatus.Granted || whenInUsePermissionStatus == PermissionStatus.Granted)
                    LocationUpdateService.StartLocationTracking();
                else
                    ListenForPermission();
            }
            else
            {
                LocationUpdateService.StartLocationTracking();
            }
                
        }

        public void StopLocationTracking()
        {
            _shouldTrackLocation = false;

            LocationUpdateService.StopLocationTracking();
        }

        private void ListenForPermission()
        {
            MessagingCenter.Subscribe<App>(this, App.MESSAGE_RESUME, async(sender) =>
            {
                if (_shouldTrackLocation)
                {
                    var alwaysPermissionStatus = await Permissions.CheckStatusAsync<Permissions.LocationAlways>();
                    var whenInUsePermissionStatus = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

                    if (alwaysPermissionStatus == PermissionStatus.Granted || whenInUsePermissionStatus == PermissionStatus.Granted)
                    {
                        LocationUpdateService.StartLocationTracking();

                        MessagingCenter.Unsubscribe<App>(this, App.MESSAGE_RESUME);
                    }
                }
                else
                {
                    MessagingCenter.Unsubscribe<App>(this, App.MESSAGE_RESUME);
                }
            });
        }
    }
}
