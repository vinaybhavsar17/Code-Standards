﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficerReports.Interfaces
{
    public partial class LocationUpdateService
    {
        public static partial void StartLocationTracking();

        public static partial void StopLocationTracking();
    }
}
