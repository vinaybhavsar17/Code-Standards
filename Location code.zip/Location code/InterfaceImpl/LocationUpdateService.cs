﻿using Android.Content;
using Android.Locations;
using Android.OS;
using Android.Runtime;
using Java.Interop;
using Microsoft.Extensions.Logging;
using OfficerReports.Constants;
using OfficerReports.Platforms.Android.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Location = Microsoft.Maui.Devices.Sensors.Location;

namespace OfficerReports.Interfaces
{
    public partial class LocationUpdateService
    {
        private static Intent _serviceIntent = null;

        public static partial void StartLocationTracking()
        {
            if(_serviceIntent == null)
            {
                _serviceIntent = new Intent(Android.App.Application.Context, typeof(AndroidLocationService));

                if (Android.OS.Build.VERSION.SdkInt >= Android.OS.BuildVersionCodes.O)
                {
                    Android.App.Application.Context.StartForegroundService(_serviceIntent);
                }
                else
                {
                    Android.App.Application.Context.StartService(_serviceIntent);
                }
            }
        }

        public static partial void StopLocationTracking()
        {
            if(_serviceIntent != null)
            {
                Android.App.Application.Context.StopService(_serviceIntent);
                _serviceIntent = null;
            }
        }
    }

    public class OfficerLocationListener : Java.Lang.Object, ILocationListener
    {
        private LocationManager _locationManager;

        public OfficerLocationListener(LocationManager locationManager)
        {
            _locationManager = locationManager;
        }

        public void OnLocationChanged(Android.Locations.Location location)
        {
            if (location != null && !location.IsFromMockProvider)
            {
                var mauiLocation = new Location
                {
                    Accuracy = location.Accuracy,
                    Latitude = location.Latitude,
                    Longitude = location.Longitude
                };
                MessagingCenter.Send<Application, Location>(App.Current, AppConstants.MessageLocationUpdate, mauiLocation);
            }
        }

        public void OnProviderDisabled(string provider)
        {
        }

        public void OnProviderEnabled(string provider)
        {
        }

        public void OnStatusChanged(string provider, [GeneratedEnum] Availability status, Bundle extras)
        {
        }
    }
}
